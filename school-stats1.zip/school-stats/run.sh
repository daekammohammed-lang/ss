#!/bin/sh
# Linux/Mac: ينشئ بيئة بايثون ويثبّت المكتبات ويشغّل المنصة
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
python run.py
