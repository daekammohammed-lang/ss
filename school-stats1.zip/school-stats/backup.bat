@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist backups mkdir backups
for /f %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set T=%%t
if exist .venv\Scripts\python.exe (set PY=.venv\Scripts\python.exe) else (set PY=python)
%PY% -c "import sqlite3;s=sqlite3.connect('data/app.db');d=sqlite3.connect('backups/app-%T%.db');s.backup(d);d.close();print('تم حفظ نسخة قاعدة البيانات')"
if exist data\uploads powershell -NoProfile -Command "Compress-Archive -Path data\uploads,data\secret.key -DestinationPath backups\files-%T%.zip -Force" 2>nul
rem يبقي آخر 14 نسخة فقط
powershell -NoProfile -Command "Get-ChildItem backups\app-*.db | Sort-Object LastWriteTime -Descending | Select-Object -Skip 14 | Remove-Item; Get-ChildItem backups\files-*.zip | Sort-Object LastWriteTime -Descending | Select-Object -Skip 14 | Remove-Item" 2>nul
echo انسخ مجلد backups إلى فلاش أو جهاز آخر كذلك.
