#!/usr/bin/env python3
"""يولّد تعريفات الاستمارات (forms/*.json) من قوالب Excel الرسمية.

كل عمود ورقي ← حقل له مفتاح ثابت (حرف العمود) ومسار ترويسة كامل ونوع،
والأعمدة المحسوبة تُستخرج صيغتها من القالب (كلها مجاميع بسيطة لخلايا الصف نفسه).
يُنتج أيضاً تقرير تدقيق الصيغ (reports/formula_audit.json).
"""
import json, re, sys, os, collections, itertools
import openpyxl
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

TEMPLATES = {
    "primary":   dict(file="templates_xlsx/primary.xlsx",   title="الابتدائي / الأساسي / المتوسط",
                      hdr_last=5, data_start=6, info_end=42),
    "secondary": dict(file="templates_xlsx/secondary.xlsx", title="الثانوي (متوسط + إعدادي)",
                      hdr_last=6, data_start=7, info_end=42),
    "kg":        dict(file="templates_xlsx/kg.xlsx",        title="رياض الأطفال",
                      hdr_last=7, data_start=8, info_end=36),
}

# أخطاء في صيغ قالب رياض الأطفال الرسمي (تجميع بنون/بنات من أعمدة المجموع) — تُصحَّح في المنصة وتُذكر في التقرير
CORRECTIONS = {"kg": {"BL": ["BF", "BI"], "BM": ["BG", "BJ"]}}

# تصحيح مجاميع بنين/بنات (الراسبون/الناجحون/التاركون…) في قالب الابتدائي: العمود = جمع كل أعمدة نفس الجنس ضمن المجال
RANGE_CORRECTIONS = {"primary": {"JN": ("JB", "JM"), "JO": ("JB", "JM"),
                                 "KC": ("JQ", "KB"), "KD": ("JQ", "KB"),
                                 "KR": ("KF", "KQ"), "KS": ("KF", "KQ")}}

MALE = {"بنين", "بنون", "ذكور"}
FEMALE = {"بنات", "اناث", "إناث"}


def norm(s):
    s = re.sub(r"[ـ]+", "", str(s))          # تطويل
    s = re.sub(r"\s+", " ", s).strip()
    return s


def header_paths(ws, hdr_last, maxc):
    grid = {}
    for r in range(1, hdr_last + 1):
        for c in range(1, maxc + 1):
            v = ws.cell(r, c).value
            if v not in (None, ""):
                grid[(r, c)] = norm(v)
    for m in ws.merged_cells.ranges:
        if m.min_row <= hdr_last:
            v = grid.get((m.min_row, m.min_col))
            if v:
                for r in range(m.min_row, min(m.max_row, hdr_last) + 1):
                    for c in range(m.min_col, min(m.max_col, maxc) + 1):
                        grid[(r, c)] = v
    paths = {}
    for c in range(1, maxc + 1):
        p = []
        for r in range(1, hdr_last + 1):
            v = grid.get((r, c))
            if v and (not p or p[-1] != v):
                p.append(v)
        paths[c] = p
    return paths


def canonical_formula_row(ws, start, maxc):
    """الصف الذي نقرأ منه الصيغ: آخر صف يحوي أكبر عدد صيغ (صفوف القالب الأخيرة أصح في رياض الأطفال)."""
    best = None
    for r in range(start, ws.max_row + 1):
        n = sum(1 for c in range(1, maxc + 1)
                if isinstance(ws.cell(r, c).value, str) and ws.cell(r, c).value.startswith("="))
        if n and (best is None or n >= best[1]):
            best = (r, n)
    return best[0]


def parse_sum(formula, row):
    refs = re.findall(r"([A-Z]+)%d\b" % row, formula)
    return refs


# ---------------------------------------------------------------- أنواع الحقول
TEXT_WORDS = ("اسم", "هاتف", "البريد", "القضاء", "الناحية", "القرية", "الحي", "زقاق", "محلة",
              "دار", "التصنيف", "اذكر", "ذكر")
NUM_INFO = ("سنة تأسيس", "سنة تاسيس", "تأسيس", "تاسيس")
CHECK_KEYWORDS = ("مادة البناء", "عائدية البناية", "الحالة العمرانية", "نوع البناء", "نوع البناية",
                  "تشغلها", "المسؤولية", "نوعية", "سياج", "مصدر", "نوع الخدمة", "المجاري",
                  "الماء الصالح", "اللغة", "مشمولة", "مستقل")


def infer_type(path, section_is_info, siblings_leaves, sec_title):
    leaf = path[-1] if path else ""
    full = " ".join(path)
    if section_is_info:
        if leaf in ("ت",):
            return "seq"
        if any(w in full for w in ("الرقم الاحصائي",)) and "الاصلية" not in full and "اذا" not in full:
            return "id"
        if any(w in full for w in NUM_INFO):
            return "text"      # القائمة الرسمية تحوي أحياناً «2019/2020» لا سنة صرفة، فلا يصح فرض رقم
        if "GPS" in full or leaf in ("N", "E"):
            return "number"
        if any(w in leaf for w in TEXT_WORDS) or (any(w in full for w in TEXT_WORDS) and len(siblings_leaves) <= 1):
            return "text"
        if len(siblings_leaves) >= 2:
            return "check"
        return "text"
    # أقسام غير المعلومات العامة
    if leaf in ("نعم", "كلا", "نعم ", "لا"):
        return "check"
    if sec_title.startswith("عدد") or sec_title.startswith("الراسب") or sec_title.startswith("الناجح"):
        return "number"
    parent = path[-2] if len(path) >= 2 else ""
    if len(siblings_leaves) >= 2 and "عدد" not in parent and any(k in full for k in CHECK_KEYWORDS):
        return "check"
    if "ماهي اللغة" in full or "اذكر" in full:
        return "text"
    return "number"


def split_sections(paths, maxc, info_end):
    """يقسم الأعمدة إلى أقسام: المعلومات العامة ثم كل عنوان رئيسي متصل."""
    sections = []
    cur = None
    for c in range(1, maxc + 1):
        p = paths[c]
        if c <= info_end:
            if cur is None or cur["id"] != "info":
                cur = dict(id="info", title="المعلومات العامة", cols=[])
                sections.append(cur)
            cur["cols"].append(c)
            continue
        title = p[0] if p else "(بلا عنوان)"
        if cur is None or cur["title"] != title or cur["id"] == "info":
            cur = dict(id="s%d" % (len(sections)), title=title, cols=[])
            sections.append(cur)
        cur["cols"].append(c)
    return sections


def choose_grid(levels_per_field):
    """يختار توزيع (صفوف × أعمدة) لمستويات المسار بحيث يقترب الجدول من الشكل الورقي."""
    k = len(levels_per_field[0])
    best = None
    idx = list(range(k))
    for rcount in range(0, k + 1):
        for rows_idx in itertools.combinations(idx, rcount):
            cols_idx = [i for i in idx if i not in rows_idx]
            rows = collections.OrderedDict()
            cols = collections.OrderedDict()
            for lv in levels_per_field:
                rows.setdefault(tuple(lv[i] for i in rows_idx), 0)
                cols.setdefault(tuple(lv[i] for i in cols_idx), 0)
            nr, nc = len(rows), len(cols)
            if nr == 0 or nc == 0:
                continue
            score = (max(nr, nc), -min(nr, nc))
            # نفضّل أن تكون الأعمدة هي المستوى الأخير (الجنس) أو ما يشبه الورق: صفوف ≤ أعمدة×3
            if best is None or score < best[0]:
                best = (score, rows_idx, cols_idx)
    return best[1], best[2]


def build_template(tid, cfg):
    wb = openpyxl.load_workbook(os.path.join(ROOT, cfg["file"]))
    ws = wb.worksheets[0]
    maxc = 0
    for r in range(1, cfg["hdr_last"] + 1):
        for c in ws[r]:
            if c.value not in (None, ""):
                maxc = max(maxc, c.column)
    paths = header_paths(ws, cfg["hdr_last"], maxc)
    frow = canonical_formula_row(ws, cfg["data_start"], maxc)

    # الصيغ لكل صف لتدقيق الاختلافات
    variants = collections.defaultdict(collections.Counter)
    for r in range(cfg["data_start"], ws.max_row + 1):
        for c in range(1, maxc + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and v.startswith("="):
                variants[c][tuple(sorted(parse_sum(v, r)))] += 1
    formulas = {}
    for c in range(1, maxc + 1):
        v = ws.cell(frow, c).value
        if isinstance(v, str) and v.startswith("="):
            formulas[c] = parse_sum(v, frow)
    corrected = []
    for col, (a, b) in RANGE_CORRECTIONS.get(tid, {}).items():
        sex = MALE if (paths[CI(col)] or [""])[-1] in MALE else FEMALE
        refs = [L(x) for x in range(CI(a), CI(b) + 1) if (paths[x] or [""])[-1] in sex]
        CORRECTIONS.setdefault(tid, {})[col] = refs
    for col, refs in CORRECTIONS.get(tid, {}).items():
        old = formulas.get(CI(col))
        formulas[CI(col)] = refs
        corrected.append(dict(col=col, was="+".join(old or []), now="+".join(refs)))

    # عناوين الأعمدة المتكررة (خلايا مدموجة لعمودين بلا عنوان جنس): الأول ذكور والثاني إناث
    leaf_label = {}
    dup_assumed = []
    prev = None
    run = []
    for c in range(1, maxc + 1):
        key = tuple(paths[c])
        if key == prev and paths[c]:
            run.append(c)
        else:
            if len(run) == 2:
                pass
            run = [c]
        prev = key
    seen = collections.defaultdict(list)
    for c in range(1, maxc + 1):
        if paths[c]:
            seen[tuple(paths[c])].append(c)
    for key, cols in seen.items():
        if len(cols) >= 2 and all(b - a == 1 for a, b in zip(cols, cols[1:])) and len(cols) == 2:
            leaf = key[-1]
            if leaf not in MALE | FEMALE | {"المجموع"}:
                paths[cols[0]] = list(key) + ["ذكور"]
                paths[cols[1]] = list(key) + ["إناث"]
                dup_assumed += cols

    # «المجموع» المتكرر داخل القسم يخص المجموعة التي تسبقه (الصف/المرحلة) — نضيف اسمها للتمييز
    tmp_sections = split_sections(paths, maxc, cfg["info_end"])
    for sec in tmp_sections:
        if sec["id"] == "info":
            continue
        cnt = collections.Counter(tuple(paths[c]) for c in sec["cols"])
        last = {}
        for c in sec["cols"]:
            p = paths[c]
            for d in range(1, len(p) - 1):
                parent = tuple(p[:d])
                if p[d].startswith("المجموع") or p[d].startswith("مجموع"):
                    prev = last.get(parent)
                    if prev and cnt[tuple(p)] > 1 and prev not in p[d]:
                        p[d] = p[d] + " " + prev
                else:
                    last[parent] = p[d]
    sections = split_sections(paths, maxc, cfg["info_end"])
    prev_title = None
    for sec in sections:
        t = sec["title"]
        if (t.startswith("المجموع") or t.startswith("مجموع")) and prev_title and prev_title not in t:
            sec["title"] = t + " — " + prev_title[:48]
        else:
            prev_title = t
    out_sections = []
    fields = {}
    for si, sec in enumerate(sections):
        is_info = sec["id"] == "info"
        cols = sec["cols"]
        base = 0 if is_info else 1
        # مسارات الحقول داخل القسم (بدون عنوان القسم)
        rel = {c: (paths[c] if is_info else paths[c][1:]) or [L(c)] for c in cols}
        if tid == "kg" and is_info:
            rel = {c: [x for x in paths[c] if x != "استمارة المعلومات"] or [L(c)] for c in cols}
        # مجموعات الإخوة (نفس الأب)
        parents = collections.defaultdict(list)
        for c in cols:
            parents[tuple(rel[c][:-1])].append(rel[c][-1])
        flist = []
        for c in cols:
            path = rel[c]
            t = infer_type(path, is_info, parents[tuple(path[:-1])], sec["title"])
            comp = c in formulas
            f = dict(key=L(c), col=c, path=path, type=("computed" if comp else t))
            if comp:
                f["sum"] = [r for r in formulas[c]]
            if t == "check" and not comp:
                f["group"] = " ‹ ".join(path[:-1]) or path[-1]
            fields[L(c)] = f
            flist.append(f)
        # التخطيط
        layout = "list"
        grid = None
        if not is_info and any(len(f["path"]) >= 2 for f in flist) and len(flist) > 1:
            mx = max(len(f["path"]) for f in flist)
            lvls = [f["path"][:-1] + [""] * (mx - len(f["path"])) + [f["path"][-1]] for f in flist]
            if True:
                rows_idx, cols_idx = choose_grid(lvls)
                if rows_idx and cols_idx:
                    layout = "grid"
                    rows = collections.OrderedDict()
                    cols_ = collections.OrderedDict()
                    cells = {}
                    for f in flist:
                        lv = [pp for pp in lvls if False] or None
                        pad = f["path"][:-1] + [""] * (mx - len(f["path"])) + [f["path"][-1]]
                        rk = tuple(pad[i] for i in rows_idx)
                        ck = tuple(pad[i] for i in cols_idx)
                        rows.setdefault(rk, len(rows))
                        cols_.setdefault(ck, len(cols_))
                        cells[f["key"]] = [rows[rk], cols_[ck]]
                    grid = dict(rows=[" / ".join(x for x in k if x) or "المجموع" for k in rows], cols=[[x for x in k if x] for k in cols_],
                                cells=cells)
        out_sections.append(dict(id=sec["id"], title=sec["title"], layout=layout, grid=grid,
                                 fields=[f["key"] for f in flist]))
    # تدقيق الصيغ: عمود ذكور/إناث لا يجمع من الجنس الآخر
    audit = []
    for c, refs in formulas.items():
        leaf = paths[c][-1] if paths[c] else ""
        issues = []
        for rr in refs:
            rl = paths[CI(rr)][-1] if paths[CI(rr)] else ""
            if leaf in MALE and rl in FEMALE or leaf in FEMALE and rl in MALE:
                issues.append("%s (%s) يجمع من %s (%s)" % (L(c), leaf, rr, rl))
            elif (leaf in MALE or leaf in FEMALE) and (rl.startswith("المجموع") or rl.startswith("مجموع")):
                issues.append("%s (%s) يجمع من عمود مجموع %s" % (L(c), leaf, rr))
        vs = variants.get(c, {})
        if len(vs) > 1:
            issues.append("صيغتان مختلفتان بين صفوف القالب: " +
                          " | ".join("+".join(k) + " ×%d" % n for k, n in vs.items()))
        if issues:
            audit.append(dict(col=L(c), path=paths[c], issues=issues, used="+".join(refs)))
    for cr in corrected:
        audit.append(dict(col=cr["col"], path=paths[CI(cr["col"])], used=cr["now"],
                          issues=["صيغة القالب الأصلية خاطئة (%s) — صُحّحت إلى %s" % (cr["was"], cr["now"])]))
    form = dict(id=tid, title=cfg["title"], file=cfg["file"], data_start=cfg["data_start"],
                hdr_last=cfg["hdr_last"], ncols=maxc, formula_row=frow,
                sections=out_sections, fields=fields,
                assumptions=["أعمدة الهيئة التدريسية/الجنسية بلا عنوان جنس في القالب: افتُرض أن الأول ذكور والثاني إناث"]
                if dup_assumed else [])
    return form, audit


def main():
    allaudit = {}
    for tid, cfg in TEMPLATES.items():
        form, audit = build_template(tid, cfg)
        with open(os.path.join(ROOT, "forms", tid + ".json"), "w", encoding="utf-8") as f:
            json.dump(form, f, ensure_ascii=False)
        nf = len(form["fields"])
        ncomp = sum(1 for x in form["fields"].values() if x["type"] == "computed")
        types = collections.Counter(x["type"] for x in form["fields"].values())
        print(tid, "fields", nf, "computed", ncomp, "sections", len(form["sections"]), dict(types),
              "audit", len(audit))
        allaudit[tid] = audit
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "formula_audit.json"), "w", encoding="utf-8") as f:
        json.dump(allaudit, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
