"""نقطة دخول gunicorn: يهيّئ القاعدة ويشغّل عامل المزامنة ثم يعرض التطبيق."""
from app import app, bootstrap
bootstrap()
