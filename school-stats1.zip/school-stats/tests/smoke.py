import requests, json, io, zipfile, time
B="http://127.0.0.1:8000"; s=requests.Session(); s.headers["X-Requested-With"]="fetch"
def ok(r,l):
    print(("OK  " if r.ok else "FAIL"), l, r.status_code, (r.text[:200] if not r.ok else "")); return r
ok(s.post(B+"/api/login",json={"username":"admin","password":"admin123"}),"login")
ok(s.get(B+"/api/me"),"me")
r=ok(s.get(B+"/api/schools/cache"),"cache"); print(len(r.json()["rows"]))
ok(s.get(B+"/api/schools/search?q=1100096"),"search")
r=ok(s.post(B+"/api/booklets",json={"school_id":"1100096"}),"open"); bk=r.json(); print(list(bk)); bid=bk["booklet"]["id"]
r=ok(s.get(B+"/api/booklets/%d"%bid),"get"); j=r.json(); print(list(j), len(j["values"]))
ok(s.get(B+"/api/forms/secondary"),"form")
fl=list(__import__("json").load(open("forms/secondary.json"))["fields"].items())
nums=[k for k,f in fl if f["type"]=="number"][:5]; print(nums)
r=ok(s.put(B+"/api/booklets/%d/values"%bid,json={"changes":[{"k":k,"v":str(i+3)} for i,k in enumerate(nums)]}),"put"); print(r.text[:300])
r=ok(s.put(B+"/api/booklets/%d/values"%bid,json={"changes":[{"k":nums[0],"v":"9","ver":0}]}),"conflict"); print(r.text[:300])
ok(s.get(B+"/api/stats"),"stats")
ok(s.post(B+"/api/booklets/%d/status"%bid,json={"status":"approved"}),"approve")
ok(s.get(B+"/api/export-info"),"exinfo")
t=time.time(); r=ok(s.get(B+"/api/export/secondary?status=all"),"export sec"); print(len(r.content), round(time.time()-t,1),"s")
t=time.time(); r=ok(s.get(B+"/api/export/all?status=all"),"export all"); print(len(r.content), round(time.time()-t,1),"s")
if r.ok: print(zipfile.ZipFile(io.BytesIO(r.content)).namelist())
ok(s.get(B+"/api/export/report"),"report")
ok(s.get(B+"/api/sync/status"),"sync status")
ok(s.get(B+"/api/uploads"),"uploads")
ok(s.get(B+"/api/users"),"users"); ok(s.get(B+"/api/audit?limit=5"),"audit"); ok(s.get(B+"/api/settings"),"settings")
ok(s.get(B+"/api/next"),"next"); ok(s.get(B+"/api/booklets/%d/review"%bid),"review")
