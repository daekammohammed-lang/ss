"""اختبارات شاملة: python3 tests/test_all.py  (تستعمل قاعدة بيانات مؤقتة ومزوّد ذكاء/Google وهميين)."""
import os, sys, io, json, glob, tempfile, time, zipfile, traceback
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
TMP = tempfile.mkdtemp()
os.environ["SCHOOLSTATS_DB"] = os.path.join(TMP, "t.db")
os.environ["ADMIN_PASSWORD"] = "pw123456"
os.environ["SECRET_KEY"] = "x" * 43 + "="
import openpyxl
import db, schools, forms, exporter, syncer, extraction
import app as appmod

appmod.bootstrap.__globals__  # noqa
app = appmod.app
c = app.test_client()
H = {"X-Requested-With": "fetch"}
RESULTS = []


def test(fn):
    try:
        fn(); RESULTS.append((fn.__name__, True, ""))
        print("PASS", fn.__name__)
    except Exception:
        RESULTS.append((fn.__name__, False, traceback.format_exc()))
        print("FAIL", fn.__name__); print(traceback.format_exc())
    return fn


def J(r): return r.get_json()
def post(u, j=None, m="post"): return getattr(c, m)(u, json=j, headers=H)


db.init()
db.get_setting  # noqa
if not db.q1("SELECT 1 FROM schools LIMIT 1"):
    schools.import_master(os.path.join(ROOT, "data", "schools_master.xlsx"), None)
db.ex("DELETE FROM users WHERE username='admin'")
appmod.ensure_admin()


@test
def login_and_csrf():
    assert c.post("/api/login", json={"username": "admin", "password": "bad"}, headers=H).status_code == 401
    assert c.get("/api/booklets/1").status_code == 401
    r = post("/api/login", {"username": "admin", "password": "pw123456"}); assert r.status_code == 200
    # بدون ترويسة الحماية تُرفض عمليات الكتابة
    assert c.post("/api/booklets", json={"school_id": "1100096"}).status_code in (400, 403)


@test
def school_lookup():
    r = J(c.get("/api/schools/1100096", headers=H)); assert "الشموخ" in json.dumps(r, ensure_ascii=False) and "secondary" in json.dumps(r)
    assert c.get("/api/schools/9999999", headers=H).status_code == 404
    rows = J(c.get("/api/schools/cache", headers=H))["rows"]; assert len(rows) == 2344
    t = {}
    for x in rows: t[x[4]] = t.get(x[4], 0) + 1
    assert t["primary"] == 1431 and t["secondary"] == 821 and t["kg"] == 61, t


@test
def entry_and_conflict():
    b = J(post("/api/booklets", {"school_id": "1100096"}))["booklet"]; bid = b["id"]
    assert post("/api/booklets", {"school_id": "1100096"}).status_code == 200  # لا يكرر
    assert db.q1("SELECT COUNT(*) n FROM booklets WHERE school_id='1100096'")["n"] == 1
    form = forms.load_form("secondary"); nums = [k for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][:3]
    r = J(post(f"/api/booklets/{bid}/values", {"changes": [{"k": nums[0], "v": "٧"}, {"k": nums[1], "v": "5"}]}, "put"))
    assert r["applied"][nums[0]] == 1 or r["applied"][nums[0]] >= 1
    v = J(c.get(f"/api/booklets/{bid}", headers=H))["values"]
    assert v[nums[0]]["v"] == "7", "الأرقام الهندية تتحوّل"
    # تعارض: نسخة قديمة
    r = J(post(f"/api/booklets/{bid}/values", {"changes": [{"k": nums[0], "v": "9", "ver": 0}]}, "put"))
    assert r["conflicts"] and r["conflicts"][0]["k"] == nums[0]
    assert J(c.get(f"/api/booklets/{bid}", headers=H))["values"][nums[0]]["v"] == "7"
    # رقم غير صالح يظهر كخطأ ويمنع الاعتماد
    post(f"/api/booklets/{bid}/values", {"changes": [{"k": nums[2], "v": "abc"}]}, "put")
    r = post(f"/api/booklets/{bid}/status", {"status": "approved"}); assert r.status_code == 409, r.data
    post(f"/api/booklets/{bid}/values", {"changes": [{"k": nums[2], "v": "2"}]}, "put")
    r = post(f"/api/booklets/{bid}/status", {"status": "approved"}); assert r.status_code == 200, r.data


@test
def computed_sums_match_client_logic():
    form = forms.load_form("secondary")
    comp = [(k, f) for k, f in form["fields"].items() if f["type"] == "computed"]
    k, f = next((k, f) for k, f in comp if all(form["fields"][x]["type"] == "number" for x in f["sum"]) and len(f["sum"]) >= 2)
    vals = {f["sum"][0]: "3", f["sum"][1]: "4"}
    assert forms.compute(form, vals)[k] == 7


@test
def export_matches_db_and_template_intact():
    # أضف مدارس إضافية معتمدة (ابتدائي وأهلي ورياض)
    import random; random.seed(3)
    for tid, own in (("primary", "حكومي"), ("primary", "اهلي"), ("kg", None), ("secondary", "اهلي")):
        q = "SELECT id FROM schools WHERE template=?" + (" AND ownership=?" if own else "") + " LIMIT 2"
        for s in db.q(q, (tid, own) if own else (tid,)):
            bid = J(post("/api/booklets", {"school_id": s["id"]}))["booklet"]["id"]
            form = forms.load_form(tid)
            ch = [{"k": k, "v": str(random.randint(0, 30))} for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][:200]
            post(f"/api/booklets/{bid}/values", {"changes": ch}, "put")
            db.ex("UPDATE booklets SET status='approved' WHERE id=?", (bid,))
    for tid in ("primary", "secondary", "kg"):
        rows = exporter.collect(tid, "approved")
        wb, n = exporter.export_one(tid, "approved")
        data = exporter.workbook_bytes(wb)
        diffs = exporter.verify_export(data, tid, rows)
        assert not diffs, (tid, diffs[:5])
        ws = openpyxl.load_workbook(io.BytesIO(data)).worksheets[0]
        src = openpyxl.load_workbook(os.path.join(ROOT, exporter.TEMPLATE_FILES[tid])).worksheets[0]
        form = forms.load_form(tid)
        for r in range(1, form["data_start"]):          # الترويسة مطابقة حرفياً
            for col in range(1, form["ncols"] + 1):
                assert ws.cell(r, col).value == src.cell(r, col).value, (tid, r, col)
        assert {str(m) for m in src.merged_cells.ranges if m.min_row < form["data_start"]} <= {str(m) for m in ws.merged_cells.ranges}
        assert ws.max_row == form["data_start"] + n - 1, (ws.max_row, n)
    z = zipfile.ZipFile(exporter.export_zip("approved")[0])
    assert len(z.namelist()) == 5, z.namelist()
    r = c.get("/api/export/all?status=approved", headers=H); assert r.status_code == 200 and r.data[:2] == b"PK"
    r = c.get("/api/export/report", headers=H); assert r.status_code == 200
    r = c.get("/api/export/primary?status=all&ids=1100096", headers=H); assert r.status_code == 200
    # صيغ حيّة
    wb, _ = exporter.export_one("secondary", "approved", formulas=True)
    form = forms.load_form("secondary"); ck = next(k for k, f in form["fields"].items() if f["type"] == "computed")
    assert str(wb.worksheets[0].cell(form["data_start"], form["fields"][ck]["col"]).value).startswith("=")


# ---------------- مزامنة Google (واجهة وهمية بذاكرة) ----------------
class FakeAPI:
    def __init__(self): self.sheets = {}; self.calls = 0; self.fail = None; self.sid = "SID"
    def meta(self, sid):
        return dict(title="t", sheets={t: dict(sheetId=i, title=t, gridProperties=dict(rowCount=1000, columnCount=3000)) for i, t in enumerate(self.sheets)})
    def batch_update(self, sid, reqs):
        for r in reqs:
            if "addSheet" in r: self.sheets.setdefault(r["addSheet"]["properties"]["title"], {})
    def get_column(self, sid, sheet, col="A"):
        d = self.sheets.get(sheet, {}); n = max(d) if d else 0
        return [(d.get(i, [""])[0] if d.get(i) else "") for i in range(1, n + 1)]
    def write_rows(self, sid, data):
        self.calls += 1
        if self.fail:
            e = self.fail; self.fail = None if self.fail_once else self.fail; raise e
        import re
        for rng, vals in data:
            m = re.match(r"'(.+)'!A(\d+):", rng); sh, row = m.group(1), int(m.group(2))
            self.sheets.setdefault(sh, {})[row] = list(vals[0])


@test
def sync_upsert_no_duplicates_and_retry():
    fake = FakeAPI(); fake.fail_once = True; syncer.api_override = fake
    db.set_setting("g_spreadsheet_id", "SID"); db.set_setting("sync_enabled", "1")
    ids = [r["school_id"] for r in db.q("SELECT school_id FROM booklets WHERE status='approved'")]
    assert ids
    n = syncer.enqueue_all(); assert n == len(ids)
    res = syncer.process_batch(); assert res["done"] == len(ids), res
    allids = [v[0] for sh in fake.sheets.values() for k, v in sh.items() if k > 1]
    assert sorted(allids) == sorted(ids) and len(set(allids)) == len(allids)
    # تعديل ثم مزامنة: نفس الصف يتحدث بلا تكرار
    sid = ids[0]; before = sum(len(s) for s in fake.sheets.values())
    syncer.enqueue(sid); syncer.process_batch()
    assert sum(len(s) for s in fake.sheets.values()) == before
    # انقطاع شبكة: تبقى المهمة وتُعاد
    syncer.enqueue(sid); fake.fail = syncer.SyncError("network", "down", True)
    r = syncer.process_batch(); st = db.q1("SELECT status,attempts FROM sync_jobs WHERE school_id=? ORDER BY id DESC", (sid,))
    assert st["status"] == "pending" and st["attempts"] >= 1, dict(st)
    db.ex("UPDATE sync_jobs SET next_try=0"); fake.fail = None
    assert syncer.process_batch()["done"] >= 1
    # خطأ صلاحيات: يفشل مع زر إعادة
    syncer.enqueue(sid); fake.fail = syncer.SyncError("permission", "no access"); fake.fail_once = True
    syncer.process_batch()
    s = syncer.status(); assert s["failed_count"] == 1, s
    fake.fail = None; syncer.retry_failed(); assert syncer.process_batch()["done"] >= 1
    assert syncer.status()["failed_count"] == 0
    # انتهاء الربط: المهام تبقى معلّقة ولا تُعدّ فاشلة
    syncer.enqueue(sid); fake.fail = syncer.SyncError("auth", "expired"); fake.fail_once = True
    syncer.process_batch(); s = syncer.status()
    assert s["failed_count"] == 0 and s["pending"] >= 1 and s["state"] == "needs_reauth", s
    db.set_setting("sync_state", "ok"); fake.fail = None
    assert syncer.process_batch()["done"] >= 1
    syncer.api_override = None


@test
def sync_hook_on_edit_and_approval():
    db.set_setting("sync_enabled", "1")
    db.ex("DELETE FROM sync_jobs")
    sid = "1100096"; bid = db.q1("SELECT id FROM booklets WHERE school_id=?", (sid,))["id"]
    form = forms.load_form("secondary"); k = [k for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][5]
    post(f"/api/booklets/{bid}/values", {"changes": [{"k": k, "v": "11"}]}, "put")
    assert db.q1("SELECT COUNT(*) n FROM sync_jobs WHERE school_id=? AND status='pending'", (sid,))["n"] == 1


# ---------------- القراءة بالذكاء الاصطناعي (مزوّد وهمي) ----------------
class FakeProvider(extraction.Provider):
    name = "fake"; model = "fake-1"
    def __init__(self, read_id, read_name): self.rid, self.rn = read_id, read_name; self.n = 0
    def identify(self, img): return dict(form_title="عدد التلاميذ المستجدين في الصف الاول المتوسط", school_id=self.rid, school_name=self.rn)
    def extract(self, img, sections):
        form = forms.load_form("secondary"); sec = next(s for s in form["sections"] if s["title"].startswith("عدد التلاميذ المستجدين في الصف الاول"))
        ks = [k for k in sec["keys"] if form["fields"][k]["type"] == "number"][:6] if "keys" in sec else []
        if not ks: ks = [k for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][:6]
        vals = {k: str(i + 1) for i, k in enumerate(ks)}
        comp = [k for k, f in form["fields"].items() if f["type"] == "computed" and set(f["sum"]) <= set(ks)]
        return dict(values=vals, alternatives={ks[0]: "9"}, illegible=[ks[1]], paper_totals={comp[0]: "999"} if comp else {}, usage={})


def _make_pdf(path):
    from PIL import Image
    pics = sorted(glob.glob("/tmp/claude-0/-home-claude/7cddd46e-401d-523c-a061-a5e44a275e80/scratchpad/zip1/page_*.jpg"))
    if not pics: return False
    ims = [Image.open(p).convert("RGB") for p in pics[:3]]
    ims[0].save(path, save_all=True, append_images=ims[1:]); return True


@test
def upload_pdf_dedupe_and_rasterize():
    pdf = os.path.join(TMP, "b.pdf")
    if not _make_pdf(pdf): print("  (لا صور عينة؛ تخطّي)"); return
    def up(sid=""):
        return c.post("/api/uploads", data={"file": (open(pdf, "rb"), "b.pdf"), "school_id": sid}, headers=H, content_type="multipart/form-data")
    r = up(); assert r.status_code == 200, r.data
    u = J(r)["uploads"][0]; uid = u["id"]
    for _ in range(60):
        st = db.q1("SELECT status,error FROM uploads WHERE id=?", (uid,))
        if st["status"] in ("ready", "failed"): break
        time.sleep(0.5)
    assert st["status"] == "ready", dict(st)
    assert db.q1("SELECT COUNT(*) n FROM pages WHERE upload_id=?", (uid,))["n"] == 3
    assert J(up())["uploads"][0].get("duplicate"), "رفع نفس الملف مرتين"
    globals()["UID"] = uid


@test
def extraction_wrong_id_is_caught_by_name():
    uid = globals().get("UID")
    if not uid: return
    db.ex("UPDATE uploads SET booklet_id=NULL, school_id=NULL WHERE id=?", (uid,))
    # الرقم المقروء 1100196 (خطأ حقيقي سابق) مع اسم الصفحة الصحيح → لا يُطابق
    extraction.provider_override = FakeProvider("1100196", "اعدادية الشموخ للبنين")
    extraction.run_extraction(uid)
    u = db.q1("SELECT status,school_check FROM uploads WHERE id=?", (uid,))
    sc = json.loads(u["school_check"]) if u["school_check"] else {}
    assert u["status"] == "needs_school", dict(u)
    assert any(x["id"] == "1100096" for x in sc["candidates"]), sc


@test
def extraction_confidence_and_review():
    uid = globals().get("UID")
    if not uid: return
    extraction.provider_override = FakeProvider("1100096", "اعدادية الشموخ للبنين")
    # دفتر جديد خالٍ لتفادي تعارض القيم اليدوية
    db.ex("DELETE FROM uploads WHERE id!=?", (uid,))
    bid = db.q1("SELECT id FROM booklets WHERE school_id='1100096'")["id"]
    db.ex("DELETE FROM vals WHERE booklet_id=? AND src!='master'", (bid,))
    db.ex("UPDATE booklets SET status='draft' WHERE id=?", (bid,))
    db.ex("UPDATE uploads SET booklet_id=NULL, school_id=NULL, status='ready' WHERE id=?", (uid,))
    extraction.run_extraction(uid, 1)
    u = db.q1("SELECT status,error FROM uploads WHERE id=?", (uid,)); assert u["status"] == "done", dict(u)
    ai = db.q("SELECT k,conf,state,alt FROM vals WHERE booklet_id=? AND src='ai'", (bid,)); assert ai
    assert any(r["alt"] and r["conf"] <= 0.55 and r["state"] == "review" for r in ai), "القراءة البديلة تخفض الثقة"
    assert any(r["conf"] == 0.0 or r["state"] == "missing" for r in ai), "غير المقروء"
    assert db.q1("SELECT status FROM booklets WHERE id=?", (bid,))["status"] == "review"
    rv = J(c.get(f"/api/booklets/{bid}/review", headers=H)); assert rv["items"] and rv["counts"]["review"] >= 1
    r = post(f"/api/booklets/{bid}/status", {"status": "approved"}); assert r.status_code == 409, "منخفض الثقة يمنع الاعتماد"
    r = J(post(f"/api/booklets/{bid}/accept", {"all": True})); assert r["accepted"] >= 1
    extraction.provider_override = None


@test
def roles_enforced():
    post("/api/users", {"username": "ro", "name": "ق", "password": "abcdef", "role": "readonly"})
    c2 = app.test_client(); c2.post("/api/login", json={"username": "ro", "password": "abcdef"}, headers=H)
    bid = db.q1("SELECT id FROM booklets LIMIT 1")["id"]
    assert c2.put(f"/api/booklets/{bid}/values", json={"changes": [{"k": "J", "v": "1"}]}, headers=H).status_code == 403
    assert c2.get("/api/users", headers=H).status_code == 403
    assert c2.get("/api/stats", headers=H).status_code == 200


@test
def stats_are_db_based():
    s = J(c.get("/api/stats", headers=H)); assert s["total_schools"] == 2344
    assert s["overall"]["approved"] == db.q1("SELECT COUNT(*) n FROM booklets WHERE status='approved'")["n"]
    assert db.q1("SELECT COUNT(*) n FROM audit_log")["n"] > 5


@test
def page_map_matches_template_and_blank_pdf_rasterizes():
    form = forms.load_form("secondary")
    exp = {5: "عدد التلاميذ المستجدين في الصف الاول", 6: "عدد التلاميذ المسجلين في المرحلة المتوسطة", 8: "عدد الطلبة الراسبين",
           11: "استمارة الابنية", 14: "استمارة المختبرات"}
    for n, t in exp.items():
        secs = extraction.sections_for_page(form, "secondary", str(n), "")
        assert any(x["title"].startswith(t) for x in secs), (n, [x["title"] for x in secs])
    assert len(extraction.sections_for_page(form, "secondary", "9", "")) == 10
    assert extraction.sections_for_page(form, "secondary", None, "عدد الطلبة الراسبين")   # رجوع للعنوان
    out = os.path.join(TMP, "blank"); os.makedirs(out)
    pages = extraction.rasterize(os.path.join(ROOT, "docs", "secondary_blank_2026-2027.pdf"), out)
    assert len(pages) == 16, len(pages)


@test
def each_school_in_exactly_one_file():
    db.ex("INSERT OR IGNORE INTO booklets(school_id,year,template,status) SELECT id,'2026-2027','primary','approved' FROM schools WHERE name LIKE '%مسرع%' LIMIT 3")
    main = {r["sid"] for t in ("primary", "secondary", "kg") for r in exporter.collect(t, "all", group="main")}
    acc = {r["sid"] for r in exporter.collect("primary", "all", group="accel")}
    ah = {r["sid"] for t in ("primary", "secondary", "kg") for r in exporter.collect(t, "all", "اهلي")}
    assert acc and not (main & acc) and not (main & ah) and not (acc & ah)
    assert all("مسرع" in db.q1("SELECT name FROM schools WHERE id=?", (i,))["name"] for i in acc)
    assert c.get("/api/export/accel?status=all", headers=H).status_code == 200
    assert c.get("/api/export/inst", headers=H).status_code == 400
    r = c.get("/api/export/combined?status=all", headers=H); assert r.status_code == 200
    wbc = openpyxl.load_workbook(io.BytesIO(r.data)); assert wbc.sheetnames == ["ملخص", "ابتدائي", "تعليم مسرع", "ثانوي", "رياض أطفال", "ابتدائي-أهلي", "ثانوي-أهلي", "رياض-أهلي"], wbc.sheetnames
    tot = sum(max(0, w.max_row - forms.load_form(t)["data_start"] + 1) for w, t in zip(wbc.worksheets[1:], ["primary", "primary", "secondary", "kg", "primary", "secondary", "kg"]))
    assert tot == db.q1("SELECT COUNT(*) n FROM booklets b JOIN schools s ON s.id=b.school_id WHERE s.template IS NOT NULL")["n"], tot
    info = J(c.get("/api/export-info", headers=H)); assert info["accel"]["incomplete"] + info["accel"]["approved"] >= 3 and info["inst"]["total"] == 31


@test
def forms_6_plus_are_manual_only():
    form = forms.load_form("secondary")
    man = [x["id"] for x in form["sections"] if extraction.is_manual_section(x)]
    auto = [x["id"] for x in form["sections"] if not extraction.is_manual_section(x)]
    assert set(auto) >= {"info", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"}, auto
    assert set(man) >= {f"s{i}" for i in range(9, 26)}, man
    assert not [x for x in extraction.sections_for_page(form, "secondary", "9", "") if not extraction.is_manual_section(x)]


@test
def accounts_activity_and_admin_dashboard():
    # المدير ينشئ موظفاً ويغيّر يوزره وباسورده
    assert post("/api/users", {"username": "emp1", "name": "موظف أول", "password": "pass1234", "role": "entry"}).status_code == 200
    uid = db.q1("SELECT id FROM users WHERE username='emp1'")["id"]
    ce = app.test_client(); assert ce.post("/api/login", json={"username": "emp1", "password": "pass1234"}, headers=H).status_code == 200
    bid = J(post("/api/booklets", {"school_id": "1100096"}))["booklet"]["id"]
    form = forms.load_form("secondary"); ks = [k for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][20:23]
    assert ce.put(f"/api/booklets/{bid}/values", json={"changes": [{"k": k, "v": "4"} for k in ks]}, headers=H).status_code == 200
    a = J(c.get("/api/admin/activity", headers=H)); me = next(u for u in a["users"] if u["id"] == uid)
    assert me["online"] and me["fields_total"] == 3 and me["fields_today"] == 3 and a["online"] >= 2
    assert ce.get("/api/admin/activity", headers=H).status_code == 403           # الموظف لا يرى اللوحة
    e = J(c.get(f"/api/admin/entries?user={uid}", headers=H))["entries"]
    assert e and any(x["name"] == "موظف أول" for x in e[0]["entered_by"])
    f = J(c.get(f"/api/admin/booklet/{bid}/forms", headers=H))["forms"]
    assert any(any(en["name"] == "موظف أول" for en in x["entered"]) for x in f)
    assert any(any(en["name"] == "قائمة المدارس" for en in x["entered"]) for x in f)
    # تغيير اليوزر والباسورد من المدير: القديم يتوقف والجديد يعمل
    assert post(f"/api/users/{uid}", {"username": "emp_new", "password": "newpass99"}, "patch").status_code == 200
    assert ce.get("/api/schools/cache", headers=H).status_code == 401, "جلساته القديمة أُغلقت"
    assert app.test_client().post("/api/login", json={"username": "emp1", "password": "pass1234"}, headers=H).status_code == 401
    assert app.test_client().post("/api/login", json={"username": "emp_new", "password": "newpass99"}, headers=H).status_code == 200
    assert post("/api/users", {"username": "xyz2", "name": "x", "password": "abcdef", "role": "entry"}).status_code == 200
    rr = post(f"/api/users/{uid}", {"username": "xyz2"}, "patch"); assert rr.status_code == 409, (rr.status_code, rr.data)
    # المدير يغيّر يوزره وباسورده بنفسه
    assert post("/api/me/account", {"current_password": "bad", "new_password": "zzzzzz"}).status_code == 403
    r = post("/api/me/account", {"current_password": "pw123456", "username": "boss", "new_password": "newadmin1"}); assert r.status_code == 200, r.data
    assert c.get("/api/me", headers=H).status_code == 200                      # جلسته الحالية تبقى
    assert app.test_client().post("/api/login", json={"username": "boss", "password": "newadmin1"}, headers=H).status_code == 200
    assert app.test_client().post("/api/login", json={"username": "admin", "password": "pw123456"}, headers=H).status_code == 401
    # التعطيل يقطع الدخول فوراً
    db.set_setting("x", "1"); assert post(f"/api/users/{uid}", {"active": False}, "patch").status_code == 200
    assert app.test_client().post("/api/login", json={"username": "emp_new", "password": "newpass99"}, headers=H).status_code == 401


@test
def exports_are_tidy():
    for tid in ("primary", "secondary", "kg"):
        wb, n = exporter.export_one(tid, "all", group="main"); ws = wb.worksheets[0]; form = forms.load_form(tid)
        assert ws.freeze_panes == "C%d" % form["data_start"], (tid, ws.freeze_panes)
        assert ws.auto_filter.ref and ws.auto_filter.ref.startswith("A%d:" % form["hdr_last"]), ws.auto_filter.ref
        assert ws.max_column == form["ncols"], (tid, ws.max_column)
        assert ws.sheet_view.rightToLeft and ws.sheet_properties.tabColor
        # ترتيب الصفوف بترتيب القائمة الرسمية والتسلسل متصل
        seqs = [ws.cell(r, 1).value for r in range(form["data_start"], form["data_start"] + n)]
        assert seqs == list(range(1, n + 1)), seqs[:5]
    z = zipfile.ZipFile(exporter.export_zip("all")[0]); names = z.namelist()
    assert names == sorted(names) and names[0].startswith("1- ") and names[-1].startswith("5- "), names
    wbc = openpyxl.load_workbook(io.BytesIO(c.get("/api/export/combined?status=all", headers=H).data))
    s = wbc["ملخص"]; assert s["A5"].value and s.cell(6, 1).hyperlink is not None


@test
def schools_append_to_category_file_in_order():
    # مدارس ابتدائية جديدة تُعتمد بترتيب معاكس لترتيب القائمة الرسمية: يجب أن تُلحَق بالتسلسل 1، 2، 3 حسب الاعتماد
    db.ex("DELETE FROM vals WHERE booklet_id IN (SELECT b.id FROM booklets b JOIN schools s ON s.id=b.school_id WHERE s.template='primary')")
    db.ex("DELETE FROM booklets WHERE school_id IN (SELECT id FROM schools WHERE template='primary')")
    ids = [r["id"] for r in db.q("SELECT id FROM schools WHERE template='primary' AND ownership='حكومي' AND name NOT LIKE '%مسرع%' ORDER BY seq LIMIT 3")]
    order = [ids[2], ids[0], ids[1]]
    for sid in order:
        bid = J(post("/api/booklets", {"school_id": sid}))["booklet"]["id"]
        rr = post(f"/api/booklets/{bid}/status", {"status": "approved"}); assert rr.status_code == 200, rr.data.decode()
    def rows():
        wb, n = exporter.export_one("primary", "approved", group="main"); ws = wb.worksheets[0]; ds = forms.load_form("primary")["data_start"]
        return [(ws.cell(r, 1).value, str(ws.cell(r, 2).value)) for r in range(ds, ds + n)]
    assert [x[1] for x in rows()] == order and [x[0] for x in rows()] == [1, 2, 3], rows()
    # تعديل مدرسة قديمة لا يغيّر مكانها ولا رقمها
    bid0 = db.q1("SELECT id FROM booklets WHERE school_id=?", (order[0],))["id"]
    k = [k for k, f in forms.load_form("primary")["fields"].items() if f["type"] == "number" and f["col"] > 42][0]
    post(f"/api/booklets/{bid0}/values", {"changes": [{"k": k, "v": "5"}]}, "put")
    post(f"/api/booklets/{bid0}/status", {"status": "approved"})
    assert [x[1] for x in rows()] == order
    # مدرسة رابعة تنضاف في آخر الملف برقم 4
    sid4 = db.q1("SELECT id FROM schools WHERE template='primary' AND ownership='حكومي' AND name NOT LIKE '%مسرع%' ORDER BY seq LIMIT 1 OFFSET 3")["id"]
    b4 = J(post("/api/booklets", {"school_id": sid4}))["booklet"]["id"]; post(f"/api/booklets/{b4}/status", {"status": "approved"})
    assert rows()[-1] == (4, sid4), rows()


@test
def pack_export_import_merge_between_computers():
    import pack
    sid = "1100096"
    form = forms.load_form("secondary"); ks = [k for k, f in form["fields"].items() if f["type"] == "number" and f["col"] > 42][40:46]
    bid = J(post("/api/booklets", {"school_id": sid}))["booklet"]["id"]
    post(f"/api/booklets/{bid}/values", {"changes": [{"k": ks[0], "v": "10"}, {"k": ks[1], "v": "20"}]}, "put")
    r = c.get("/api/pack/export?status=all", headers=H); assert r.status_code == 200 and r.data[:2] == b"PK"
    pk = r.data
    # الجهاز «الرئيسي» = نسخة بلا هذه الأرقام وبقيمة مختلفة لخانة (تعارض) ومدرسة غير موجودة عنده
    db.ex("DELETE FROM vals WHERE booklet_id=? AND k=?", (bid, ks[1]))
    db.ex("UPDATE vals SET v='99', upd_at='2000-01-01 00:00:00' WHERE booklet_id=? AND k=?", (bid, ks[0]))
    other = db.q1("SELECT id FROM schools WHERE template='kg' LIMIT 1")["id"]
    db.ex("DELETE FROM vals WHERE booklet_id IN (SELECT id FROM booklets WHERE school_id=?)", (other,)); db.ex("DELETE FROM booklets WHERE school_id=?", (other,))
    pkg = pack.read_pack(io.BytesIO(pk)); pkg["booklets"].append(dict(school_id=other, template="kg", status="approved", source="manual", updated_at="", values={}))
    rep = pack.merge_pack(pkg, {"id": 1, "username": "admin"}, appmod.ensure_booklet)
    v = {x["k"]: x["v"] for x in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (bid,))}
    assert v[ks[1]] == "20" and v[ks[0]] == "10", v          # الوارد الأحدث يغلب ويُملأ الفارغ
    assert rep["conflicts"] and rep["conflicts"][0]["local"] == "99" and rep["conflicts"][0]["winner"] == "الوارد"
    assert rep["created"] == 1 and db.q1("SELECT status FROM booklets WHERE school_id=?", (other,))["status"] == "approved"
    n_before = db.q1("SELECT COUNT(*) n FROM booklets")["n"]
    rep2 = pack.merge_pack(pkg, {"id": 1, "username": "admin"}, appmod.ensure_booklet)      # إعادة الاستيراد لا تكرر شيئاً
    assert db.q1("SELECT COUNT(*) n FROM booklets")["n"] == n_before and not rep2["conflicts"] and rep2["created"] == 0
    # المحلي الأحدث لا يُستبدل
    db.ex("UPDATE vals SET v='77', upd_at='2999-01-01 00:00:00' WHERE booklet_id=? AND k=?", (bid, ks[0]))
    rep3 = pack.merge_pack(pkg, {"id": 1, "username": "admin"}, appmod.ensure_booklet)
    assert db.q1("SELECT v FROM vals WHERE booklet_id=? AND k=?", (bid, ks[0]))["v"] == "77" and rep3["conflicts"][0]["winner"] == "المحلي"
    # حزمة تالفة تُرفض، والرفع عبر الواجهة
    bad = bytearray(pk); bad[-30] ^= 0xFF
    try: pack.read_pack(io.BytesIO(bytes(bad))); assert False
    except ValueError: pass
    r = c.post("/api/pack/import", data={"file": [(io.BytesIO(pk), "a.sstats"), (io.BytesIO(b"junk"), "b.sstats")]}, headers=H, content_type="multipart/form-data")
    j = J(r); assert r.status_code == 200 and "error" not in j["reports"][0] and j["reports"][1]["error"]


@test
def local_mode_needs_no_login():
    appmod.LOCAL_MODE = True
    try:
        t = app.test_client()
        assert t.get("/api/me", headers=H).status_code == 200 and J(t.get("/api/me", headers=H))["user"]["role"] == "admin"
        assert t.get("/api/schools/cache", headers=H).status_code == 200
    finally:
        appmod.LOCAL_MODE = False
    assert app.test_client().get("/api/me", headers=H).status_code == 401


if __name__ == "__main__":
    bad = [r for r in RESULTS if not r[1]]
    print(f"\n{len(RESULTS) - len(bad)}/{len(RESULTS)} passed")
    sys.exit(1 if bad else 0)
