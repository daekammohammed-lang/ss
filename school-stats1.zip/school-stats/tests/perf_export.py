import os,time,random,json
import db,schools,exporter,forms
db.init(); schools.import_master("data/schools_master.xlsx",None)
form=forms.load_form("primary"); nums=[k for k,f in form["fields"].items() if f["type"]=="number"]
rows=db.q("SELECT id FROM schools WHERE template='primary' AND ownership!='اهلي'")
random.seed(1)
with db.tx():
    for r in rows:
        db.ex("INSERT INTO booklets(school_id,year,status,source,template) VALUES(?,?,?,?,?)",(r["id"],"2026-2027","approved","manual","primary"))
        bid=db.q1("select last_insert_rowid() i")["i"]
        db.conn().executemany("INSERT INTO vals(booklet_id,k,v,src,state) VALUES(?,?,?,?,?)",[(bid,k,str(random.randint(0,40)),"manual","ok") for k in nums])
print("seeded",len(rows),"x",len(nums))
t=time.time(); b=exporter.export_zip("approved"); print("export_zip",round(time.time()-t,1),"s",len(b)//1024,"KB")
t=time.time(); b=exporter.export_zip("approved"); print("again",round(time.time()-t,1),"s")
