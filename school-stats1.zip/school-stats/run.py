"""تشغيل بسيط على أي جهاز: python run.py  ثم افتح http://localhost:8000"""
import os, sys
from app import app, bootstrap

bootstrap()
port = int(os.environ.get("PORT", 8000))
print("\n>>> المنصة تعمل على: http://localhost:%d   (للخروج: Ctrl+C)\n" % port, flush=True)
try:
    from waitress import serve
    serve(app, host=os.environ.get("HOST", "0.0.0.0"), port=port, threads=8)
except ImportError:
    app.run(host=os.environ.get("HOST", "0.0.0.0"), port=port, threaded=True)
