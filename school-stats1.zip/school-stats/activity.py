"""لوحة نشاط الموظفين للمدير: من متصل الآن، كم أدخل كل موظف، ومن أدخل كل كراس وكل استمارة (قسم)."""
import time
from flask import request, jsonify, abort
import db, forms

ONLINE_SECS = 120


def _iso(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else None


def users_activity():
    now = time.time()
    out = []
    for u in db.q("SELECT * FROM users ORDER BY active DESC, id"):
        st = db.q1("SELECT COUNT(*) n, COUNT(DISTINCT booklet_id) b, "
                   "SUM(CASE WHEN date(upd_at)=date('now') THEN 1 ELSE 0 END) t "
                   "FROM vals WHERE upd_by=? AND src='manual'", (u["id"],))
        appr = db.q1("SELECT COUNT(*) n FROM booklets WHERE approved_by=?", (u["id"],))["n"]
        has_session = db.q1("SELECT 1 FROM sessions WHERE user_id=? AND expires>?", (u["id"], now)) is not None
        online = bool(u["active"] and has_session and u["last_seen"] and now - u["last_seen"] <= ONLINE_SECS)
        out.append(dict(id=u["id"], username=u["username"], name=u["name"], role=u["role"], active=bool(u["active"]),
                        online=online, last_seen=_iso(u["last_seen"]), last_seen_ago=int(now - u["last_seen"]) if u["last_seen"] else None,
                        last_login=_iso(u["last_login"]), fields_total=st["n"] or 0, fields_today=st["t"] or 0,
                        booklets=st["b"] or 0, approved=appr))
    return out


def register(app, auth):
    @app.get("/api/admin/activity")
    @auth(["admin"])
    def admin_activity():
        us = users_activity()
        return jsonify(users=us, online=sum(1 for u in us if u["online"]), online_window=ONLINE_SECS,
                       fields_today=sum(u["fields_today"] for u in us))

    @app.get("/api/admin/entries")
    @auth(["admin"])
    def admin_entries():
        """الكراسات مع من أدخلها: ?user=ID لتصفية موظف، ?q= رقم/اسم مدرسة."""
        year = db.get_setting("year", "2026-2027")
        where, args = ["b.year=?"], [year]
        if request.args.get("user"):
            where.append("EXISTS(SELECT 1 FROM vals v WHERE v.booklet_id=b.id AND v.upd_by=? AND v.src='manual')")
            args.append(int(request.args["user"]))
        q = (request.args.get("q") or "").strip()
        if q:
            where.append("(s.id LIKE ? OR s.name LIKE ?)")
            args += [q + "%", "%" + q + "%"]
        limit = min(int(request.args.get("limit", 100)), 500)
        rows = db.q("SELECT b.id, b.status, b.source, b.updated_at, b.approved_at, s.id sid, s.name, s.template, "
                    "cu.name created_by, uu.name updated_by, au.name approved_by FROM booklets b JOIN schools s ON s.id=b.school_id "
                    "LEFT JOIN users cu ON cu.id=b.created_by LEFT JOIN users uu ON uu.id=b.updated_by "
                    "LEFT JOIN users au ON au.id=b.approved_by WHERE " + " AND ".join(where) +
                    " ORDER BY b.updated_at DESC LIMIT ?", args + [limit])
        ids = [r["id"] for r in rows]
        who = {}
        if ids:
            for r in db.q("SELECT v.booklet_id bid, u.name, COUNT(*) n FROM vals v JOIN users u ON u.id=v.upd_by "
                          "WHERE v.src='manual' AND v.booklet_id IN (%s) GROUP BY v.booklet_id, v.upd_by ORDER BY n DESC" %
                          ",".join("?" * len(ids)), ids):
                who.setdefault(r["bid"], []).append(dict(name=r["name"], n=r["n"]))
        return jsonify(entries=[dict(dict(r), entered_by=who.get(r["id"], [])) for r in rows])

    @app.get("/api/admin/booklet/<int:bid>/forms")
    @auth(["admin"])
    def admin_booklet_forms(bid):
        """لكل استمارة (قسم) في الكراس: من أدخلها وكم خانة وآخر وقت."""
        b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
        if not b:
            abort(404)
        form = forms.load_form(b["template"])
        key_sec = {k: s["id"] for s in form["sections"] for k in s["fields"]}
        agg = {}
        for r in db.q("SELECT v.k, v.src, v.upd_at, u.name FROM vals v LEFT JOIN users u ON u.id=v.upd_by "
                      "WHERE v.booklet_id=? AND v.v IS NOT NULL AND v.v!=''", (bid,)):
            sid = key_sec.get(r["k"])
            if not sid:
                continue
            a = agg.setdefault(sid, {})
            who = r["name"] if r["src"] == "manual" else ("الذكاء الاصطناعي" if r["src"] == "ai" else "قائمة المدارس")
            e = a.setdefault(who, dict(name=who, n=0, last=None))
            e["n"] += 1
            e["last"] = max(filter(None, [e["last"], r["upd_at"]]), default=None)
        out = []
        for s in form["sections"]:
            entered = sorted(agg.get(s["id"], {}).values(), key=lambda x: -x["n"])
            inputs = [k for k in s["fields"] if form["fields"][k]["type"] in ("number", "check", "text")]
            out.append(dict(id=s["id"], title=s["title"], total=len(inputs), entered=entered,
                            filled=sum(e["n"] for e in entered)))
        return jsonify(booklet=dict(id=bid, school_id=b["school_id"]), forms=out)
