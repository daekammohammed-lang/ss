@echo off
chcp 65001 >nul
rem نسخة الجهاز الواحد: بلا شاشة دخول، وتعمل على هذا الجهاز فقط، وبلا إنترنت
cd /d "%~dp0"
set LOCAL_MODE=1
set HOST=127.0.0.1
set ADMIN_PASSWORD=local-only-not-exposed
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
start "" http://127.0.0.1:8000
python run.py
pause
