"""منصة الكراسات الإحصائية المدرسية — الخادم.
تصميم المنصة: المهندس ضيغم الفهداوي
"""
import os, io, json, time, secrets, functools, re, hashlib, threading
from flask import Flask, request, jsonify, g, send_from_directory, abort, make_response, send_file
import db, forms, schools

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024
SESSION_TTL = 12 * 3600
ROLES = ("admin", "entry", "reviewer", "readonly")
CREDIT = "تصميم المهندس ضيغم الفهداوي"


# ------------------------------------------------------------------ مصادقة
LOCAL_MODE = os.environ.get("LOCAL_MODE") == "1"   # برنامج على جهاز واحد: بلا شاشة دخول (يُشغَّل على 127.0.0.1 فقط)


def _local_user():
    r = db.q1("SELECT * FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1")
    return dict(id=r["id"], username=r["username"], name=r["name"], role="admin") if r else None


def current_user():
    tok = request.cookies.get("sid")
    if not tok:
        return _local_user() if LOCAL_MODE else None
    r = db.q1("SELECT u.*, s.expires FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?", (tok,))
    if not r or r["expires"] < time.time() or not r["active"]:
        return _local_user() if LOCAL_MODE else None
    now = time.time()
    if not r["last_seen"] or now - r["last_seen"] > 30:       # نبضة نشاط (مرة كل 30 ثانية كحد أقصى)
        db.ex("UPDATE users SET last_seen=? WHERE id=?", (now, r["id"]))
    return dict(id=r["id"], username=r["username"], name=r["name"], role=r["role"])


def auth(roles=None, write=False):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*a, **kw):
            u = current_user()
            if not u:
                return jsonify(error="يجب تسجيل الدخول", code="auth"), 401
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                if request.headers.get("X-Requested-With") != "fetch":
                    return jsonify(error="طلب غير مسموح"), 403
            if write and u["role"] == "readonly":
                return jsonify(error="صلاحية القراءة فقط"), 403
            if roles and u["role"] not in roles:
                return jsonify(error="لا تملك الصلاحية"), 403
            g.user = u
            return fn(*a, **kw)
        return wrapper
    return deco


def ensure_admin():
    if db.q1("SELECT 1 FROM users LIMIT 1"):
        return
    pw = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(9)
    db.ex("INSERT INTO users(username,name,pw_hash,role) VALUES(?,?,?,'admin')",
          ("admin", "مدير النظام", db.hash_pw(pw)))
    print("== تم إنشاء المستخدم admin بكلمة المرور: %s  (غيّرها بعد الدخول) ==" % pw, flush=True)
    try:    # نسخة تبقى متاحة إن فاتتك الرسالة أعلاه
        with open(os.path.join(os.path.dirname(db.DB_PATH), "admin_password.txt"), "w", encoding="utf-8") as f:
            f.write("admin\n%s\n" % pw)
    except OSError:
        pass


@app.post("/api/login")
def login():
    d = request.get_json(force=True, silent=True) or {}
    r = db.q1("SELECT * FROM users WHERE username=? AND active=1", (str(d.get("username", "")).strip(),))
    # تأخير ثابت تقريباً لتقليل التخمين
    if not r or not db.check_pw(str(d.get("password", "")), r["pw_hash"]):
        time.sleep(0.4)
        return jsonify(error="اسم المستخدم أو كلمة المرور غير صحيحة"), 401
    tok = secrets.token_urlsafe(32)
    db.ex("INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)", (tok, r["id"], time.time() + SESSION_TTL))
    db.ex("UPDATE users SET last_login=?, last_seen=? WHERE id=?", (time.time(), time.time(), r["id"]))
    db.ex("DELETE FROM sessions WHERE expires<?", (time.time(),))
    u = dict(id=r["id"], username=r["username"], name=r["name"], role=r["role"])
    db.audit(u, "login")
    resp = jsonify(user=u, credit=CREDIT)
    resp.set_cookie("sid", tok, httponly=True, samesite="Lax", max_age=SESSION_TTL,
                    secure=bool(os.environ.get("COOKIE_SECURE")))
    return resp


@app.post("/api/logout")
@auth()
def logout():
    db.ex("DELETE FROM sessions WHERE token=?", (request.cookies.get("sid"),))
    resp = jsonify(ok=True)
    resp.delete_cookie("sid")
    return resp


@app.get("/api/me")
def me():
    u = current_user()
    return jsonify(user=u, credit=CREDIT) if u else (jsonify(user=None, credit=CREDIT), 401)


# ------------------------------------------------------------------ المستخدمون
@app.get("/api/users")
@auth(["admin"])
def users_list():
    return jsonify(users=[dict(id=r["id"], username=r["username"], name=r["name"], role=r["role"],
                               active=bool(r["active"])) for r in db.q("SELECT * FROM users ORDER BY id")])


@app.post("/api/me/account")
@auth()
def my_account():
    """المستخدم (ومنه المدير) يغيّر اسم دخوله و/أو كلمة مروره بعد إدخال كلمة المرور الحالية."""
    d = request.get_json(force=True)
    r = db.q1("SELECT * FROM users WHERE id=?", (g.user["id"],))
    if not db.check_pw(str(d.get("current_password", "")), r["pw_hash"]):
        time.sleep(0.4)
        return jsonify(error="كلمة المرور الحالية غير صحيحة"), 403
    un = str(d.get("username") or "").strip()
    if un and un != r["username"]:
        if len(un) < 3 or re.search(r"\s", un):
            return jsonify(error="اسم المستخدم 3 أحرف على الأقل وبلا مسافات"), 400
        if db.q1("SELECT 1 FROM users WHERE username=? AND id!=?", (un, r["id"])):
            return jsonify(error="اسم المستخدم مستعمل"), 409
        db.ex("UPDATE users SET username=? WHERE id=?", (un, r["id"]))
    npw = str(d.get("new_password") or "")
    if npw:
        if len(npw) < 6:
            return jsonify(error="كلمة المرور الجديدة 6 أحرف على الأقل"), 400
        db.ex("UPDATE users SET pw_hash=? WHERE id=?", (db.hash_pw(npw), r["id"]))
        db.ex("DELETE FROM sessions WHERE user_id=? AND token!=?", (r["id"], request.cookies.get("sid")))
    db.audit(g.user, "account.update", detail=dict(username=bool(un), password=bool(npw)))
    return jsonify(ok=True, user=dict(id=r["id"], username=un or r["username"], name=r["name"], role=r["role"]))


@app.post("/api/ping")
@auth()
def ping():
    return jsonify(ok=True)


@app.post("/api/users")
@auth(["admin"])
def users_create():
    d = request.get_json(force=True)
    un, name, pw, role = (str(d.get(k, "")).strip() for k in ("username", "name", "password", "role"))
    if not un or not name or len(pw) < 6 or role not in ROLES:
        return jsonify(error="بيانات ناقصة (كلمة المرور 6 أحرف على الأقل)"), 400
    if db.q1("SELECT 1 FROM users WHERE username=?", (un,)):
        return jsonify(error="اسم المستخدم موجود"), 409
    db.ex("INSERT INTO users(username,name,pw_hash,role) VALUES(?,?,?,?)", (un, name, db.hash_pw(pw), role))
    db.audit(g.user, "user.create", detail=dict(username=un, role=role))
    return jsonify(ok=True)


@app.patch("/api/users/<int:uid>")
@auth(["admin"])
def users_update(uid):
    d = request.get_json(force=True)
    r = db.q1("SELECT * FROM users WHERE id=?", (uid,))
    if not r:
        abort(404)
    if "username" in d:
        un = str(d["username"]).strip()
        if not un or len(un) < 3 or re.search(r"\s", un):
            return jsonify(error="اسم المستخدم 3 أحرف على الأقل وبلا مسافات"), 400
        if db.q1("SELECT 1 FROM users WHERE username=? AND id!=?", (un, uid)):
            return jsonify(error="اسم المستخدم مستعمل"), 409
        if un != r["username"]:
            db.ex("UPDATE users SET username=? WHERE id=?", (un, uid))
    if "name" in d and str(d["name"]).strip():
        db.ex("UPDATE users SET name=? WHERE id=?", (str(d["name"]).strip(), uid))
    if "role" in d and d["role"] in ROLES:
        if uid == g.user["id"] and d["role"] != "admin":
            return jsonify(error="لا يمكنك إزالة صلاحية المدير عن نفسك"), 400
        db.ex("UPDATE users SET role=? WHERE id=?", (d["role"], uid))
    if "active" in d:
        if uid == g.user["id"] and not d["active"]:
            return jsonify(error="لا يمكنك تعطيل نفسك"), 400
        db.ex("UPDATE users SET active=? WHERE id=?", (1 if d["active"] else 0, uid))
    if d.get("password"):
        if len(d["password"]) < 6:
            return jsonify(error="كلمة المرور قصيرة"), 400
        db.ex("UPDATE users SET pw_hash=? WHERE id=?", (db.hash_pw(d["password"]), uid))
        db.ex("DELETE FROM sessions WHERE user_id=?" + (" AND token!=?" if uid == g.user["id"] else ""),
              (uid, request.cookies.get("sid")) if uid == g.user["id"] else (uid,))
    if "active" in d and not d["active"]:
        db.ex("DELETE FROM sessions WHERE user_id=?", (uid,))
    db.audit(g.user, "user.update", detail=dict(id=uid, fields=[k for k in d if k != "password"]))
    return jsonify(ok=True)


# ------------------------------------------------------------------ المدارس
@app.get("/api/schools/cache")
@auth()
def schools_cache():
    """قائمة مضغوطة تُخزَّن في المتصفح للبحث السريع دون اتصال."""
    rows = db.q("SELECT s.id,s.name,s.category,s.ownership,s.template,s.gender,b.status,b.id AS bid "
                "FROM schools s LEFT JOIN booklets b ON b.school_id=s.id AND b.year=? ORDER BY s.id",
                (db.get_setting("year", "2026-2027"),))
    return jsonify(rows=[[r["id"], r["name"], r["category"], r["ownership"], r["template"], r["gender"],
                          r["status"], r["bid"]] for r in rows], ts=time.time())


@app.get("/api/schools")
@auth()
def schools_search():
    q = request.args.get("q", "")
    lim = min(int(request.args.get("limit", 30)), 200)
    return jsonify(results=schools.search(q, lim, request.args.get("category"), request.args.get("template")))


@app.get("/api/schools/<sid>")
@auth()
def school_get(sid):
    sid = schools.norm_ar(sid)
    r = db.q1("SELECT * FROM schools WHERE id=?", (sid,))
    if not r:
        return jsonify(error="الرقم الإحصائي %s غير موجود في قائمة المدارس" % sid, code="not_found"), 404
    d = schools.school_dict(r)
    b = db.q1("SELECT id,status,source,rev FROM booklets WHERE school_id=? AND year=?",
              (sid, db.get_setting("year", "2026-2027")))
    d["booklet"] = dict(b) if b else None
    d["template_title"] = forms.TEMPLATE_TITLES.get(r["template"])
    return jsonify(d)


@app.post("/api/schools/import")
@auth(["admin"])
def schools_import():
    f = request.files.get("file")
    if not f:
        return jsonify(error="لم يُرفع ملف"), 400
    tmp = os.path.join(BASE, "data", "_import_%s.xlsx" % secrets.token_hex(4))
    f.save(tmp)
    try:
        res = schools.import_master(tmp, g.user)
    except Exception as e:
        return jsonify(error="فشل الاستيراد: %s" % e), 400
    finally:
        os.remove(tmp)
    return jsonify(res)


# ------------------------------------------------------------------ الاستمارات والكراسات
@app.get("/api/forms/<tid>")
@auth()
def form_get(tid):
    if tid not in forms.TEMPLATE_IDS:
        abort(404)
    resp = jsonify(forms.load_form(tid))
    resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


def booklet_values(bid):
    out = {}
    for r in db.q("SELECT k,v,src,conf,state,alt,paper,ver FROM vals WHERE booklet_id=?", (bid,)):
        out[r["k"]] = dict(v=r["v"], src=r["src"], conf=r["conf"], state=r["state"], alt=r["alt"],
                           paper=r["paper"], ver=r["ver"])
    return out


def booklet_payload(b):
    form = forms.load_form(b["template"])
    vals = booklet_values(b["id"])
    flat = {k: x["v"] for k, x in vals.items()}
    paper = {k: x["paper"] for k, x in vals.items() if x["paper"] not in (None, "")}
    s = db.q1("SELECT * FROM schools WHERE id=?", (b["school_id"],))
    return dict(booklet=dict(id=b["id"], school_id=b["school_id"], year=b["year"], template=b["template"],
                             status=b["status"], source=b["source"], rev=b["rev"], updated_at=b["updated_at"]),
                school=schools.school_dict(s), values=vals,
                computed=forms.compute(form, flat), issues=forms.validate(form, flat, paper),
                completion=forms.completion(form, flat))


def ensure_booklet(s, user):
    """يعيد كراس المدرسة للسنة الحالية وينشئه (مع تعبئة المعلومات العامة من القائمة الرسمية) إن لم يوجد."""
    sid, year = s["id"], db.get_setting("year", "2026-2027")
    b = db.q1("SELECT * FROM booklets WHERE school_id=? AND year=?", (sid, year))
    if not b:
        form = forms.load_form(s["template"])
        uid = user["id"] if user else None
        with db.tx():
            b0 = db.q1("SELECT * FROM booklets WHERE school_id=? AND year=?", (sid, year))
            if not b0:
                cur = db.ex("INSERT INTO booklets(school_id,year,template,created_by,updated_by) VALUES(?,?,?,?,?)",
                            (sid, year, s["template"], uid, uid))
                bid = cur.lastrowid
                pre = json.loads(s["prefill"] or "{}")
                pre["B"] = sid  # الرقم الإحصائي
                for k, v in pre.items():
                    f = form["fields"].get(k)
                    if f and f["type"] not in ("computed", "seq") and v not in (None, ""):
                        db.ex("INSERT OR IGNORE INTO vals(booklet_id,k,v,src,upd_by) VALUES(?,?,?,'master',?)",
                              (bid, k, str(v), uid))
                db.audit(user, "booklet.create", sid, bid, dict(template=s["template"]))
        b = db.q1("SELECT * FROM booklets WHERE school_id=? AND year=?", (sid, year))
    return b


@app.post("/api/booklets")
@auth(write=True)
def booklet_open():
    """يفتح كراس المدرسة أو ينشئه (مرة واحدة لكل مدرسة وسنة)."""
    d = request.get_json(force=True)
    sid = schools.norm_ar(str(d.get("school_id", "")))
    s = db.q1("SELECT * FROM schools WHERE id=?", (sid,))
    if not s:
        return jsonify(error="الرقم الإحصائي %s غير موجود" % sid, code="not_found"), 404
    if not s["template"]:
        return jsonify(error="لا يوجد قالب إدخال لهذا النوع (%s) بعد" % s["category"], code="no_template"), 422
    b = ensure_booklet(s, g.user)
    return jsonify(booklet_payload(b))


@app.get("/api/booklets/<int:bid>")
@auth()
def booklet_get(bid):
    b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
    if not b:
        abort(404)
    return jsonify(booklet_payload(b))


def _sync_hook(b, reason):
    try:
        import syncer
        syncer.enqueue(b["school_id"], b["id"], reason)
    except Exception as e:  # المزامنة اختيارية ولا تعطّل الإدخال أبداً
        app.logger.warning("sync enqueue failed: %s", e)


@app.put("/api/booklets/<int:bid>/values")
@auth(write=True)
def booklet_put(bid):
    d = request.get_json(force=True)
    changes = d.get("changes") or []
    b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
    if not b:
        abort(404)
    if b["status"] == "approved" and g.user["role"] not in ("admin", "reviewer") \
            and not db.get_setting("entry_can_edit_approved"):
        return jsonify(error="الكراس معتمد؛ التعديل للمراجع أو المدير", code="locked"), 423
    form = forms.load_form(b["template"])
    applied, conflicts, changed_log = {}, [], []
    with db.tx():
        for ch in changes:
            k, v = ch.get("k"), ch.get("v")
            f = form["fields"].get(k)
            if f is None or f["type"] in ("computed", "seq"):
                continue
            v = None if v is None else str(v).strip()
            if v is not None and f["type"] == "number":
                n = forms.to_num(v)
                v = str(n) if n is not None else v        # توحيد الأرقام العربية-الهندية
            cur = db.q1("SELECT v,ver,src FROM vals WHERE booklet_id=? AND k=?", (bid, k))
            if cur and ch.get("ver") is not None and cur["ver"] != ch["ver"] and (cur["v"] or "") != (v or ""):
                conflicts.append(dict(k=k, server_v=cur["v"], server_ver=cur["ver"]))
                continue
            if cur and (cur["v"] or "") == (v or "") and cur["src"] != "ai":
                applied[k] = cur["ver"]
                continue
            alt = cur["v"] if cur and cur["src"] == "ai" else None
            if cur:
                db.ex("UPDATE vals SET v=?, src='manual', state='ok', conf=NULL, ver=ver+1, upd_by=?, "
                      "upd_at=CURRENT_TIMESTAMP, alt=COALESCE(alt, ?) WHERE booklet_id=? AND k=?",
                      (v, g.user["id"], alt, bid, k))
                applied[k] = cur["ver"] + 1
            else:
                db.ex("INSERT INTO vals(booklet_id,k,v,src,upd_by) VALUES(?,?,?,'manual',?)", (bid, k, v, g.user["id"]))
                applied[k] = 1
            changed_log.append([k, cur["v"] if cur else None, v])
        if changed_log:
            has_ai = db.q1("SELECT 1 FROM vals WHERE booklet_id=? AND src='ai'", (bid,))
            src = b["source"]
            if src == "ai":
                src = "hybrid"
            db.ex("UPDATE booklets SET rev=rev+1, updated_by=?, updated_at=CURRENT_TIMESTAMP, source=? WHERE id=?",
                  (g.user["id"], src, bid))
            db.audit(g.user, "booklet.edit", b["school_id"], bid, dict(changes=changed_log[:60], n=len(changed_log)))
    b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
    if changed_log and b["status"] == "approved":
        _sync_hook(b, "edit")
    flat = {r["k"]: r["v"] for r in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (bid,))}
    return jsonify(applied=applied, conflicts=conflicts, rev=b["rev"], computed=forms.compute(form, flat),
                   issues=forms.validate(form, flat))


@app.post("/api/booklets/<int:bid>/status")
@auth(write=True)
def booklet_status(bid):
    d = request.get_json(force=True)
    to = d.get("status")
    b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
    if not b or to not in ("draft", "review", "approved"):
        abort(400)
    role = g.user["role"]
    needs_review = db.get_setting("require_review") == "1"
    if to == "approved" and needs_review and role not in ("admin", "reviewer"):
        to = "review"
    if b["status"] == "approved" and to != "approved" and role not in ("admin", "reviewer"):
        return jsonify(error="إعادة فتح الكراس المعتمد للمراجع أو المدير"), 403
    if to == "approved":
        form = forms.load_form(b["template"])
        vals = booklet_values(bid)
        flat = {k: x["v"] for k, x in vals.items()}
        paper = {k: x["paper"] for k, x in vals.items() if x["paper"]}
        errs = [(k, i) for k, lst in forms.validate(form, flat, paper).items() for i in lst if i["level"] == "error"]
        pend = [k for k, x in vals.items() if x["state"] == "review" and (x["conf"] is None or x["conf"] < 0.6)]
        if (errs or pend) and not (d.get("force") and role in ("admin", "reviewer")):
            return jsonify(error="لا يمكن الاعتماد: %d خطأ و%d حقل بانتظار المراجعة" % (len(errs), len(pend)),
                           code="blocked", errors=[k for k, _ in errs][:50], pending=pend[:50]), 409
    db.ex("UPDATE booklets SET status=?, updated_at=CURRENT_TIMESTAMP, approved_by=?, approved_at=? WHERE id=?",
          (to, g.user["id"] if to == "approved" else None, time.strftime("%Y-%m-%d %H:%M:%S") if to == "approved" else None, bid))
    if to == "approved":      # أول اعتماد: تُلحَق المدرسة بآخر الملف العام للفئة برقم تسلسل جديد (لا يتغير عند التعديل)
        db.ex("UPDATE booklets SET master_seq=(SELECT COALESCE(MAX(master_seq),0)+1 FROM booklets) WHERE id=? AND master_seq IS NULL", (bid,))
    db.audit(g.user, "booklet.status", b["school_id"], bid, dict(from_=b["status"], to=to))
    b = db.q1("SELECT * FROM booklets WHERE id=?", (bid,))
    if to == "approved":
        _sync_hook(b, "approve")
    return jsonify(status=to)


@app.get("/api/next")
@auth()
def next_school():
    after = request.args.get("after", "")
    year = db.get_setting("year", "2026-2027")
    sql = ("SELECT s.id,s.name,s.category FROM schools s LEFT JOIN booklets b ON b.school_id=s.id AND b.year=? "
           "WHERE s.template IS NOT NULL AND (b.id IS NULL OR b.status!='approved')")
    args = [year]
    for k, col in (("template", "s.template"), ("category", "s.category")):
        if request.args.get(k):
            sql += " AND %s=?" % col
            args.append(request.args[k])
    if request.args.get("ownership"):
        sql += " AND s.ownership=?"
        args.append(request.args["ownership"])
    r = db.q1(sql + " AND s.id>? ORDER BY s.id LIMIT 1", args + [after]) or db.q1(sql + " ORDER BY s.id LIMIT 1", args)
    return jsonify(school=dict(r) if r else None)


@app.get("/api/pending")
@auth()
def pending_list():
    """المدارس غير المكتملة (قائمة الإدخال التالي)."""
    year = db.get_setting("year", "2026-2027")
    sql = ("SELECT s.id,s.name,s.category,s.ownership,b.status FROM schools s LEFT JOIN booklets b "
           "ON b.school_id=s.id AND b.year=? WHERE s.template IS NOT NULL AND (b.id IS NULL OR b.status!='approved')")
    args = [year]
    if request.args.get("template"):
        sql += " AND s.template=?"
        args.append(request.args["template"])
    if request.args.get("status") == "started":
        sql += " AND b.id IS NOT NULL"
    rows = db.q(sql + " ORDER BY s.id LIMIT ?", args + [min(int(request.args.get("limit", 100)), 500)])
    return jsonify(rows=[dict(r) for r in rows])


# ------------------------------------------------------------------ الإحصائيات
@app.get("/api/stats")
@auth()
def stats():
    year = db.get_setting("year", "2026-2027")
    base = ("FROM schools s LEFT JOIN booklets b ON b.school_id=s.id AND b.year=? WHERE s.template IS NOT NULL")

    def block(cond="", args=()):
        r = db.q1("SELECT COUNT(*) total, COUNT(b.id) started, "
                  "SUM(b.status='approved') approved, SUM(b.status='review') review, "
                  "SUM(b.status='draft') draft " + base + cond, (year,) + tuple(args))
        tot, ap = r["total"] or 0, r["approved"] or 0
        return dict(total=tot, started=r["started"] or 0, approved=ap, review=r["review"] or 0,
                    draft=r["draft"] or 0, pct=round(100.0 * ap / tot, 1) if tot else 0.0)
    overall = block()
    cats = dict(
        primary=block(" AND s.template='primary'"), secondary=block(" AND s.template='secondary'"),
        ahli=block(" AND s.ownership='اهلي'"), kg=block(" AND s.template='kg'"))
    src = db.q1("SELECT SUM(source='manual') manual, SUM(source='ai') ai, SUM(source='hybrid') hybrid "
                "FROM booklets WHERE year=?", (year,))
    f = db.q1("SELECT COUNT(*) n, SUM(src='ai') ai, SUM(src='manual') manual, SUM(state='review') review, "
              "SUM(src='manual' AND alt IS NOT NULL) corrected FROM vals v JOIN booklets b ON b.id=v.booklet_id "
              "WHERE b.year=? AND v.src!='master'", (year,))
    pages = db.q1("SELECT COUNT(*) n FROM pages")["n"]
    uploads = db.q1("SELECT COUNT(*) n FROM uploads")["n"]
    ai_books = db.q1("SELECT COUNT(DISTINCT booklet_id) n FROM extraction_runs WHERE status='done'")["n"]
    withproblems = db.q1("SELECT COUNT(DISTINCT booklet_id) n FROM vals WHERE state='review' AND booklet_id IN "
                         "(SELECT id FROM booklets WHERE status!='approved')")["n"]
    no_tpl = db.q1("SELECT COUNT(*) n FROM schools WHERE template IS NULL")["n"]
    return jsonify(year=year, overall=overall, categories=cats, no_template=no_tpl,
                   total_schools=db.q1("SELECT COUNT(*) n FROM schools")["n"],
                   received=uploads, ai_read=ai_books, manual=(src["manual"] or 0), hybrid=(src["hybrid"] or 0),
                   ai_source=(src["ai"] or 0), with_issues=withproblems, remaining=overall["total"] - overall["approved"],
                   fields=dict(entered=f["n"] or 0, ai=f["ai"] or 0, manual=f["manual"] or 0,
                               needs_review=f["review"] or 0, ai_corrected=f["corrected"] or 0),
                   pages_read=pages)


@app.get("/api/audit")
@auth(["admin", "reviewer"])
def audit_list():
    sql, args = "SELECT * FROM audit_log WHERE 1=1", []
    if request.args.get("booklet"):
        sql += " AND booklet_id=?"
        args.append(int(request.args["booklet"]))
    if request.args.get("school"):
        sql += " AND school_id=?"
        args.append(request.args["school"])
    rows = db.q(sql + " ORDER BY id DESC LIMIT ?", args + [min(int(request.args.get("limit", 100)), 500)])
    return jsonify(rows=[dict(r) for r in rows])


@app.get("/api/settings")
@auth()
def settings_get():
    return jsonify(year=db.get_setting("year", "2026-2027"), require_review=db.get_setting("require_review") == "1",
                   entry_can_edit_approved=bool(db.get_setting("entry_can_edit_approved")),
                   ai_enabled=bool(os.environ.get("ANTHROPIC_API_KEY")), local_mode=LOCAL_MODE)


@app.put("/api/settings")
@auth(["admin"])
def settings_put():
    d = request.get_json(force=True)
    if "year" in d:
        db.set_setting("year", str(d["year"]))
    if "require_review" in d:
        db.set_setting("require_review", "1" if d["require_review"] else "0")
    if "entry_can_edit_approved" in d:
        db.set_setting("entry_can_edit_approved", "1" if d["entry_can_edit_approved"] else "")
    db.audit(g.user, "settings.update", detail=d)
    return jsonify(ok=True)


# ------------------------------------------------------------------ الواجهة
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/healthz")
def healthz():
    return jsonify(ok=True)


# وحدات إضافية (تصدير، مزامنة، رفع وقراءة)
import exporter, syncer, extraction, activity, pack  # noqa: E402
exporter.register(app, auth)
syncer.register(app, auth)
extraction.register(app, auth)
activity.register(app, auth)
pack.register(app, auth)


def bootstrap():
    db.init()
    ensure_admin()
    if not db.q1("SELECT 1 FROM schools LIMIT 1"):
        p = os.path.join(BASE, "data", "schools_master.xlsx")
        if os.path.exists(p):
            print("استيراد قائمة المدارس…", schools.import_master(p), flush=True)
    syncer.start_worker()


if __name__ == "__main__":
    bootstrap()
    app.run(host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", 8000)), threaded=True)
