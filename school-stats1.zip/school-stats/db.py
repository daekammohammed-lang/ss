"""طبقة قاعدة البيانات (SQLite بنمط WAL).

القاعدة الداخلية هي المصدر الوحيد للحقيقة. SQLite كافية لعدة مستخدمين وبضع مئات من الكراسات؛
ويمكن نقل المخطط حرفياً إلى PostgreSQL عند الحاجة (استعلامات قياسية فقط).
"""
import os, sqlite3, json, threading, time, hashlib, hmac, secrets

DB_PATH = os.environ.get("SCHOOLSTATS_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "app.db"))
_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, pw_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'entry',            -- admin | entry | reviewer | readonly
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS schools(
  id TEXT PRIMARY KEY,                           -- الرقم الإحصائي (مفتاح فريد)
  seq INTEGER, name TEXT NOT NULL, name_norm TEXT NOT NULL,
  gender TEXT, env TEXT, category TEXT, independence TEXT, ownership TEXT, shift TEXT,
  template TEXT,                                  -- primary | secondary | kg | NULL (لا قالب)
  details TEXT NOT NULL DEFAULT '{}', prefill TEXT NOT NULL DEFAULT '{}');
CREATE INDEX IF NOT EXISTS idx_schools_name ON schools(name_norm);
CREATE INDEX IF NOT EXISTS idx_schools_tpl ON schools(template, ownership);
CREATE TABLE IF NOT EXISTS booklets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id TEXT NOT NULL REFERENCES schools(id), year TEXT NOT NULL DEFAULT '2026-2027',
  template TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft',   -- draft | review | approved
  source TEXT NOT NULL DEFAULT 'manual',                           -- manual | ai | hybrid
  rev INTEGER NOT NULL DEFAULT 0, created_by INTEGER, updated_by INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  approved_by INTEGER, approved_at TEXT, UNIQUE(school_id, year));
CREATE TABLE IF NOT EXISTS vals(
  booklet_id INTEGER NOT NULL REFERENCES booklets(id) ON DELETE CASCADE,
  k TEXT NOT NULL, v TEXT, src TEXT NOT NULL DEFAULT 'manual',    -- manual | master | ai
  conf REAL, state TEXT NOT NULL DEFAULT 'ok',                    -- ok | review | missing
  alt TEXT, paper TEXT, page INTEGER, ver INTEGER NOT NULL DEFAULT 1, upd_by INTEGER,
  upd_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(booklet_id, k));
CREATE TABLE IF NOT EXISTS uploads(
  id INTEGER PRIMARY KEY AUTOINCREMENT, booklet_id INTEGER, filename TEXT, sha256 TEXT UNIQUE,
  pages INTEGER DEFAULT 0, status TEXT DEFAULT 'new', error TEXT, created_by INTEGER,
  school_id TEXT, progress REAL DEFAULT 0, school_check TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, upload_id INTEGER NOT NULL, n INTEGER NOT NULL, path TEXT NOT NULL,
  form_hint TEXT, UNIQUE(upload_id, n));
CREATE TABLE IF NOT EXISTS extraction_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, upload_id INTEGER, booklet_id INTEGER, provider TEXT, model TEXT,
  status TEXT, fields_read INTEGER DEFAULT 0, fields_review INTEGER DEFAULT 0, error TEXT, raw TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT DEFAULT CURRENT_TIMESTAMP, user_id INTEGER, username TEXT,
  action TEXT NOT NULL, school_id TEXT, booklet_id INTEGER, detail TEXT);
CREATE INDEX IF NOT EXISTS idx_audit_booklet ON audit_log(booklet_id);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS sync_jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, school_id TEXT NOT NULL, booklet_id INTEGER, sheet TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',            -- pending | done | failed
  attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, error_kind TEXT, next_try REAL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX IF NOT EXISTS idx_sync_open ON sync_jobs(school_id, sheet) WHERE status IN ('pending','failed');
CREATE TABLE IF NOT EXISTS sync_rows(
  sheet TEXT NOT NULL, school_id TEXT NOT NULL, row INTEGER NOT NULL, synced_at TEXT, PRIMARY KEY(sheet, school_id));
"""


def conn():
    c = getattr(_local, "c", None)
    if c is None or getattr(_local, "path", None) != DB_PATH:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        c = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA foreign_keys=ON")
        _local.c, _local.path = c, DB_PATH
    return c


def init():
    c = conn()
    c.executescript(SCHEMA)
    cols = {r["name"] for r in c.execute("PRAGMA table_info(users)")}
    bcols = {r["name"] for r in c.execute("PRAGMA table_info(booklets)")}
    if "master_seq" not in bcols:                     # ترتيب الإضافة إلى الملف العام: يُمنح عند أول اعتماد ويبقى ثابتاً
        c.execute("ALTER TABLE booklets ADD COLUMN master_seq INTEGER")
        c.execute("UPDATE booklets SET master_seq = (SELECT COUNT(*) FROM booklets b2 WHERE b2.status='approved' AND b2.id<=booklets.id) "
                  "WHERE status='approved'")
    for col in ("last_seen", "last_login"):           # آخر نشاط / آخر دخول (epoch)
        if col not in cols:
            c.execute("ALTER TABLE users ADD COLUMN %s REAL" % col)


def q(sql, args=()):
    return conn().execute(sql, args).fetchall()


def q1(sql, args=()):
    return conn().execute(sql, args).fetchone()


def ex(sql, args=()):
    return conn().execute(sql, args)


class tx:
    """معاملة صريحة: with tx(): ... (BEGIN IMMEDIATE لتسلسل الكتابة)."""
    def __enter__(self):
        conn().execute("BEGIN IMMEDIATE")
        return self

    def __exit__(self, et, ev, tb):
        conn().execute("ROLLBACK" if et else "COMMIT")
        return False


# ------------------------------------------------------------------ كلمات المرور
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1)
    return salt.hex() + "$" + h.hex()


def check_pw(pw, stored):
    try:
        salt, h = stored.split("$")
        c = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1)
        return hmac.compare_digest(c.hex(), h)
    except Exception:
        return False


def audit(user, action, school_id=None, booklet_id=None, detail=None):
    ex("INSERT INTO audit_log(user_id,username,action,school_id,booklet_id,detail) VALUES(?,?,?,?,?,?)",
       (user["id"] if user else None, user["username"] if user else None, action, school_id, booklet_id,
        json.dumps(detail, ensure_ascii=False) if detail is not None else None))


def get_setting(k, default=None):
    r = q1("SELECT v FROM settings WHERE k=?", (k,))
    return r["v"] if r else default


def set_setting(k, v):
    ex("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))
