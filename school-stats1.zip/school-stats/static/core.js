/* منصة الكراسات الإحصائية المدرسية — النواة: شبكة، تخزين محلي، حفظ تلقائي مع طابور دون اتصال.
   تصميم المنصة: المهندس ضيغم الفهداوي */
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const EAST = '٠١٢٣٤٥٦٧٨٩', PERS = '۰۱۲۳۴۵۶۷۸۹';
const normDigits = s => String(s ?? '').replace(/[٠-٩۰-۹]/g, d => { const i = EAST.indexOf(d); return i >= 0 ? i : PERS.indexOf(d); });
const normAr = s => normDigits(String(s ?? '')).replace(/ـ/g, '').replace(/[ً-ٰٟ]/g, '')
  .replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/\s+/g, ' ').trim().toLowerCase();
const nf = n => (n ?? '') === '' ? '' : new Intl.NumberFormat('en-US').format(n);

function toast(msg, bad) {
  const d = document.createElement('div'); d.textContent = msg; if (bad) d.className = 'bad';
  $('#toast').appendChild(d); setTimeout(() => d.remove(), bad ? 6000 : 3200);
}

/* ---------- تخزين محلي (IndexedDB مع احتياط localStorage) ---------- */
const kv = (() => {
  let dbp = null, broken = false;
  const open = () => dbp ||= new Promise((res, rej) => {
    try {
      const r = indexedDB.open('schoolstats', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    } catch (e) { rej(e); }
  });
  const tx = async (mode, fn) => {
    const db = await open();
    return new Promise((res, rej) => { const t = db.transaction('kv', mode); const q = fn(t.objectStore('kv')); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); });
  };
  return {
    async get(k) { if (!broken) { try { return await tx('readonly', s => s.get(k)); } catch { broken = true; } } try { return JSON.parse(localStorage.getItem('kv:' + k)); } catch { return undefined; } },
    async set(k, v) { if (!broken) { try { return await tx('readwrite', s => s.put(v, k)); } catch { broken = true; } } try { localStorage.setItem('kv:' + k, JSON.stringify(v)); } catch { } },
    async del(k) { if (!broken) { try { return await tx('readwrite', s => s.delete(k)); } catch { broken = true; } } try { localStorage.removeItem('kv:' + k); } catch { } },
  };
})();

/* ---------- الشبكة ---------- */
const net = { online: navigator.onLine, listeners: new Set() };
addEventListener('online', () => { net.online = true; net.listeners.forEach(f => f()); });
addEventListener('offline', () => { net.online = false; net.listeners.forEach(f => f()); });

async function api(path, opt = {}) {
  const o = { credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' }, ...opt };
  if (opt.json !== undefined) { o.method = o.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opt.json); delete o.json; }
  let r;
  try { r = await fetch(path, o); } catch (e) { const err = new Error('لا يوجد اتصال بالخادم'); err.offline = true; throw err; }
  if (opt.raw) return r;
  let data = null; try { data = await r.json(); } catch { }
  if (r.status === 401 && !path.includes('/login') && !path.includes('/api/me')) { App.user = null; location.hash = '#/login'; }
  if (!r.ok) { const err = new Error((data && data.error) || ('خطأ ' + r.status)); err.status = r.status; err.data = data; throw err; }
  return data;
}

/* ---------- قائمة المدارس (بحث فوري ودون اتصال) ---------- */
const Schools = {
  rows: [], loaded: false,
  async load(force) {
    if (!force && this.loaded) return;
    try { const j = await api('/api/schools/cache'); this.rows = j.rows.map(r => ({ id: r[0], name: r[1], category: r[2], ownership: r[3], template: r[4], gender: r[5], status: r[6], bid: r[7], n: normAr(r[1]) })); await kv.set('schools', j.rows); }
    catch (e) { const c = await kv.get('schools'); if (c) this.rows = c.map(r => ({ id: r[0], name: r[1], category: r[2], ownership: r[3], template: r[4], gender: r[5], status: r[6], bid: r[7], n: normAr(r[1]) })); else throw e; }
    this.loaded = true;
  },
  get(id) { return this.rows.find(r => r.id === id); },
  search(q, limit = 12) {
    q = normAr(q); if (!q) return [];
    const out = [];
    if (/^\d+$/.test(q)) { for (const r of this.rows) { if (r.id.startsWith(q)) { out.push(r); if (out.length >= limit) break; } } return out; }
    const toks = q.split(' ');
    for (const r of this.rows) { if (toks.every(t => r.n.includes(t))) { out.push(r); if (out.length >= limit) break; } }
    return out;
  },
};

/* ---------- الحفظ التلقائي مع طابور دون اتصال ---------- */
class Saver {
  constructor(bid, vers, onStatus, onResult) {
    this.bid = bid; this.vers = vers || {}; this.pending = new Map(); this.onStatus = onStatus; this.onResult = onResult;
    this.timer = null; this.busy = false; this.conflicts = []; this.dead = false;
    this.retry = setInterval(() => { if (this.pending.size && !this.busy) this.flush(); }, 6000);
    this.netfn = () => { this.emit(); if (net.online) this.flush(); }; net.listeners.add(this.netfn);
    this.beforeunload = e => { if (this.pending.size) { e.preventDefault(); e.returnValue = ''; } }; addEventListener('beforeunload', this.beforeunload);
  }
  async restore() { const q = await kv.get('queue:' + this.bid); if (Array.isArray(q)) for (const c of q) this.pending.set(c.k, c.v); if (this.pending.size) { this.emit(); this.flush(); } }
  persist() { return kv.set('queue:' + this.bid, [...this.pending].map(([k, v]) => ({ k, v }))); }
  set(k, v) { this.pending.set(k, v); this.persist(); this.emit(); clearTimeout(this.timer); this.timer = setTimeout(() => this.flush(), 600); }
  emit() { this.onStatus && this.onStatus(this.pending.size ? (net.online ? 'saving' : 'offline') : (this.conflicts.length ? 'conflict' : 'saved'), this.pending.size); }
  async flush() {
    if (this.busy || this.dead || !this.pending.size) return;
    if (!net.online) { this.emit(); return; }
    this.busy = true; const batch = [...this.pending];
    try {
      const j = await api('/api/booklets/' + this.bid + '/values', { method: 'PUT', json: { changes: batch.map(([k, v]) => ({ k, v, ver: this.vers[k] })) } });
      for (const [k, v] of batch) if (this.pending.get(k) === v) this.pending.delete(k);
      Object.assign(this.vers, j.applied);
      if (j.conflicts && j.conflicts.length) { for (const c of j.conflicts) { this.pending.delete(c.k); this.vers[c.k] = c.server_ver; } this.conflicts.push(...j.conflicts); }
      await this.persist(); this.onResult && this.onResult(j);
    } catch (e) {
      if (e.offline) { net.online = false; } else if (e.status === 423 || e.status === 403) { toast(e.message, true); this.pending.clear(); await this.persist(); }
      else if (e.status === 401) { /* ستُعاد المحاولة بعد الدخول */ }
      else toast(e.message, true);
    } finally { this.busy = false; this.emit(); if (this.pending.size && net.online) { clearTimeout(this.timer); this.timer = setTimeout(() => this.flush(), 1500); } }
  }
  async flushNow() { clearTimeout(this.timer); let n = 0; while (this.pending.size && n++ < 4) { await this.flush(); if (!net.online) break; } return !this.pending.size; }
  destroy() { this.dead = true; clearInterval(this.retry); clearTimeout(this.timer); net.listeners.delete(this.netfn); removeEventListener('beforeunload', this.beforeunload); }
}

/* ---------- المجاميع (نفس منطق الخادم) ---------- */
function toNum(v) { if (v === null || v === undefined) return null; const s = normDigits(String(v)).trim(); if (s === '') return null; const n = Number(s); return Number.isFinite(n) ? n : null; }
function computeAll(form, vals) {
  const cache = {};
  const get = k => {
    const f = form.fields[k]; if (!f) return null;
    if (f.type !== 'computed') return toNum(vals[k] && vals[k].v);
    if (k in cache) return cache[k]; cache[k] = null;
    const parts = f.sum.map(get); cache[k] = parts.every(p => p === null) ? null : parts.reduce((a, b) => a + (b || 0), 0); return cache[k];
  };
  const out = {}; for (const k in form.fields) if (form.fields[k].type === 'computed') out[k] = get(k); return out;
}

const App = { user: null, credit: 'تصميم المهندس ضيغم الفهداوي', settings: {} };
