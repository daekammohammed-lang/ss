/* شاشة الإدخال السريع: رقم إحصائي ← مدرسة ← استمارة كاملة في صفحة واحدة. */
'use strict';
const Forms = { cache: {}, async get(tid) {
  if (this.cache[tid]) return this.cache[tid];
  try { const f = await api('/api/forms/' + tid); this.cache[tid] = f; kv.set('form:' + tid, f); }
  catch (e) { const c = await kv.get('form:' + tid); if (!c) throw e; this.cache[tid] = c; }
  return this.cache[tid];
} };

const STATUS_LBL = { approved: ['معتمد', 'ok'], review: ['قيد المراجعة', 'warn'], draft: ['غير مكتمل', 'brand'], null: ['لم يبدأ', ''] };

async function EntryView(root, params) {
  await Schools.load().catch(() => toast('تعذّر تحميل قائمة المدارس', true));
  root.innerHTML = `
  <div class="entrybar">
    <input id="sid" class="inp sidno" inputmode="numeric" autocomplete="off" placeholder="الرقم الإحصائي" aria-label="الرقم الإحصائي أو اسم المدرسة" autofocus>
    <div class="school-box" id="sbox"><span class="muted">اكتب الرقم الإحصائي (7 أرقام) أو جزءاً من اسم المدرسة ثم Enter</span></div>
    <span class="savechip hide" id="savechip"></span>
    <button class="btn" id="nextbtn" title="Alt+N">التالي غير المكتمل ⟵</button>
  </div>
  <div id="sugg" class="suggest hide"></div>
  <div id="entrybody"></div>`;
  const sid = $('#sid', root), sbox = $('#sbox', root), body = $('#entrybody', root), sugg = $('#sugg', root), chip = $('#savechip', root);
  let S = null, saver = null, selIdx = -1, hits = [];

  const placeSugg = () => { const r = sid.getBoundingClientRect(); sugg.style.top = (r.bottom + scrollY + 4) + 'px'; sugg.style.insetInlineStart = 'auto'; sugg.style.right = (document.documentElement.clientWidth - r.right - scrollX) + 'px'; };
  const showSugg = list => {
    hits = list; selIdx = list.length ? 0 : -1;
    if (!list.length) { sugg.classList.add('hide'); return; }
    sugg.innerHTML = list.map((r, i) => `<div data-i="${i}" class="${i === 0 ? 'on' : ''}"><span>${esc(r.name)}</span><span class="muted small">${r.id} · ${esc(r.category || '')}${r.ownership === 'اهلي' ? ' · أهلي' : ''}</span></div>`).join('');
    placeSugg(); sugg.classList.remove('hide');
  };
  sugg.addEventListener('mousedown', e => { const d = e.target.closest('[data-i]'); if (d) { e.preventDefault(); pick(hits[+d.dataset.i].id); } });

  function setChip(st, n) {
    chip.classList.remove('hide', 'saving', 'off');
    if (st === 'saved') chip.textContent = 'تم الحفظ ✓';
    else if (st === 'saving') { chip.textContent = 'جارٍ الحفظ…'; chip.classList.add('saving'); }
    else if (st === 'offline') { chip.textContent = 'غير متصل — محفوظ على الجهاز (' + n + ')'; chip.classList.add('off'); }
    else if (st === 'conflict') { chip.textContent = 'تعارض في حقول — راجعها'; chip.classList.add('off'); }
  }

  async function pick(id) {
    sugg.classList.add('hide'); sid.value = id; await openSchool(id);
  }

  async function openSchool(id) {
    id = normDigits(id).trim();
    const cached = Schools.get(id);
    if (cached) sbox.innerHTML = `<span class="nm">${esc(cached.name)}</span><span class="chip brand">${esc(cached.category || '')}</span>${cached.ownership === 'اهلي' ? '<span class="chip ai">أهلي</span>' : ''}`;
    try {
      const sch = await api('/api/schools/' + encodeURIComponent(id));
      if (!sch.template) { sbox.innerHTML = `<span class="nm">${esc(sch.name)}</span><span class="chip warn">${esc(sch.category)}</span><span class="notice" style="margin:0">لا يوجد قالب إدخال لهذا النوع بعد</span>`; body.innerHTML = ''; return; }
      const j = await api('/api/booklets', { json: { school_id: id } });
      await load(j);
    } catch (e) {
      if (e.offline) {
        const c = Schools.get(id); const bid = c && c.bid; const local = bid && await kv.get('bk:' + bid);
        if (local) { toast('لا اتصال — فُتح الكراس من النسخة المحفوظة على الجهاز'); return load(local); }
        sbox.innerHTML = '<span class="notice bad" style="margin:0">لا اتصال بالخادم وهذا الكراس غير محفوظ على الجهاز — افتحه مرة واحدة وأنت متصل</span>'; return;
      }
      sbox.innerHTML = `<span class="notice bad" style="margin:0">${esc(e.message)}</span>`; body.innerHTML = '';
    }
  }

  async function load(payload) {
    if (saver) { await saver.flushNow(); saver.destroy(); }
    const form = await Forms.get(payload.booklet.template);
    S = { form, bk: payload.booklet, school: payload.school, vals: payload.values, computed: payload.computed, issues: payload.issues };
    kv.set('bk:' + S.bk.id, payload);
    const vers = {}; for (const k in S.vals) vers[k] = S.vals[k].ver;
    saver = new Saver(S.bk.id, vers, setChip, j => { S.computed = j.computed; S.issues = j.issues; paintAll(); updateNav(); });
    await saver.restore();
    for (const [k, v] of saver.pending) (S.vals[k] ||= {}).v = v;
    S.computed = computeAll(form, S.vals);
    const s = S.school;
    sid.value = s.id;
    sbox.innerHTML = `<span class="nm">${esc(s.name)}</span><span class="chip brand">${esc(s.category || '')}</span>
      ${s.ownership === 'اهلي' ? '<span class="chip ai">أهلي</span>' : ''}<span class="chip">${esc(s.gender || '')} · ${esc(s.env || '')}</span>
      <span id="stchip" class="chip"></span><span class="muted small">${esc(form.title)}</span>`;
    setChip('saved', 0);
    renderForm(); stChip();
    const first = $$('input[data-k]:not([readonly])', body).find(i => !i.value && !i.closest('.sec.info'));
    (first || $('input[data-k]:not([readonly])', body))?.focus();
    location.hash = '#/entry/' + S.bk.id;
  }

  function stChip() { const el = $('#stchip', root); if (!el) return; const [t, c] = STATUS_LBL[S.bk.status] || ['', '']; el.textContent = t; el.className = 'chip ' + c; }

  /* ---------- رسم الاستمارة ---------- */
  const val = k => (S.vals[k] && S.vals[k].v) ?? '';
  function cellInput(k, f, extra = '') {
    const x = S.vals[k] || {}; let cls = 'cell';
    if (f.type === 'computed') return `<input class="cell c" data-k="${k}" data-calc="1" readonly tabindex="-1" value="${esc(S.computed[k] ?? '')}" ${extra}>`;
    if (x.src === 'ai') cls += (x.conf ?? 1) < 0.6 ? ' low' : ((x.conf ?? 1) < 0.85 ? ' mid' : ' ai');
    if (x.src === 'master') cls += ' master';
    return `<input class="${cls}" data-k="${k}" inputmode="numeric" autocomplete="off" value="${esc(val(k))}" ${extra}>`;
  }
  function gridHTML(sec) {
    const g = sec.grid, cols = g.cols, D = Math.max(...cols.map(c => c.length), 1);
    let thead = '';
    for (let l = 0; l < D; l++) {
      let tr = l === 0 ? '<th rowspan="' + D + '"></th>' : ''; let i = 0;
      while (i < cols.length) {
        if (cols[i].length <= l) { i++; continue; }
        const pre = cols[i].slice(0, l + 1).join('›'); let j = i;
        while (j + 1 < cols.length && cols[j + 1].length > l && cols[j + 1].slice(0, l + 1).join('›') === pre) j++;
        let allEnd = true; for (let m = i; m <= j; m++) if (cols[m].length !== l + 1) allEnd = false;
        tr += `<th colspan="${j - i + 1}" ${allEnd && D - l > 1 ? 'rowspan="' + (D - l) + '"' : ''}>${esc(cols[i][l])}</th>`; i = j + 1;
      }
      thead += `<tr>${tr}</tr>`;
    }
    const cellAt = {}; for (const k in g.cells) { const [r, c] = g.cells[k]; cellAt[r + ':' + c] = k; }
    let rows = '';
    g.rows.forEach((rl, r) => {
      let tr = `<td class="rl">${esc(rl)}</td>`;
      cols.forEach((_, c) => { const k = cellAt[r + ':' + c]; tr += k ? `<td>${cellInput(k, S.form.fields[k], `data-r="${r}" data-c="${c}"`)}</td>` : '<td class="na"></td>'; });
      rows += `<tr>${tr}</tr>`;
    });
    return `<table class="g"><thead>${thead}</thead><tbody>${rows}</tbody></table>`;
  }
  function listHTML(sec) {
    const fs = sec.fields.map(k => S.form.fields[k]).filter(f => f.type !== 'seq');
    const seen = new Set(), dup = {}; fs.forEach(f => { const l = f.path.join(' ‹ '); dup[l] = (dup[l] || 0) + 1; });
    const idx = {}; let out = '';
    for (const f of fs) {
      if (f.type === 'check') {
        if (seen.has(f.group)) continue; seen.add(f.group);
        const members = fs.filter(x => x.type === 'check' && x.group === f.group);
        const excl = sec.id === 'info' || members.some(m => /^(نعم|كلا)\s*$/.test(m.path[m.path.length - 1]));
        out += `<div class="field"><div class="lb">${esc(f.group)}</div><div class="opts" data-group="${esc(f.group)}" data-excl="${excl ? 1 : 0}">` +
          members.map(m => `<span class="opt ${val(m.key) === '1' ? 'on' : ''}" tabindex="0" role="checkbox" aria-checked="${val(m.key) === '1'}" data-k="${m.key}">${esc(m.path[m.path.length - 1])}</span>`).join('') + '</div></div>';
        continue;
      }
      let lb = f.path.join(' ‹ '); const l0 = lb; if (dup[l0] > 1) { idx[l0] = (idx[l0] || 0) + 1; lb += ' (' + idx[l0] + ')'; }
      if (f.type === 'computed') out += `<div class="field"><div class="lb">${esc(lb)}</div><div><input class="cell c" style="width:110px" data-k="${f.key}" data-calc="1" readonly tabindex="-1" value="${esc(S.computed[f.key] ?? '')}"></div></div>`;
      else if (f.type === 'number') out += `<div class="field"><div class="lb">${esc(lb)}</div><div><input class="txt num" data-k="${f.key}" inputmode="numeric" autocomplete="off" value="${esc(val(f.key))}"></div></div>`;
      else out += `<div class="field"><div class="lb">${esc(lb)}</div><div><input class="txt" data-k="${f.key}" data-text="1" autocomplete="off" value="${esc(val(f.key))}" ${f.type === 'id' ? 'readonly tabindex="-1"' : ''}></div></div>`;
    }
    return out;
  }
  function renderForm() {
    const f = S.form;
    body.innerHTML = `<div class="legend"><span><i style="background:var(--calc)"></i>مجموع محسوب</span><span><i style="background:var(--shade)"></i>خانة غير مطلوبة</span>
      <span><i style="background:var(--ai-l)"></i>قراءة آلية</span><span><i style="background:var(--warn-l)"></i>مراجعة مستحبة</span><span><i style="background:var(--bad-l)"></i>مراجعة إلزامية / خطأ</span>
      <span class="muted">Enter ← الخانة التالية · الأسهم للتنقل · Ctrl+Enter اعتماد والانتقال للتالي</span></div>
    <div class="entry"><nav class="secnav" id="secnav">${f.sections.map((s, i) => `<a data-s="${s.id}" class="${i === 0 ? 'on' : ''}">${esc(s.title.length > 70 ? s.title.slice(0, 70) + '…' : s.title)}<span class="c" data-cnt="${s.id}"></span></a>`).join('')}</nav>
    <div id="secs">${f.sections.map(s => `<section class="sec ${s.id === 'info' ? 'info' : ''}" id="sec-${s.id}"><h3>${esc(s.title)}</h3><div class="body">${s.layout === 'grid' ? gridHTML(s) : listHTML(s)}</div></section>`).join('')}</div></div>
    <div class="actions" id="actions">
      <button class="btn ok" id="approve">اعتماد الكراس (Ctrl+Enter)</button>
      <button class="btn" id="tostatus">إعادة للمراجعة</button>
      ${App.settings.ai_enabled ? `<a class="btn" href="#/uploads?bid=${S.bk.id}">رفع/قراءة PDF</a>` : ''}
      <span id="issuesum" class="muted small"></span><span class="spacer"></span>
      <button class="btn sm" id="hist">سجل التعديلات</button></div>`;
    paintAll(); updateNav(); bindForm();
  }
  function paintAll() {
    if (!S) return;
    $$('input[data-calc]', body).forEach(el => { const v = S.computed[el.dataset.k]; const s = v ?? ''; if (el.value !== String(s)) el.value = s; });
    $$('input[data-k]:not([data-calc])', body).forEach(el => {
      const k = el.dataset.k, is = (S.issues[k] || []);
      el.classList.toggle('err', is.some(i => i.level === 'error')); el.classList.toggle('wrn', !is.some(i => i.level === 'error') && is.some(i => i.level === 'warn'));
      el.title = is.map(i => i.msg).join(' · ');
    });
    $$('input[data-calc]', body).forEach(el => { const is = S.issues[el.dataset.k] || []; el.classList.toggle('err', is.length > 0); el.title = is.map(i => i.msg).join(' · '); });
    const ne = Object.values(S.issues).flat().filter(i => i.level === 'error').length, nw = Object.values(S.issues).flat().filter(i => i.level === 'warn').length;
    const is = $('#issuesum', root); if (is) is.innerHTML = (ne ? `<span class="chip bad">${ne} خطأ</span> ` : '') + (nw ? `<span class="chip warn">${nw} تنبيه</span>` : '') || '<span class="chip ok">لا أخطاء</span>';
  }
  function updateNav() {
    if (!S) return;
    for (const s of S.form.sections) {
      const nums = s.fields.filter(k => ['number', 'text', 'check'].includes(S.form.fields[k].type));
      const filled = nums.filter(k => (S.vals[k] && S.vals[k].v) ? S.vals[k].v !== '' : false).length;
      const el = $(`[data-cnt="${s.id}"]`, root); if (el) el.textContent = filled ? filled + '/' + nums.length : '';
    }
  }

  /* ---------- التفاعل ---------- */
  function setVal(k, v) {
    const old = S.vals[k] || {}; const nv = { ...old, v, src: 'manual', state: 'ok', conf: null }; S.vals[k] = nv;
    saver.set(k, v);
    S.computed = computeAll(S.form, S.vals);
    $$('input[data-calc]', body).forEach(el => { const c = S.computed[el.dataset.k]; el.value = c ?? ''; });
  }
  let navT = null; const navUpdSoon = () => { clearTimeout(navT); navT = setTimeout(updateNav, 300); };
  function focusDelta(el, d) {
    const all = $$('input[data-k]:not([readonly]), .opt', body), i = all.indexOf(el); const t = all[i + d]; if (t) { t.focus(); t.select && t.select(); t.scrollIntoView({ block: 'center', inline: 'nearest' }); }
  }
  function focusGrid(el, dr, dc) {
    const tbl = el.closest('table'); let r = +el.dataset.r, c = +el.dataset.c, guard = 0;
    for (; guard < 200; guard++) {
      r += dr; c += dc; const t = tbl.querySelector(`input[data-r="${r}"][data-c="${c}"]:not([readonly])`);
      if (t) { t.focus(); t.select(); return; }
      if (r < -1 || r > 500 || c < -1 || c > 500) return;
      if (!tbl.querySelector(`input[data-r="${r}"]`) && dr) return;
    }
  }
  async function approve() {
    if (!S) return;
    if (!await saver.flushNow()) { toast('لم يكتمل الحفظ — تحقق من الاتصال', true); return; }
    try {
      let j; try { j = await api('/api/booklets/' + S.bk.id + '/status', { json: { status: 'approved' } }); }
      catch (e) {
        if (e.status === 409 && App.user.role !== 'entry' && App.user.role !== 'readonly' && confirm(e.message + '\nاعتماد رغم ذلك؟')) j = await api('/api/booklets/' + S.bk.id + '/status', { json: { status: 'approved', force: true } });
        else if (e.status === 409) { toast(e.message, true); const first = (e.data.errors || e.data.pending || [])[0]; const el = first && $(`[data-k="${first}"]`, body); if (el) { el.scrollIntoView({ block: 'center' }); el.focus(); } return; } else throw e;
      }
      S.bk.status = j.status; stChip(); toast(j.status === 'approved' ? 'تم اعتماد الكراس ✓' : 'أُرسل للمراجعة');
      const row = Schools.get(S.school.id); if (row) row.status = j.status;
      await gotoNext();
    } catch (e) { toast(e.message, true); }
  }
  async function gotoNext() {
    try { const j = await api('/api/next?after=' + (S ? S.school.id : '') + (S ? '&template=' + S.bk.template : '')); if (j.school) { await openSchool(j.school.id); } else toast('لا توجد مدارس غير مكتملة 🎉'); }
    catch (e) { toast(e.message, true); }
  }
  function bindForm() {
    body.addEventListener('input', e => {
      const el = e.target; if (!el.dataset || !el.dataset.k || el.dataset.calc) return;
      if (!el.dataset.text) { const v = normDigits(el.value).replace(/[^\d]/g, ''); if (v !== el.value) el.value = v; }
      setVal(el.dataset.k, el.value); navUpdSoon();
    });
    body.addEventListener('keydown', e => {
      const el = e.target;
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); approve(); return; }
      if (el.classList && el.classList.contains('opt') && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); toggleOpt(el); if (e.key === 'Enter') focusDelta(el, 1); return; }
      if (!el.matches || !el.matches('input[data-k]')) return;
      if (e.key === 'Enter') { e.preventDefault(); focusDelta(el, e.shiftKey ? -1 : 1); }
      else if (el.dataset.r !== undefined && !el.dataset.text) {
        const m = { ArrowDown: [1, 0], ArrowUp: [-1, 0], ArrowLeft: [0, 1], ArrowRight: [0, -1] }[e.key];
        if (m) { e.preventDefault(); focusGrid(el, m[0], m[1]); }
      }
    });
    body.addEventListener('click', e => { const o = e.target.closest('.opt'); if (o) toggleOpt(o); });
    body.addEventListener('focusin', e => { const sec = e.target.closest('.sec'); if (sec) $$('#secnav a', root).forEach(a => a.classList.toggle('on', 'sec-' + a.dataset.s === sec.id)); });
    $('#secnav', root).addEventListener('click', e => { const a = e.target.closest('a[data-s]'); if (!a) return; const sec = $('#sec-' + a.dataset.s); sec.scrollIntoView({ behavior: 'smooth', block: 'start' }); const i = $('input[data-k]:not([readonly]), .opt', sec); i && setTimeout(() => i.focus({ preventScroll: true }), 350); });
    $('#approve', root).onclick = approve;
    $('#tostatus', root).onclick = async () => { try { const j = await api('/api/booklets/' + S.bk.id + '/status', { json: { status: 'draft' } }); S.bk.status = j.status; stChip(); toast('أُعيد فتح الكراس'); } catch (e) { toast(e.message, true); } };
    $('#hist', root).onclick = async () => { const j = await api('/api/audit?booklet=' + S.bk.id + '&limit=60').catch(e => ({ rows: [], err: e.message })); alert(j.err ? j.err : j.rows.map(r => `${r.ts} · ${r.username || '—'} · ${r.action}`).join('\n') || 'لا سجل'); };
  }
  function toggleOpt(o) {
    const k = o.dataset.k, grp = o.closest('.opts'), excl = grp.dataset.excl === '1', on = !o.classList.contains('on');
    if (excl && on) $$('.opt', grp).forEach(x => { if (x !== o) { if (x.classList.contains('on') || val(x.dataset.k) === '') { x.classList.remove('on'); x.setAttribute('aria-checked', 'false'); setVal(x.dataset.k, '0'); } } });
    o.classList.toggle('on', on); o.setAttribute('aria-checked', on); setVal(k, on ? '1' : (excl ? '' : '0')); navUpdSoon();
  }

  /* ---------- حقل الرقم الإحصائي ---------- */
  let st = null;
  sid.addEventListener('input', () => {
    const q = sid.value; clearTimeout(st);
    if (/^[\d٠-٩]+$/.test(q) && normDigits(q).length >= 7) { st = setTimeout(() => openSchool(normDigits(q)), 80); sugg.classList.add('hide'); return; }
    st = setTimeout(() => showSugg(Schools.search(q, 10)), 60);
  });
  sid.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!hits.length) return; selIdx = (selIdx + (e.key === 'ArrowDown' ? 1 : -1) + hits.length) % hits.length; $$('div', sugg).forEach((d, i) => d.classList.toggle('on', i === selIdx)); }
    else if (e.key === 'Enter') { e.preventDefault(); if (!sugg.classList.contains('hide') && hits[selIdx]) pick(hits[selIdx].id); else if (sid.value.trim()) openSchool(normDigits(sid.value)); }
    else if (e.key === 'Escape') sugg.classList.add('hide');
  });
  sid.addEventListener('blur', () => setTimeout(() => sugg.classList.add('hide'), 150));
  $('#nextbtn', root).onclick = gotoNext;
  const hotkey = e => { if (e.altKey && (e.key === 'n' || e.key === 'ن')) { e.preventDefault(); gotoNext(); } else if (e.altKey && e.key === '/') { e.preventDefault(); sid.focus(); sid.select(); } else if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saver && saver.flushNow().then(ok => toast(ok ? 'تم الحفظ ✓' : 'محفوظ على الجهاز — سيُرفع عند عودة الاتصال')); } };
  addEventListener('keydown', hotkey);

  if (params && params[0] && /^\d+$/.test(params[0])) { try { await load(await api('/api/booklets/' + params[0])); } catch (e) { const local = await kv.get('bk:' + params[0]); if (local) await load(local); else toast(e.message, true); } }
  return () => { removeEventListener('keydown', hotkey); if (saver) { saver.flushNow(); saver.destroy(); } };
}
