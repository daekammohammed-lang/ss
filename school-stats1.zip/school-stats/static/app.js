/* الهيكل العام والواجهات: لوحة التحكم، المدارس، الرفع والمراجعة، التصدير، المزامنة، المستخدمون، السجل. */
'use strict';
const NAV = [
  ['#/', 'لوحة التحكم', '◧'], ['#/entry', 'الإدخال السريع', '✎'], ['#/schools', 'المدارس', '☷'], ['#/uploads', 'رفع وقراءة PDF', '⇪'],
  ['#/export', 'التصدير', '⇩'], ['#/pack', 'نقل البيانات بين الأجهزة', '⇆', ['admin', 'reviewer', 'entry']], ['#/sync', 'Google Sheets', '⇄', ['admin', 'reviewer']], ['#/activity', 'نشاط الموظفين', '◔', ['admin']], ['#/users', 'المستخدمون', '☺', ['admin']], ['#/audit', 'سجل العمليات', '☰', ['admin', 'reviewer']],
];
const ROLE_LBL = { admin: 'مدير النظام', entry: 'موظف إدخال', reviewer: 'موظف مراجعة', readonly: 'قراءة فقط' };
let cleanup = null, pollT = null;

function shell(title, inner, route) {
  const root = $('#app');
  root.innerHTML = `<div class="shell"><aside class="side"><div class="brand">منصة الكراسات الإحصائية<small>الإحصاء المدرسي ${esc(App.settings.year || '')}</small></div>
    <nav class="nav">${NAV.filter(n => (!n[3] || n[3].includes(App.user.role)) && (n[0] !== '#/uploads' || App.settings.ai_enabled)).map(n => `<a href="${n[0]}" class="${route === n[0] ? 'on' : ''}"><span class="ico">${n[2]}</span>${n[1]}</a>`).join('')}</nav>
    <div class="foot"><b>${esc(App.user.name)}</b><br>${ROLE_LBL[App.user.role]}<br><a href="#/account">حسابي (تغيير الاسم/كلمة المرور)</a><br>${App.settings.local_mode ? '' : '<a href="#" id="logout">تسجيل الخروج</a>'}<div style="margin-top:10px">${esc(App.credit)}</div></div></aside>
    <main class="main"><div class="top"><h1>${esc(title)}</h1><span class="spacer"></span><span id="netchip" class="chip ok">متصل</span></div><div id="view">${inner || ''}</div></main></div>`;
  if ($('#logout')) $('#logout').onclick = async e => { e.preventDefault(); await api('/api/logout', { method: 'POST' }).catch(() => { }); App.user = null; location.hash = '#/login'; };
  const nc = $('#netchip'); const upd = () => { nc.textContent = net.online ? 'متصل' : 'غير متصل'; nc.className = 'chip ' + (net.online ? 'ok' : 'bad'); }; upd(); net.listeners.add(upd);
  return $('#view');
}

/* ---------- الدخول ---------- */
function loginView() {
  $('#app').innerHTML = `<div class="login"><div class="card"><h1>منصة الكراسات الإحصائية المدرسية</h1><div class="muted small">تسجيل الدخول</div>
    <form id="lf"><label>اسم المستخدم</label><input class="inp" id="lu" autocomplete="username" autofocus><label>كلمة المرور</label><input class="inp" id="lp" type="password" autocomplete="current-password">
    <div id="lerr" class="notice bad hide"></div><button class="btn pri" style="width:100%;margin-top:18px;padding:10px">دخول</button></form>
    <div class="credit">${esc(App.credit)}</div></div></div>`;
  $('#lf').onsubmit = async e => {
    e.preventDefault();
    try { const j = await api('/api/login', { json: { username: $('#lu').value, password: $('#lp').value } }); App.user = j.user; App.credit = j.credit; await boot(); location.hash = '#/'; route(); }
    catch (err) { const el = $('#lerr'); el.textContent = err.message; el.classList.remove('hide'); }
  };
}

/* ---------- لوحة التحكم ---------- */
function pctBar(label, b) { return `<div class="prog"><span>${label}</span><div class="bar"><i style="width:${b.pct}%"></i></div><span class="v">${b.approved}/${b.total} · ${b.pct}%</span></div>`; }
async function dashView(v) {
  v.innerHTML = '<div class="muted">جارٍ التحميل…</div>';
  const draw = async () => {
    let s; try { s = await api('/api/stats'); } catch (e) { return; }
    const o = s.overall, c = s.categories, f = s.fields;
    const st = (n, l, cls = '') => `<div class="card stat ${cls}"><div class="n">${nf(n)}</div><div class="l">${l}</div></div>`;
    v.innerHTML = `<div class="grid g4">${st(s.total_schools, 'إجمالي المدارس المسجلة')}${st(o.total, 'الكراسات المطلوبة')}${st(o.started, 'الكراسات المستلمة / المبدوءة')}${st(o.approved, 'المعتمدة (المكتملة)', 'ok')}
      ${st(o.draft, 'غير مكتملة', 'warn')}${st(o.review, 'قيد المراجعة', 'warn')}${st(s.with_issues, 'بها بيانات مشكوك بها', 'bad')}${st(s.remaining, 'مدارس متبقية للإدخال')}
      ${st(s.ai_read, 'قُرئت بالذكاء الاصطناعي', 'ai')}${st(s.manual + s.hybrid, 'أُدخلت يدوياً / هجين')}${st(s.received, 'ملفات PDF مرفوعة')}${st(s.pages_read, 'صفحات جُهّزت للقراءة')}</div>
    <div class="grid g2" style="margin-top:14px"><div class="card"><h2>نسبة الإنجاز</h2><div style="font-size:42px;font-weight:700;color:var(--brand)">${o.pct}%</div><div class="bar" style="margin:6px 0 16px"><i style="width:${o.pct}%"></i></div>
      ${pctBar('الابتدائي والأساسي', c.primary)}${pctBar('الثانوي (متوسط+إعدادي)', c.secondary)}${pctBar('الأهلي', c.ahli)}${pctBar('رياض الأطفال', c.kg)}
      <div class="muted small" style="margin-top:8px">«الأهلي» يشمل مدارس أهلية من الأنواع الأخرى أيضاً. ${s.no_template ? s.no_template + ' مدرسة (مهني/معاهد) بلا قالب إدخال بعد.' : ''}</div></div>
      <div class="card"><h2>الحقول</h2><table class="t"><tr><td>حقول مدخلة (بدون المعبّأ مسبقاً)</td><td>${nf(f.entered)}</td></tr><tr><td>مقروءة بالذكاء الاصطناعي</td><td>${nf(f.ai)}</td></tr>
      <tr><td>أُدخلت/عُدّلت يدوياً</td><td>${nf(f.manual)}</td></tr><tr><td>بانتظار المراجعة</td><td>${nf(f.needs_review)}</td></tr><tr><td>قراءات آلية صُحّحت يدوياً</td><td>${nf(f.ai_corrected)}</td></tr></table>
      <div class="row" style="margin-top:14px"><a class="btn pri" href="#/entry">متابعة الإدخال</a><a class="btn" href="#/schools?pending=1">المدارس المتبقية</a></div></div></div>`;
  };
  await draw(); pollT = setInterval(draw, 10000); return () => clearInterval(pollT);
}

/* ---------- المدارس ---------- */
async function schoolsView(v, params, query) {
  await Schools.load();
  v.innerHTML = `<div class="row"><input id="q" class="inp" style="width:300px" placeholder="رقم إحصائي أو اسم مدرسة" autofocus>
    <select id="ft" class="inp"><option value="">كل القوالب</option><option value="primary">ابتدائي/أساسي</option><option value="secondary">ثانوي</option><option value="kg">رياض أطفال</option><option value="none">بلا قالب</option></select>
    <select id="fs" class="inp"><option value="">كل الحالات</option><option value="none">لم يبدأ</option><option value="draft">غير مكتمل</option><option value="review">قيد المراجعة</option><option value="approved">معتمد</option><option value="pending">غير معتمد (متبقي)</option></select>
    <label class="small"><input type="checkbox" id="fa"> أهلي فقط</label><span class="muted small" id="cnt"></span></div><div class="card" style="margin-top:12px;padding:0;max-height:70vh;overflow:auto"><table class="t" id="tb"></table></div>`;
  if (query.get('pending')) $('#fs').value = 'pending';
  const draw = () => {
    const q = normAr($('#q').value), ft = $('#ft').value, fs = $('#fs').value, fa = $('#fa').checked;
    const toks = q.split(' ').filter(Boolean);
    const rows = Schools.rows.filter(r => (!q || (/^\d+$/.test(q) ? r.id.startsWith(q) : toks.every(t => r.n.includes(t)))) && (!ft || (ft === 'none' ? !r.template : r.template === ft)) &&
      (!fs || (fs === 'none' ? !r.status : fs === 'pending' ? r.status !== 'approved' && r.template : r.status === fs)) && (!fa || r.ownership === 'اهلي'));
    $('#cnt').textContent = rows.length + ' مدرسة';
    $('#tb').innerHTML = '<tr><th>الرقم الإحصائي</th><th>الاسم</th><th>التصنيف</th><th>العائدية</th><th>الحالة</th><th></th></tr>' + rows.slice(0, 400).map(r => {
      const [t, c] = STATUS_LBL[r.status || null]; return `<tr><td class="small" style="direction:ltr;text-align:right">${r.id}</td><td>${esc(r.name)}</td><td>${esc(r.category || '')}</td><td>${r.ownership === 'اهلي' ? '<span class="chip ai">أهلي</span>' : 'حكومي'}</td>
      <td><span class="chip ${c}">${r.template ? t : 'بلا قالب'}</span></td><td>${r.template ? `<a class="btn sm" href="#/entry" data-open="${r.id}">فتح</a>` : ''}</td></tr>`; }).join('') + (rows.length > 400 ? '<tr><td colspan="6" class="muted">يُعرض أول 400 — ضيّق البحث</td></tr>' : '');
  };
  ['input', 'change'].forEach(ev => v.addEventListener(ev, draw)); draw();
  v.addEventListener('click', async e => { const a = e.target.closest('[data-open]'); if (!a) return; e.preventDefault(); try { const j = await api('/api/booklets', { json: { school_id: a.dataset.open } }); location.hash = '#/entry/' + j.booklet.id; } catch (er) { toast(er.message, true); } });
}

/* ---------- الرفع والمراجعة ---------- */
async function uploadsView(v, params, query) {
  v.innerHTML = `<div class="card"><h2>رفع كراس (PDF أو صور ممسوحة)</h2><div class="row" style="margin-bottom:10px"><input id="us" class="inp" style="width:230px" placeholder="الرقم الإحصائي (اختياري — يُقرأ من الصفحة)" value="${esc(query.get('sid') || '')}"></div>
    <div class="drop" id="drop">اسحب الملفات هنا أو اضغط للاختيار<input type="file" id="uf" multiple accept=".pdf,.jpg,.jpeg,.png" class="hide"></div></div>
    <div class="card" style="margin-top:14px"><h2>الملفات</h2><div id="ul" class="muted">…</div></div><div id="uview"></div>`;
  const drop = $('#drop'), uf = $('#uf');
  drop.onclick = () => uf.click();
  ['dragover', 'dragenter'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', ev => up(ev.dataTransfer.files)); uf.onchange = () => up(uf.files);
  async function up(files) {
    const fd = new FormData(); for (const f of files) fd.append('file', f); fd.append('school_id', $('#us').value.trim());
    try { const j = await api('/api/uploads', { method: 'POST', body: fd }); j.uploads.forEach(u => toast(u.error ? (u.filename + ': ' + u.error) : u.duplicate ? (u.filename + ': مرفوع سابقاً (لن يُعالج مرة ثانية)') : (u.filename + ': جارٍ تجهيز الصفحات'), !!u.error)); list(); } catch (e) { toast(e.message, true); }
  }
  const STL = { new: ['جديد', ''], rendering: ['تجهيز الصفحات…', 'warn'], ready: ['جاهز للقراءة', 'brand'], extracting: ['قراءة بالذكاء الاصطناعي…', 'ai'], done: ['تمت القراءة', 'ok'], failed: ['فشل', 'bad'], needs_school: ['يحتاج تأكيد المدرسة', 'warn'] };
  async function list() {
    const j = await api('/api/uploads'); const el = $('#ul'); if (!el) return;
    el.innerHTML = j.uploads.length ? '<table class="t"><tr><th>الملف</th><th>المدرسة</th><th>الصفحات</th><th>الحالة</th><th></th></tr>' + j.uploads.map(u => { const [t, c] = STL[u.status] || [u.status, '']; const busy = ['rendering', 'extracting'].includes(u.status);
      return `<tr><td>${esc(u.filename)}</td><td>${u.school_name ? esc(u.school_name) + ' <span class="muted small">' + u.school_id + '</span>' : '<span class="muted">—</span>'}</td><td>${u.pages || ''}</td>
      <td><span class="chip ${c}">${t}${busy ? ' ' + Math.round((u.progress || 0) * 100) + '%' : ''}</span>${u.error ? '<div class="small" style="color:var(--bad)">' + esc(u.error) + '</div>' : ''}</td>
      <td class="row"><button class="btn sm" data-v="${u.id}">عرض</button>${u.status === 'ready' || u.status === 'failed' || u.status === 'done' || u.status === 'needs_school' ? `<button class="btn sm pri" data-x="${u.id}" data-done="${u.status === 'done' ? 1 : 0}">${u.status === 'done' ? 'إعادة القراءة' : 'قراءة بالذكاء الاصطناعي'}</button>` : ''}${u.booklet_id && u.status === 'done' ? `<a class="btn sm" href="#/review/${u.booklet_id}">مراجعة</a>` : ''}</td></tr>`; }).join('') + '</table>' : 'لا ملفات بعد';
  }
  v.addEventListener('click', async e => {
    const x = e.target.closest('[data-x]'), vw = e.target.closest('[data-v]'), as = e.target.closest('[data-assign]');
    if (x) { try { await api('/api/uploads/' + x.dataset.x + '/extract', { json: { force: x.dataset.done === '1' } }); toast('بدأت القراءة'); list(); } catch (er) { toast(er.message, true); } }
    if (vw) { const j = await api('/api/uploads/' + vw.dataset.v); const sc = j.school_check;
      $('#uview').innerHTML = `<div class="card" style="margin-top:14px"><h2>${esc(j.filename)} — ${j.pages.length} صفحة</h2>${sc ? `<div class="notice bad">لم يتطابق الرقم المقروء (${esc(sc.read_id || '—')}) مع اسم المدرسة المكتوب (${esc(sc.read_name || '—')}). اختر المدرسة الصحيحة:
        <div class="row" style="margin-top:8px">${(sc.candidates || []).map(c => `<button class="btn sm" data-assign="${j.id}" data-sid="${c.id}">${esc(c.name)} · ${c.id}</button>`).join('')}<input class="inp" id="asid" placeholder="رقم إحصائي" style="width:150px"><button class="btn sm" data-assign="${j.id}" data-sid="">تأكيد الرقم</button></div></div>` : ''}
        <div class="thumbs">${j.pages.map(p => `<a href="/api/pages/${p.id}/image" target="_blank"><img loading="lazy" src="/api/pages/${p.id}/image" alt="صفحة ${p.n}" title="${esc(p.form_hint || '')}"></a>`).join('')}</div></div>`; }
    if (as) { const sid = as.dataset.sid || $('#asid').value.trim(); try { await api('/api/uploads/' + as.dataset.assign + '/assign', { json: { school_id: sid } }); toast('رُبط بالمدرسة'); list(); $('#uview').innerHTML = ''; } catch (er) { toast(er.message, true); } }
  });
  await list(); const t = setInterval(list, 3000); return () => clearInterval(t);
}

async function reviewView(v, params) {
  const bid = params[0]; const [rv, bk] = await Promise.all([api('/api/booklets/' + bid + '/review'), api('/api/booklets/' + bid)]);
  const form = await Forms.get(bk.booklet.template); let sel = null;
  const LV = { low: ['إلزامية', 'bad'], mid: ['مستحبة', 'warn'], high: ['عالية', 'ok'] };
  const pageSrc = p => p ? '/api/pages/' + p + '/image' : '';
  const draw = () => {
    v.innerHTML = `<div class="row" style="margin-bottom:10px"><b>${esc(bk.school.name)}</b><span class="muted">${bk.school.id}</span><span class="spacer"></span>
      <span class="chip ai">مقروء آلياً: ${rv.counts.ai || 0}</span><span class="chip warn">للمراجعة: ${rv.counts.review || 0}</span><span class="chip ok">صُحّح يدوياً: ${rv.counts.corrected || 0}</span>
      <button class="btn" id="acc-high">اعتماد عالي الثقة</button><button class="btn" id="acc-all">اعتماد الكل</button><a class="btn pri" href="#/entry/${bid}">فتح الاستمارة الكاملة</a></div>
      <div class="notice info small">مستوى الثقة مبني على إشارات قابلة للتحقق: مطابقة مجاميع الورق مع المحسوب، وجود قراءة بديلة، سلامة الرقم، المدى. ليس نسبة احتمال مُعايَرة؛ يجب معايرة العتبات على كراسات مصحّحة لديكم.</div>
      <div class="review"><div class="pageview" id="pv">${rv.pages.length ? `<img id="pimg" src="${pageSrc(sel ? sel.page : rv.pages[0].id)}" alt="الصفحة">` : '<div class="muted" style="padding:20px">لا صفحات</div>'}</div>
      <div class="card" style="padding:6px 10px;max-height:78vh;overflow:auto">${rv.items.length ? rv.items.map(it => `<div class="ritem ${sel && sel.k === it.k ? 'sel' : ''}" data-k="${it.k}"><div><div class="small">${esc(it.label)}</div><span class="chip ${LV[it.level][1]}">${it.computed ? 'مجموع الورق: ' + esc(it.paper) : 'مراجعة ' + LV[it.level][0] + (it.conf != null ? ' · ' + Math.round(it.conf * 100) + '%' : '')}</span>${it.alt ? ` <button class="btn sm" data-alt="${it.k}" data-v="${esc(it.alt)}">بديل: ${esc(it.alt)}</button>` : ''}</div>
        ${it.computed ? '<span></span>' : `<input data-i="${it.k}" value="${esc(it.v ?? '')}" inputmode="numeric">`}${it.computed ? '' : `<button class="btn sm ok" data-ok="${it.k}">✓</button>`}</div>`).join('') : '<div class="muted" style="padding:16px">لا حقول بحاجة لمراجعة</div>'}</div></div>`;
  };
  draw();
  v.addEventListener('click', async e => {
    const ok = e.target.closest('[data-ok]'), alt = e.target.closest('[data-alt]'), it = e.target.closest('.ritem');
    try {
      if (ok) { const k = ok.dataset.ok, inp = $(`[data-i="${k}"]`, v); const cur = rv.items.find(x => x.k === k);
        if (inp.value !== (cur.v ?? '')) await api('/api/booklets/' + bid + '/values', { method: 'PUT', json: { changes: [{ k, v: inp.value }] } }); else await api('/api/booklets/' + bid + '/accept', { json: { keys: [k] } });
        rv.items = rv.items.filter(x => x.k !== k); draw(); return; }
      if (alt) { const k = alt.dataset.alt; await api('/api/booklets/' + bid + '/values', { method: 'PUT', json: { changes: [{ k, v: alt.dataset.v }] } }); rv.items = rv.items.filter(x => x.k !== k); draw(); return; }
      if (e.target.id === 'acc-high') { const j = await api('/api/booklets/' + bid + '/accept', { json: { all_high: true } }); toast('اعتُمد ' + j.accepted + ' حقل'); }
      if (e.target.id === 'acc-all') { if (!confirm('اعتماد جميع القراءات الآلية دون مراجعة؟')) return; const j = await api('/api/booklets/' + bid + '/accept', { json: { all: true } }); toast('اعتُمد ' + j.accepted + ' حقل'); }
      if (e.target.id === 'acc-high' || e.target.id === 'acc-all') { Object.assign(rv, await api('/api/booklets/' + bid + '/review')); draw(); return; }
      if (it && !e.target.closest('input,button')) { sel = rv.items.find(x => x.k === it.dataset.k); draw(); }
    } catch (er) { toast(er.message, true); }
  });
}

/* ---------- التصدير ---------- */
async function exportView(v) {
  const info = await api('/api/export-info');
  const T = { primary: 'الابتدائي / الأساسي / المتوسط', secondary: 'الثانوي', kg: 'رياض الأطفال', accel: 'التعليم المسرع' };
  v.innerHTML = `<div class="card"><h2>الملفات النهائية</h2><div class="row"><label>الكراسات:</label><select id="est" class="inp"><option value="approved">المعتمدة فقط</option><option value="all">كل الكراسات المبدوءة</option><option value="incomplete">غير المعتمدة فقط</option></select>
    <label class="small"><input type="checkbox" id="ef"> إبقاء المجاميع كصيغ Excel حيّة (بدل القيم)</label></div>
    <div class="row" style="margin-top:14px"><button class="btn pri" id="eall" style="padding:12px 22px;font-size:16px">⇩ تصدير جميع البيانات</button><button class="btn" id="ecomb" style="padding:12px 18px">⇩ ملف Excel واحد جامع لكل الفئات</button><span class="muted small">ينتج 5 ملفات: ابتدائي · ثانوي · رياض أطفال · التعليم المسرع · الأهلي (ورقة لكل قالب) داخل ملف ZIP — كل مدرسة في ملف واحد فقط</span></div></div>
    <div class="grid g2" style="margin-top:14px"><div class="card"><h2>تصدير حسب النوع</h2><table class="t">${Object.entries(T).map(([k, t]) => `<tr><td>${t}</td><td class="muted small">${info[k].approved} معتمد · ${info[k].incomplete} غير معتمد</td><td><button class="btn sm" data-e="${k}">تحميل</button></td></tr>`).join('')}
      <tr><td>المعاهد والمهني (${info.inst.total} مدرسة)</td><td class="muted small" colspan="2">بلا قالب Excel بعد</td></tr>
      <tr><td>المدارس الأهلية (ورقة لكل قالب)</td><td class="muted small">${Object.values(info).reduce((a, b) => a + b.ahli, 0)} معتمد</td><td><button class="btn sm" data-e="ahli">تحميل</button></td></tr></table></div>
    <div class="card"><h2>تصدير مدارس محددة / تقرير</h2><div class="row"><input id="eids" class="inp" style="flex:1" placeholder="أرقام إحصائية مفصولة بفاصلة"><select id="etpl" class="inp"><option value="primary">قالب الابتدائي</option><option value="secondary">قالب الثانوي</option><option value="kg">قالب رياض الأطفال</option></select><button class="btn" id="eid">تحميل</button></div>
      <div class="row" style="margin-top:12px"><a class="btn" href="/api/export/report">⇩ تقرير الإنجاز (كل المدارس وحالتها)</a></div></div></div>
    <div class="notice info small" style="margin-top:14px">الملفات تُبنى من قوالب Excel الرسمية نفسها (ترويسات ودمج وتنسيق مطابق). المجاميع في قالب الابتدائي ورياض الأطفال فيها أخطاء صيغ في القالب الأصلي صُحّحت تلقائياً — التفاصيل في تقرير تدقيق الصيغ.</div>`;
  const q = () => '?status=' + $('#est').value + ($('#ef').checked ? '&formulas=1' : '');
  const dl = async (url, name) => { try { const r = await api(url, { raw: true }); if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || 'فشل التصدير'); } const b = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); toast('تم التحميل'); } catch (e) { toast(e.message, true); } };
  $('#ecomb').onclick = () => dl('/api/export/combined' + q(), 'الملف الجامع.xlsx');
  $('#eall').onclick = () => dl('/api/export/all' + q(), 'الملفات النهائية.zip');
  v.addEventListener('click', e => { const b = e.target.closest('[data-e]'); if (b) dl('/api/export/' + b.dataset.e + q(), b.dataset.e + '.xlsx'); });
  $('#eid').onclick = () => dl('/api/export/' + $('#etpl').value + '?status=all&ids=' + encodeURIComponent($('#eids').value.replace(/\s/g, '')), 'مدارس محددة.xlsx');
}

/* ---------- Google Sheets ---------- */
async function syncView(v) {
  const draw = async () => {
    const s = await api('/api/sync/status'); const adm = App.user.role === 'admin';
    const STT = { ok: ['يعمل', 'ok'], idle: ['غير مفعّل', ''], retrying: ['إعادة محاولة (انقطاع/حصة)', 'warn'], needs_reauth: ['يحتاج إعادة ربط الحساب', 'bad'], error: ['خطأ في الملف/الصلاحية', 'bad'] };
    const [stt, stc] = STT[s.state] || [s.state, ''];
    v.innerHTML = `<div class="notice info small">قاعدة بيانات المنصة هي المصدر الرئيسي؛ Google Sheets نسخة مرآة اختيارية باتجاه واحد (المنصة ← الشيت). أي تعديل يدوي في الشيت يُستبدل عند المزامنة التالية للمدرسة.</div>
    <div class="grid g2"><div class="card"><h2>1) ربط حساب Google</h2>
      <div class="row"><span class="chip ${s.account_linked ? 'ok' : 'warn'}">${s.account_linked ? 'الحساب مربوط' : 'غير مربوط'}</span>${adm ? `<button class="btn sm pri" id="gl" ${s.has_client ? '' : 'disabled'}>${s.account_linked ? 'إعادة الربط' : 'ربط الحساب'}</button>${s.account_linked ? '<button class="btn sm bad" id="gd">فصل</button>' : ''}` : ''}</div>
      ${adm ? `<details style="margin-top:12px"${s.has_client ? '' : ' open'}><summary class="small">إعداد OAuth (مرة واحدة)</summary><div class="small muted" style="margin:8px 0">في Google Cloud Console: أنشئ مشروعاً ← فعّل Google Sheets API ← OAuth consent screen (External) ← انشر التطبيق «In production» كي لا تنتهي الصلاحية بعد 7 أيام ← أنشئ OAuth Client (Web) وأضف Redirect URI:<br><code style="direction:ltr;display:block;margin-top:4px">${location.origin}/api/google/callback</code></div>
      <input class="inp" id="cid" placeholder="Client ID" style="width:100%;margin:4px 0"><input class="inp" id="csec" placeholder="Client Secret" type="password" style="width:100%"><button class="btn sm" id="csave" style="margin-top:8px">حفظ</button></details>` : ''}</div>
    <div class="card"><h2>2) ملف Google Sheets</h2>${s.spreadsheet_url ? `<div class="row"><a href="${s.spreadsheet_url}" target="_blank">${esc(s.spreadsheet_title || 'فتح الملف')}</a></div>` : '<div class="muted small">لم يُختر ملف</div>'}
      ${adm ? `<div class="row" style="margin-top:10px"><input class="inp" id="surl" placeholder="رابط أو معرّف ملف موجود" style="flex:1"><button class="btn sm" id="slink">ربط</button></div>
      <div class="row" style="margin-top:8px"><button class="btn sm" id="screate" ${s.account_linked ? '' : 'disabled'}>إنشاء ملف جديد بالأوراق الأربع</button></div>` : ''}</div></div>
    <div class="card" style="margin-top:14px"><h2>3) التحكم والحالة</h2><div class="row"><span class="chip ${stc}">${stt}</span>${adm ? `<label><input type="checkbox" id="sen" ${s.enabled ? 'checked' : ''}> تفعيل المزامنة التلقائية</label>` : ''}
      <span class="spacer"></span>${adm || App.user.role === 'reviewer' ? `<button class="btn sm" id="srun">مزامنة الآن</button><button class="btn sm" id="sretry" ${s.failed_count ? '' : 'disabled'}>إعادة محاولة الفاشلة</button>` : ''}${adm ? '<button class="btn sm" id="sre">إعادة مزامنة كاملة</button>' : ''}</div>
      <div class="grid g4" style="margin-top:12px"><div class="card stat ok"><div class="n">${s.synced}</div><div class="l">مدارس تمت مزامنتها</div></div><div class="card stat warn"><div class="n">${s.pending}</div><div class="l">بانتظار المزامنة</div></div><div class="card stat bad"><div class="n">${s.failed_count}</div><div class="l">فشلت مزامنتها</div></div></div>
      ${s.last_success ? `<div class="muted small" style="margin-top:8px">آخر مزامنة ناجحة: ${esc(s.last_success)}</div>` : ''}${s.last_error ? `<div class="notice bad small">${esc(s.last_error)}</div>` : ''}
      ${Object.keys(s.synced_by_sheet).length ? '<div class="small muted" style="margin-top:6px">' + Object.entries(s.synced_by_sheet).map(([a, b]) => esc(a) + ': ' + b).join(' · ') + '</div>' : ''}
      ${s.failed.length ? `<table class="t" style="margin-top:12px"><tr><th>المدرسة</th><th>الورقة</th><th>سبب الفشل</th><th></th></tr>${s.failed.map(f => `<tr><td>${esc(f.name)}<div class="muted small">${f.school_id}</div></td><td>${esc(f.sheet)}</td><td class="small">${esc(f.last_error || '')}</td><td><button class="btn sm" data-r="${f.school_id}">إعادة</button></td></tr>`).join('')}</table>` : ''}</div>`;
    const on = (id, fn) => { const el = $('#' + id); if (el) el.onclick = async () => { try { await fn(); } catch (e) { toast(e.message, true); } draw(); }; };
    on('gl', async () => { const j = await api('/api/google/auth-url'); location.href = j.url; });
    on('gd', async () => { if (confirm('فصل الحساب؟')) await api('/api/sync/disconnect', { method: 'POST' }); });
    on('csave', async () => { await api('/api/sync/settings', { method: 'PUT', json: { client_id: $('#cid').value, client_secret: $('#csec').value } }); toast('حُفظ'); });
    on('slink', async () => { await api('/api/sync/settings', { method: 'PUT', json: { spreadsheet: $('#surl').value } }); toast('رُبط الملف'); });
    on('screate', async () => { await api('/api/sync/create', { json: {} }); toast('أُنشئ الملف'); });
    on('srun', async () => { const j = await api('/api/sync/run', { method: 'POST' }); toast('تمت مزامنة ' + j.result.done); });
    on('sretry', async () => { const j = await api('/api/sync/retry', { json: {} }); toast('أُعيدت ' + j.retried); });
    on('sre', async () => { if (confirm('إضافة كل الكراسات المعتمدة لطابور المزامنة؟')) { const j = await api('/api/sync/resync', { method: 'POST' }); toast('أُضيف ' + j.queued); } });
    const en = $('#sen'); if (en) en.onchange = async () => { try { await api('/api/sync/settings', { method: 'PUT', json: { enabled: en.checked } }); } catch (e) { toast(e.message, true); } draw(); };
    $$('[data-r]', v).forEach(b => b.onclick = async () => { await api('/api/sync/retry', { json: { school_id: b.dataset.r } }); draw(); });
  };
  await draw(); const t = setInterval(() => { if (!document.activeElement || !['INPUT'].includes(document.activeElement.tagName)) draw(); }, 8000); return () => clearInterval(t);
}


/* ---------- نشاط الموظفين (للمدير) ---------- */
function ago(sec) { if (sec == null) return 'لم يدخل بعد'; if (sec < 90) return 'الآن'; if (sec < 3600) return 'منذ ' + Math.round(sec / 60) + ' د'; if (sec < 86400) return 'منذ ' + Math.round(sec / 3600) + ' س'; return 'منذ ' + Math.round(sec / 86400) + ' يوم'; }
async function activityView(v) {
  let filter = '', open = null, q = '';
  const draw = async () => {
    const [a, e] = await Promise.all([api('/api/admin/activity'), api('/api/admin/entries?limit=150' + (filter ? '&user=' + filter : '') + (q ? '&q=' + encodeURIComponent(q) : ''))]);
    let det = '';
    if (open) { try { const f = await api('/api/admin/booklet/' + open + '/forms'); det = `<div class="card" style="margin-top:12px"><h2>من أدخل كل استمارة — كراس #${open}</h2><table class="t"><tr><th>الاستمارة / القسم</th><th>المدخلون</th><th>الخانات المملوءة</th></tr>${f.forms.map(x => `<tr><td>${esc(x.title.slice(0, 90))}</td><td>${x.entered.length ? x.entered.map(en => `<span class="chip ${en.name === 'الذكاء الاصطناعي' ? 'ai' : en.name === 'قائمة المدارس' ? '' : 'brand'}">${esc(en.name)} · ${en.n}</span>`).join(' ') : '<span class="muted">لم تُدخل</span>'}</td><td>${x.filled}/${x.total}</td></tr>`).join('')}</table></div>`; } catch (er) { det = ''; } }
    const stl = { approved: ['معتمد', 'ok'], review: ['قيد المراجعة', 'warn'], draft: ['غير مكتمل', ''] };
    v.innerHTML = `<div class="grid g4"><div class="card stat ok"><div class="n">${a.online}</div><div class="l">متصلون الآن</div></div><div class="card stat"><div class="n">${a.users.filter(u => u.active).length}</div><div class="l">حسابات فعّالة</div></div><div class="card stat"><div class="n">${nf(a.fields_today)}</div><div class="l">خانات أُدخلت اليوم</div></div></div>
    <div class="card" style="margin-top:14px;padding:0;overflow:auto"><table class="t"><tr><th>الموظف</th><th>الحالة</th><th>آخر نشاط</th><th>اليوم</th><th>إجمالي الخانات</th><th>كراسات دخل بها</th><th>اعتمد</th><th></th></tr>
      ${a.users.map(u => `<tr class="${filter == u.id ? 'sel' : ''}"><td><b>${esc(u.name)}</b><div class="muted small" style="direction:ltr;text-align:right">${esc(u.username)}</div></td>
      <td>${!u.active ? '<span class="chip bad">معطّل</span>' : u.online ? '<span class="chip ok">● متصل</span>' : '<span class="chip">غير متصل</span>'}</td><td class="small">${ago(u.last_seen_ago)}${u.last_seen ? '<div class="muted">' + esc(u.last_seen) + '</div>' : ''}</td>
      <td>${nf(u.fields_today)}</td><td>${nf(u.fields_total)}</td><td>${nf(u.booklets)}</td><td>${nf(u.approved)}</td><td><button class="btn sm" data-uf="${u.id}">${filter == u.id ? 'إلغاء التصفية' : 'عرض كراساته'}</button></td></tr>`).join('')}</table></div>
    <div class="row" style="margin:14px 0 8px"><h2 style="margin:0">الكراسات ومن أدخلها</h2><span class="spacer"></span><input class="inp" id="aq" placeholder="رقم أو اسم مدرسة" value="${esc(q)}"></div>
    <div class="card" style="padding:0;max-height:50vh;overflow:auto"><table class="t"><tr><th>المدرسة</th><th>الحالة</th><th>أدخلها</th><th>اعتمدها</th><th>آخر تعديل</th><th></th></tr>
      ${e.entries.map(r => { const [t, c] = stl[r.status] || [r.status, '']; return `<tr><td>${esc(r.name)}<div class="muted small">${r.sid}</div></td><td><span class="chip ${c}">${t}</span></td>
      <td>${r.entered_by.length ? r.entered_by.map(w => `<span class="chip brand">${esc(w.name)} · ${w.n}</span>`).join(' ') : (r.source === 'ai' ? '<span class="chip ai">ذكاء اصطناعي</span>' : '<span class="muted">—</span>')}</td>
      <td class="small">${esc(r.approved_by || '—')}</td><td class="small muted">${esc(r.updated_at || '')}</td><td><button class="btn sm" data-bf="${r.id}">الاستمارات</button></td></tr>`; }).join('') || '<tr><td colspan="6" class="muted">لا كراسات</td></tr>'}</table></div>${det}`;
  };
  v.onclick = async e => { const b = e.target.closest('[data-uf],[data-bf]'); if (!b) return; if (b.dataset.uf) filter = filter == b.dataset.uf ? '' : b.dataset.uf; if (b.dataset.bf) open = open == b.dataset.bf ? null : b.dataset.bf; await draw(); };
  v.oninput = e => { if (e.target.id === 'aq') { q = e.target.value; clearTimeout(activityView.t); activityView.t = setTimeout(async () => { await draw(); const i = $('#aq', v); i.focus(); i.setSelectionRange(99, 99); }, 350); } };
  await draw(); const t = setInterval(() => { if (document.activeElement?.id !== 'aq') draw().catch(() => { }); }, 15000); return () => clearInterval(t);
}

/* ---------- حسابي ---------- */
async function accountView(v) {
  v.innerHTML = `<div class="card" style="max-width:520px"><h2>حسابي</h2><div class="muted small" style="margin-bottom:10px">${esc(App.user.name)} · ${ROLE_LBL[App.user.role]}</div>
    <label>اسم الدخول</label><input class="inp" id="au" value="${esc(App.user.username)}" style="width:100%;direction:ltr">
    <label>كلمة المرور الجديدة (اتركها فارغة لعدم التغيير)</label><input class="inp" id="anp" type="password" autocomplete="new-password" style="width:100%">
    <label>كلمة المرور الحالية (مطلوبة للتأكيد)</label><input class="inp" id="acp" type="password" autocomplete="current-password" style="width:100%">
    <div id="aerr" class="notice bad hide"></div><button class="btn pri" id="asave" style="margin-top:16px">حفظ</button></div>`;
  $('#asave').onclick = async () => { const er = $('#aerr'); er.classList.add('hide'); try { const j = await api('/api/me/account', { json: { current_password: $('#acp').value, username: $('#au').value, new_password: $('#anp').value } }); App.user = j.user; toast('تم الحفظ'); $('#acp').value = $('#anp').value = ''; } catch (e) { er.textContent = e.message; er.classList.remove('hide'); } };
}

/* ---------- نقل البيانات بين الأجهزة (حزم بلا إنترنت) ---------- */
async function packView(v) {
  const info = await api('/api/pack/info'); const adm = App.user.role === 'admin';
  v.innerHTML = `<div class="notice info small">لكل جهاز نسخته الكاملة من البرنامج. حين تريد جمع البيانات: صدّر «حزمة بيانات» من كل جهاز (فلاش أو أي وسيلة نقل)، ثم استوردها كلها على الجهاز الرئيسي. الدمج بالرقم الإحصائي فلا تتكرر مدرسة، وإن أُدخلت خانة بقيمتين مختلفتين يُعرض التعارض وتغلب القيمة الأحدث.</div>
  <div class="grid g2"><div class="card"><h2>1) تصدير حزمة من هذا الجهاز</h2>
    <div class="row"><label>اسم الجهاز:</label><input class="inp" id="pcn" value="${esc(info.computer_name)}" ${adm ? '' : 'disabled'}>${adm ? '<button class="btn sm" id="pcs">حفظ الاسم</button>' : ''}</div>
    <div class="muted small" style="margin:8px 0">كراسات هذا الجهاز: ${nf(info.booklets)}</div>
    <button class="btn pri" id="pex">⇩ تصدير حزمة البيانات (.sstats)</button></div>
  <div class="card"><h2>2) استيراد حزم من أجهزة أخرى</h2>
    <input type="file" id="pif" multiple accept=".sstats"><div style="margin-top:10px"><button class="btn pri" id="pim">استيراد ودمج</button></div>
    <div class="muted small" style="margin-top:8px">يمكن اختيار عدة حزم دفعة واحدة. أعد الاستيراد متى شئت: لا يكرر شيئاً.</div></div></div><div id="prep"></div>`;
  $('#pcs') && ($('#pcs').onclick = async () => { try { await api('/api/pack/info', { method: 'PUT', json: { computer_name: $('#pcn').value } }); toast('حُفظ'); } catch (e) { toast(e.message, true); } });
  $('#pex').onclick = async () => { try { const r = await api('/api/pack/export', { raw: true }); if (!r.ok) throw new Error('فشل التصدير'); const cd = r.headers.get('content-disposition') || ''; const b = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = decodeURIComponent((cd.match(/filename\*=UTF-8''([^;]+)/) || [])[1] || 'data.sstats'); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); toast('تم تصدير الحزمة'); } catch (e) { toast(e.message, true); } };
  $('#pim').onclick = async () => {
    const fs = $('#pif').files; if (!fs.length) { toast('اختر ملفاً', true); return; }
    const fd = new FormData(); for (const f of fs) fd.append('file', f);
    try {
      const j = await api('/api/pack/import', { method: 'POST', body: fd });
      $('#prep').innerHTML = j.reports.map(r => r.error ? `<div class="notice bad" style="margin-top:12px"><b>${esc(r.file)}</b>: ${esc(r.error)}</div>` :
        `<div class="card" style="margin-top:12px"><h2>${esc(r.file)} — من جهاز «${esc(r.computer || '')}»</h2><div class="row"><span class="chip ok">كراسات: ${r.booklets}</span><span class="chip brand">جديدة: ${r.created}</span><span class="chip">خانات جديدة: ${r.fields_new}</span><span class="chip">خانات حُدّثت: ${r.fields_updated}</span><span class="chip">متطابقة: ${r.fields_same}</span><span class="chip ${r.conflicts.length ? 'warn' : ''}">تعارضات: ${r.conflicts.length}</span>${r.skipped.length ? `<span class="chip bad">متخطاة: ${r.skipped.length}</span>` : ''}</div>
        ${r.conflicts.length ? `<table class="t" style="margin-top:10px"><tr><th>المدرسة</th><th>الخانة</th><th>المحلية</th><th>الواردة</th><th>الفائز</th></tr>${r.conflicts.map(c => `<tr><td>${esc(c.school)}<div class="muted small">${c.school_id}</div></td><td class="small">${esc(c.field)}</td><td>${esc(c.local)}</td><td>${esc(c.incoming)}</td><td><span class="chip ${c.winner === 'الوارد' ? 'brand' : ''}">${c.winner}</span></td></tr>`).join('')}</table>` : ''}</div>`).join('');
      toast('انتهى الاستيراد'); Schools.loaded = false;
    } catch (e) { toast(e.message, true); }
  };
}

/* ---------- المستخدمون / السجل ---------- */
async function usersView(v) {
  const draw = async () => {
    const j = await api('/api/users'); const s = await api('/api/settings');
    v.innerHTML = `<div class="card"><table class="t"><tr><th>اسم الدخول (يمكن تغييره)</th><th>الاسم</th><th>الدور</th><th>فعّال</th><th></th></tr>${j.users.map(u => `<tr><td><input class="inp" data-un="${u.id}" value="${esc(u.username)}" style="width:140px;direction:ltr"></td><td><input class="inp" data-nm="${u.id}" value="${esc(u.name)}" style="width:170px"></td>
      <td><select class="inp" data-role="${u.id}">${Object.entries(ROLE_LBL).map(([k, l]) => `<option value="${k}" ${k === u.role ? 'selected' : ''}>${l}</option>`).join('')}</select></td>
      <td><input type="checkbox" data-act="${u.id}" ${u.active ? 'checked' : ''}></td><td><button class="btn sm" data-pw="${u.id}">كلمة مرور جديدة</button></td></tr>`).join('')}</table></div>
    <div class="card" style="margin-top:14px"><h2>مستخدم جديد</h2><div class="row"><input class="inp" id="nu" placeholder="اسم المستخدم"><input class="inp" id="nn" placeholder="الاسم الكامل"><input class="inp" id="np" type="password" placeholder="كلمة المرور (6+)">
      <select class="inp" id="nr">${Object.entries(ROLE_LBL).map(([k, l]) => `<option value="${k}" ${k === 'entry' ? 'selected' : ''}>${l}</option>`).join('')}</select><button class="btn pri" id="nadd">إضافة</button></div></div>
    <div class="card" style="margin-top:14px"><h2>إعدادات العمل</h2><div class="row"><label class="small"><input type="checkbox" id="srr" ${s.require_review ? 'checked' : ''}> موظف الإدخال يرسل للمراجعة ولا يعتمد بنفسه</label>
      <label class="small"><input type="checkbox" id="seae" ${s.entry_can_edit_approved ? 'checked' : ''}> السماح لموظف الإدخال بتعديل الكراسات المعتمدة</label><label class="small">السنة: <input class="inp" id="syr" value="${esc(s.year)}" style="width:110px"></label><button class="btn sm" id="ssave">حفظ</button></div></div>
    <div class="card" style="margin-top:14px"><h2>استيراد/تحديث قائمة المدارس (Excel)</h2><div class="row"><input type="file" id="imf" accept=".xlsx"><button class="btn sm" id="imb">استيراد</button><span class="muted small">لا يحذف مدارس ولا يكرر الرقم الإحصائي</span></div></div>`;
    v.onchange = async e => { const t = e.target; try { if (t.dataset.un) await api('/api/users/' + t.dataset.un, { method: 'PATCH', json: { username: t.value } }); else if (t.dataset.nm) await api('/api/users/' + t.dataset.nm, { method: 'PATCH', json: { name: t.value } }); else if (t.dataset.role) await api('/api/users/' + t.dataset.role, { method: 'PATCH', json: { role: t.value } }); else if (t.dataset.act) await api('/api/users/' + t.dataset.act, { method: 'PATCH', json: { active: t.checked } }); toast('حُفظ'); } catch (er) { toast(er.message, true); draw(); } };
    v.onclick = async e => { const t = e.target; try {
      if (t.dataset.pw) { const p = prompt('كلمة المرور الجديدة (6 أحرف+)'); if (p) { await api('/api/users/' + t.dataset.pw, { method: 'PATCH', json: { password: p } }); toast('تم'); } }
      if (t.id === 'nadd') { await api('/api/users', { json: { username: $('#nu').value, name: $('#nn').value, password: $('#np').value, role: $('#nr').value } }); toast('أُضيف'); draw(); }
      if (t.id === 'ssave') { await api('/api/settings', { method: 'PUT', json: { require_review: $('#srr').checked, entry_can_edit_approved: $('#seae').checked, year: $('#syr').value } }); toast('حُفظ'); }
      if (t.id === 'imb') { const f = $('#imf').files[0]; if (!f) return; const fd = new FormData(); fd.append('file', f); const j = await api('/api/schools/import', { method: 'POST', body: fd }); toast(`أُضيف ${j.added} · حُدّث ${j.updated}`); await Schools.load(true); }
    } catch (er) { toast(er.message, true); } };
  };
  await draw();
}
async function auditView(v) {
  const j = await api('/api/audit?limit=300');
  v.innerHTML = `<div class="card" style="padding:0;max-height:78vh;overflow:auto"><table class="t"><tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>المدرسة</th><th>التفاصيل</th></tr>${j.rows.map(r => `<tr><td class="small" style="white-space:nowrap">${esc(r.ts)}</td><td>${esc(r.username || '—')}</td><td><span class="chip brand">${esc(r.action)}</span></td><td>${esc(r.school_id || '')}</td><td class="small muted" style="max-width:520px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(r.detail || '')}">${esc(r.detail || '')}</td></tr>`).join('')}</table></div>`;
}

/* ---------- الموجّه ---------- */
async function boot() { try { App.settings = await api('/api/settings'); } catch { } }
async function route() {
  if (cleanup) { try { cleanup(); } catch { } cleanup = null; }
  const [path, qs] = (location.hash || '#/').split('?'); const query = new URLSearchParams(qs || '');
  const parts = path.replace(/^#\/?/, '').split('/'); const name = parts[0] || '';
  if (!App.user) { try { const j = await api('/api/me'); App.user = j.user; App.credit = j.credit; await boot(); } catch { } }
  if (!App.user) { if (name !== 'login') { location.hash = '#/login'; return; } return loginView(); }
  if (name === 'login') { location.hash = '#/'; return; }
  const V = { '': ['لوحة التحكم', dashView, '#/'], entry: ['الإدخال السريع', EntryView, '#/entry'], schools: ['المدارس', schoolsView, '#/schools'], uploads: ['رفع وقراءة الكراسات', uploadsView, '#/uploads'],
    review: ['مراجعة القراءة الآلية', reviewView, '#/uploads'], export: ['تصدير ملفات Excel', exportView, '#/export'], sync: ['مزامنة Google Sheets', syncView, '#/sync'], users: ['المستخدمون والإعدادات', usersView, '#/users'], activity: ['نشاط الموظفين', activityView, '#/activity'], account: ['حسابي', accountView, ''], pack: ['نقل البيانات بين الأجهزة', packView, '#/pack'], audit: ['سجل العمليات', auditView, '#/audit'] }[name];
  if (!V) { location.hash = '#/'; return; }
  const v = shell(V[0], '', V[2]);
  try { cleanup = await V[1](v, parts.slice(1), query); } catch (e) { v.innerHTML = `<div class="notice bad">${esc(e.message)}</div>`; }
}
setInterval(() => { if (App.user && net.online) api('/api/ping', { method: 'POST' }).catch(() => { }); }, 60000);   // نبضة تُبقي الموظف «متصلاً» وهو يقرأ
addEventListener('hashchange', route);
route();
