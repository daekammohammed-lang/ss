"""محرك الاستمارات: تحميل التعريفات، حساب المجاميع، التحقق."""
import json, os, re, functools

ROOT = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_IDS = ("primary", "secondary", "kg")
TEMPLATE_TITLES = {"primary": "الابتدائي / الأساسي / المتوسط", "secondary": "الثانوي (متوسط + إعدادي)",
                   "kg": "رياض الأطفال"}


@functools.lru_cache(maxsize=8)
def load_form(tid):
    with open(os.path.join(ROOT, "forms", tid + ".json"), encoding="utf-8") as f:
        return json.load(f)


_AR = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def to_num(v):
    """يحوّل نص الخلية إلى رقم؛ يقبل الأرقام العربية-الهندية. None إن كان فارغاً/غير رقمي."""
    if v is None:
        return None
    s = str(v).strip().translate(_AR)
    if s == "":
        return None
    try:
        f = float(s)
    except ValueError:
        return None
    return int(f) if f == int(f) else f


def compute(form, values):
    """values: {key: raw}. يعيد {key: number|None} لكل الحقول المحسوبة."""
    fields = form["fields"]
    cache = {}

    def val(k):
        f = fields.get(k)
        if f is None:
            return None
        if f["type"] == "computed":
            if k in cache:
                return cache[k]
            cache[k] = None  # حماية من الدوران
            parts = [val(r) for r in f["sum"]]
            cache[k] = None if all(p is None for p in parts) else sum(p or 0 for p in parts)
            return cache[k]
        return to_num(values.get(k))

    return {k: val(k) for k, f in fields.items() if f["type"] == "computed"}


def validate(form, values, paper=None):
    """تحذيرات وأخطاء: {key: [{level, msg}]}"""
    out = {}
    fields = form["fields"]

    def add(k, level, msg):
        out.setdefault(k, []).append(dict(level=level, msg=msg))

    comp = compute(form, values)
    for k, f in fields.items():
        v = values.get(k)
        if f["type"] == "number":
            if v in (None, ""):
                continue
            n = to_num(v)
            if n is None:
                add(k, "error", "ليس رقماً")
            elif n < 0:
                add(k, "error", "قيمة سالبة")
            elif n != int(n):
                add(k, "error", "يجب أن يكون عدداً صحيحاً")
            elif n > 3000 and "سنة" not in " ".join(f["path"]) and "GPS" not in " ".join(f["path"]):
                add(k, "warn", "رقم كبير جداً — تأكد")
        elif f["type"] == "check":
            if v not in (None, "", "0", "1", 0, 1):
                add(k, "error", "قيمة اختيار غير صالحة")
    if paper:
        for k, pv in paper.items():
            f = fields.get(k)
            if f and f["type"] == "computed":
                a, b = to_num(pv), comp.get(k)
                if a is not None and (b or 0) != a:
                    add(k, "error", "مجموع الورق %s لا يطابق المحسوب %s" % (a, b if b is not None else 0))
    return out


def completion(form, values):
    """نسبة الحقول الرقمية المعبّأة — مؤشر تقريبي (كثير من الخلايا يبقى فارغاً بطبيعته)."""
    nums = [k for k, f in form["fields"].items() if f["type"] == "number"]
    filled = sum(1 for k in nums if values.get(k) not in (None, ""))
    return dict(filled=filled, total=len(nums))


def apply_exclusive_groups(form, changes, current):
    """عند اختيار خيار في مجموعة اختيار حصرية يُصفَّر الباقي (يُستدعى من الخادم لضمان الاتساق)."""
    return changes
