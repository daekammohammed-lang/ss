"""نقطة دخول البرنامج المستقل (SchoolStats.exe): جهاز واحد، بلا دخول، بلا إنترنت."""
import os, sys, threading, webbrowser, time
if getattr(sys, "frozen", False):
    os.chdir(os.path.dirname(sys.executable))
os.environ.setdefault("SCHOOLSTATS_DB", os.path.join(os.getcwd(), "data", "app.db"))   # البيانات بجانب البرنامج لا داخل ملفاته
os.environ.setdefault("LOCAL_MODE", "1")
os.environ.setdefault("HOST", "127.0.0.1")
os.environ.setdefault("ADMIN_PASSWORD", "local-only-not-exposed")
from app import app, bootstrap
bootstrap()
threading.Thread(target=lambda: (time.sleep(1.5), webbrowser.open("http://127.0.0.1:8000")), daemon=True).start()
try:
    from waitress import serve
    serve(app, host="127.0.0.1", port=8000, threads=8)
except ImportError:
    app.run(host="127.0.0.1", port=8000, threaded=True)
