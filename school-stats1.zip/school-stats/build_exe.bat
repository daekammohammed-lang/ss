@echo off
chcp 65001 >nul
rem يبني برنامجاً واحداً (SchoolStats.exe) يعمل على أي ويندوز بدون تثبيت بايثون. شغّله مرة واحدة على جهاز عليه إنترنت وبايثون.
cd /d "%~dp0"
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt pyinstaller
pyinstaller --noconfirm --onedir --name SchoolStats --add-data "static;static" --add-data "forms;forms" --add-data "templates_xlsx;templates_xlsx" --add-data "data\schools_master.xlsx;data" --add-data "reports;reports" desktop.py
echo.
echo تم. انسخ المجلد dist\SchoolStats كاملاً إلى الأجهزة، وشغّل SchoolStats.exe (بيانات كل جهاز تُحفظ في مجلد data بجانبه).
pause
