"""مزامنة Google Sheets — نسخة مرآة اختيارية باتجاه واحد (القاعدة الداخلية هي المصدر).

التصميم:
* نمط Outbox: عند اعتماد/تعديل كراس يُسجَّل «مهمة مزامنة» في القاعدة (جدول sync_jobs) دون انتظار Google.
* عامل خلفي واحد يعالج المهام دفعات، ويقرأ بيانات الكراس الحالية وقت التنفيذ (فلا تُرسَل نسخة قديمة).
* الرقم الإحصائي هو المفتاح: يُقرأ العمود A من الشيت قبل كل دفعة، فإن وُجد الصف يُحدَّث وإلا يُضاف. لا تكرار أبداً،
  حتى لو انقطع الاتصال بعد نجاح الكتابة وقبل وصول الرد.
* أخطاء مصنَّفة: network/quota/server ← إعادة محاولة بتأخير متصاعد؛ auth ← إيقاف المزامنة وطلب إعادة الربط؛
  notfound/permission ← فشل ظاهر في اللوحة مع زر إعادة المحاولة.
"""
import os, io, json, time, threading, re, secrets, traceback, logging
import requests
try:
    from cryptography.fernet import Fernet
except ImportError:     # يعمل النظام بدونها؛ تلزم فقط لربط Google
    Fernet = None
from flask import request, jsonify, g, redirect
import db, forms

log = logging.getLogger("syncer")
ROOT = os.path.dirname(os.path.abspath(__file__))
SCOPES = "https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file"

# الأوراق: الاسم، القالب (None = ملخص)
SHEETS = {
    "primary": "المدارس الابتدائية",
    "secondary": "المدارس الثانوية",
    "ahli": "المدارس الأهلية",
    "kg": "رياض الأطفال",
}
AHLI_COLS = ["الرقم الإحصائي", "حالة الكراس", "آخر تحديث", "اسم المدرسة", "القالب", "التصنيف", "الجنس", "البيئة",
             "الدوام", "العائدية", "عدد الحقول المدخلة"]
MAX_ATTEMPTS = 8
BATCH = 25

_lock = threading.Lock()
_worker = None
_stop = threading.Event()
api_override = None  # للاختبارات


class SyncError(Exception):
    def __init__(self, kind, msg, retry=False):
        super().__init__(msg)
        self.kind, self.retry = kind, retry


# ------------------------------------------------------------------ تشفير الرموز
def _fernet():
    if Fernet is None:
        raise SyncError('config', 'مكتبة cryptography غير مثبتة؛ ثبّتها (pip install cryptography) لاستعمال ربط Google')
    p = os.path.join(os.path.dirname(db.DB_PATH), "secret.key")
    key = os.environ.get("SECRET_KEY")
    if key:
        return Fernet(key.encode())
    if not os.path.exists(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(Fernet.generate_key())
    return Fernet(open(p, "rb").read().strip())


def put_secret(name, value):
    db.set_setting(name, _fernet().encrypt(value.encode()).decode() if value else "")


def get_secret(name):
    v = db.get_setting(name)
    if not v:
        return None
    try:
        return _fernet().decrypt(v.encode()).decode()
    except Exception:
        return None


# ------------------------------------------------------------------ عميل Google
class SheetsAPI:
    BASE = "https://sheets.googleapis.com/v4/spreadsheets"

    def __init__(self):
        self.token = None
        self.token_exp = 0

    # --- OAuth
    @staticmethod
    def auth_url(redirect_uri, state):
        cid = get_secret("g_client_id")
        if not cid:
            raise SyncError("config", "لم يُضبط معرّف عميل OAuth")
        from urllib.parse import urlencode
        return "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(
            dict(client_id=cid, redirect_uri=redirect_uri, response_type="code", scope=SCOPES,
                 access_type="offline", prompt="consent", state=state))

    @staticmethod
    def exchange_code(code, redirect_uri):
        r = requests.post("https://oauth2.googleapis.com/token", timeout=30, data=dict(
            code=code, client_id=get_secret("g_client_id"), client_secret=get_secret("g_client_secret"),
            redirect_uri=redirect_uri, grant_type="authorization_code"))
        if r.status_code != 200:
            raise SyncError("auth", "فشل تبادل رمز Google: %s" % r.text[:200])
        j = r.json()
        if j.get("refresh_token"):
            put_secret("g_refresh_token", j["refresh_token"])
        return j

    def _access(self):
        if self.token and time.time() < self.token_exp - 60:
            return self.token
        rt = get_secret("g_refresh_token")
        if not rt:
            raise SyncError("auth", "الحساب غير مربوط")
        try:
            r = requests.post("https://oauth2.googleapis.com/token", timeout=30, data=dict(
                client_id=get_secret("g_client_id"), client_secret=get_secret("g_client_secret"),
                refresh_token=rt, grant_type="refresh_token"))
        except requests.RequestException as e:
            raise SyncError("network", "تعذّر الاتصال بـ Google: %s" % e, retry=True)
        if r.status_code != 200:
            kind = "auth" if r.status_code in (400, 401) else "server"
            raise SyncError(kind, "فشل تجديد الصلاحية (%s): %s" % (r.status_code, r.text[:160]), retry=kind != "auth")
        j = r.json()
        self.token, self.token_exp = j["access_token"], time.time() + j.get("expires_in", 3600)
        return self.token

    def _call(self, method, url, **kw):
        for attempt in range(3):
            try:
                r = requests.request(method, url, timeout=60, headers={"Authorization": "Bearer " + self._access()}, **kw)
            except requests.RequestException as e:
                raise SyncError("network", "انقطاع الاتصال: %s" % e, retry=True)
            if r.status_code == 401 and attempt == 0:
                self.token = None
                continue
            break
        if r.status_code == 200:
            return r.json()
        msg = r.text[:300]
        if r.status_code == 429 or (r.status_code == 403 and "rateLimit" in msg) or "RATE_LIMIT" in msg:
            raise SyncError("quota", "تجاوز حصة Google API: " + msg, retry=True)
        if r.status_code >= 500:
            raise SyncError("server", "خطأ من Google (%s)" % r.status_code, retry=True)
        if r.status_code == 404:
            raise SyncError("notfound", "الملف غير موجود أو حُذف")
        if r.status_code in (401,):
            raise SyncError("auth", "انتهت صلاحية الربط: " + msg)
        if r.status_code == 403:
            raise SyncError("permission", "لا تملك صلاحية على الملف: " + msg)
        raise SyncError("other", "خطأ %s: %s" % (r.status_code, msg))

    # --- عمليات الجداول
    def create_spreadsheet(self, title, sheet_titles):
        j = self._call("POST", self.BASE, json=dict(properties=dict(title=title),
                       sheets=[dict(properties=dict(title=t, rightToLeft=True)) for t in sheet_titles]))
        return j["spreadsheetId"], j.get("spreadsheetUrl")

    def meta(self, sid):
        j = self._call("GET", "%s/%s" % (self.BASE, sid),
                       params=dict(fields="properties.title,sheets.properties(sheetId,title,gridProperties)"))
        return dict(title=j["properties"]["title"],
                    sheets={s["properties"]["title"]: s["properties"] for s in j["sheets"]})

    def batch_update(self, sid, requests_):
        return self._call("POST", "%s/%s:batchUpdate" % (self.BASE, sid), json=dict(requests=requests_))

    def get_column(self, sid, sheet, col="A"):
        j = self._call("GET", "%s/%s/values/%s" % (self.BASE, sid, requests.utils.quote("'%s'!%s:%s" % (sheet, col, col))))
        return [(r[0] if r else "") for r in j.get("values", [])]

    def write_rows(self, sid, data):
        """data: [(range_a1, [[...]])] — يكتب دفعة واحدة (RAW)."""
        body = dict(valueInputOption="RAW", data=[dict(range=r, majorDimension="ROWS", values=v) for r, v in data])
        return self._call("POST", "%s/%s/values:batchUpdate" % (self.BASE, sid), json=body)


def get_api():
    return api_override or SheetsAPI()


# ------------------------------------------------------------------ مخطط الأوراق
def sheet_for(school):
    return SHEETS["ahli"] if school["ownership"] == "اهلي" else SHEETS.get(school["template"])


def header_for(sheet_title):
    """ترويسة الصف الأول للورقة."""
    if sheet_title == SHEETS["ahli"]:
        return AHLI_COLS
    tid = {v: k for k, v in SHEETS.items()}[sheet_title]
    form = forms.load_form(tid)
    hdr = ["الرقم الإحصائي", "حالة الكراس", "آخر تحديث"]
    for c in range(1, form["ncols"] + 1):
        f = form["fields"].get(_L(c))
        hdr.append(" ‹ ".join(f["path"]) if f else _L(c))
    return hdr


def _L(c):
    from openpyxl.utils import get_column_letter
    return get_column_letter(c)


def col_letter(n):
    return _L(n)


def row_for(school_id):
    """يبني صف المدرسة من القاعدة (وقت التنفيذ). None إن لم يوجد كراس."""
    s = db.q1("SELECT * FROM schools WHERE id=?", (school_id,))
    b = db.q1("SELECT * FROM booklets WHERE school_id=? AND year=?", (school_id, db.get_setting("year", "2026-2027")))
    if not s or not b:
        return None
    status = {"approved": "معتمد", "review": "قيد المراجعة", "draft": "غير مكتمل"}[b["status"]]
    vals = {x["k"]: x["v"] for x in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (b["id"],))}
    form = forms.load_form(b["template"])
    sheet = sheet_for(s)
    if sheet == SHEETS["ahli"]:
        n = sum(1 for k, v in vals.items() if v not in (None, "") and form["fields"].get(k, {}).get("type") == "number")
        return sheet, [s["id"], status, b["updated_at"], s["name"], forms.TEMPLATE_TITLES.get(s["template"], ""),
                       s["category"], s["gender"], s["env"], s["shift"], s["ownership"], n]
    comp = forms.compute(form, vals)
    out = [s["id"], status, b["updated_at"]]
    import exporter
    for c in range(1, form["ncols"] + 1):
        k = _L(c)
        f = form["fields"].get(k)
        if not f:
            out.append("")
        elif f["type"] == "seq":
            out.append("")
        else:
            v = exporter._cell_value(f, vals.get(k), comp.get(k))
            out.append("" if v is None else v)
    return sheet, out


# ------------------------------------------------------------------ الطابور
def configured():
    return bool(db.get_setting("g_spreadsheet_id")) and bool(get_secret("g_refresh_token") or api_override)


def enabled():
    return db.get_setting("sync_enabled") == "1" and db.get_setting("sync_state") != "needs_reauth"


def enqueue(school_id, booklet_id=None, reason=""):
    """يسجّل مهمة مزامنة (آمنة للاستدعاء دائماً؛ لا تتصل بالشبكة)."""
    if db.get_setting("sync_enabled") != "1":
        return False
    s = db.q1("SELECT ownership, template FROM schools WHERE id=?", (school_id,))
    if not s:
        return False
    sheet = sheet_for(s)
    if not sheet:
        return False
    # إن تغيّرت الورقة (مثلاً أصبحت مدرسة أهلية) تبقى المهام القديمة؛ الجديدة تُنشأ للورقة الحالية
    cur = db.q1("SELECT id,status FROM sync_jobs WHERE school_id=? AND sheet=? AND status IN ('pending','failed')",
                (school_id, sheet))
    if cur:
        db.ex("UPDATE sync_jobs SET status='pending', attempts=0, next_try=0, last_error=NULL, error_kind=NULL, "
              "updated_at=CURRENT_TIMESTAMP, booklet_id=? WHERE id=?", (booklet_id, cur["id"]))
    else:
        db.ex("INSERT INTO sync_jobs(school_id,booklet_id,sheet) VALUES(?,?,?)", (school_id, booklet_id, sheet))
    return True


def enqueue_all():
    n = 0
    for r in db.q("SELECT school_id FROM booklets WHERE status='approved'"):
        n += 1 if enqueue(r["school_id"]) else 0
    return n


def _ensure_sheets(api, sid):
    """يتأكد من وجود الأوراق الأربع وترويساتها وحجم الشبكة الكافي."""
    meta = api.meta(sid)
    reqs, titles = [], meta["sheets"]
    for title in SHEETS.values():
        need_cols = len(header_for(title))
        if title not in titles:
            reqs.append(dict(addSheet=dict(properties=dict(title=title, rightToLeft=True,
                        gridProperties=dict(rowCount=1000, columnCount=max(need_cols, 26), frozenRowCount=1)))))
        else:
            gp = titles[title].get("gridProperties", {})
            if gp.get("columnCount", 0) < need_cols:
                reqs.append(dict(updateSheetProperties=dict(properties=dict(sheetId=titles[title]["sheetId"],
                            gridProperties=dict(columnCount=need_cols)), fields="gridProperties.columnCount")))
    if reqs:
        api.batch_update(sid, reqs)
        meta = api.meta(sid)
    for title in SHEETS.values():
        first = api.get_column(sid, title, "A")
        if not first or first[0] != "الرقم الإحصائي":
            hdr = header_for(title)
            api.write_rows(sid, [("'%s'!A1:%s1" % (title, _L(len(hdr))), [hdr])])
    return meta


def process_batch(max_jobs=200):
    """يعالج المهام المستحقة. يعيد dict بالنتيجة. آمن للاستدعاء من العامل أو يدوياً."""
    with _lock:
        sid = db.get_setting("g_spreadsheet_id")
        if not sid:
            return dict(done=0, failed=0, skipped="no_spreadsheet")
        jobs = db.q("SELECT * FROM sync_jobs WHERE status='pending' AND next_try<=? ORDER BY id LIMIT ?",
                    (time.time(), max_jobs))
        if not jobs:
            return dict(done=0, failed=0)
        api = get_api()
        done = failed = 0
        try:
            meta = _ensure_sheets(api, sid)
            by_sheet = {}
            for j in jobs:
                by_sheet.setdefault(j["sheet"], []).append(j)
            for sheet, sjobs in by_sheet.items():
                col = api.get_column(sid, sheet, "A")
                index = {v: i + 1 for i, v in enumerate(col) if v and i > 0}   # id → رقم الصف
                next_row = max(len(col), 1) + 1
                for k in range(0, len(sjobs), BATCH):
                    chunk = sjobs[k:k + BATCH]
                    data, sent = [], []
                    for j in chunk:
                        built = row_for(j["school_id"])
                        if not built or built[0] != sheet:
                            db.ex("UPDATE sync_jobs SET status='done', updated_at=CURRENT_TIMESTAMP WHERE id=?", (j["id"],))
                            continue
                        _, vals = built
                        row = index.get(str(j["school_id"]))
                        if row is None:
                            row = next_row
                            next_row += 1
                            index[str(j["school_id"])] = row
                        data.append(("'%s'!A%d:%s%d" % (sheet, row, _L(len(vals)), row), [vals]))
                        sent.append((j, row))
                    if not data:
                        continue
                    # توسيع عدد الصفوف عند الحاجة
                    need = max(r for _, r in sent)
                    have = meta["sheets"][sheet].get("gridProperties", {}).get("rowCount", 1000)
                    if need > have:
                        api.batch_update(sid, [dict(updateSheetProperties=dict(properties=dict(
                            sheetId=meta["sheets"][sheet]["sheetId"], gridProperties=dict(rowCount=need + 500)),
                            fields="gridProperties.rowCount"))])
                        meta["sheets"][sheet]["gridProperties"]["rowCount"] = need + 500
                    try:
                        api.write_rows(sid, data)
                    except SyncError as e:
                        if e.kind != "auth":          # الخطأ في الصلاحية يُبقي المهام معلّقة حتى إعادة الربط
                            _fail_jobs([j for j, _ in sent], e)
                            failed += len(sent)
                        if e.kind in ("auth", "notfound", "permission"):
                            raise
                        continue
                    for j, row in sent:
                        db.ex("UPDATE sync_jobs SET status='done', last_error=NULL, error_kind=NULL, "
                              "updated_at=CURRENT_TIMESTAMP WHERE id=?", (j["id"],))
                        db.ex("INSERT INTO sync_rows(sheet,school_id,row,synced_at) VALUES(?,?,?,CURRENT_TIMESTAMP) "
                              "ON CONFLICT(sheet,school_id) DO UPDATE SET row=excluded.row, synced_at=excluded.synced_at",
                              (sheet, j["school_id"], row))
                        done += 1
            db.set_setting("sync_last_success", time.strftime("%Y-%m-%d %H:%M:%S"))
            db.set_setting("sync_state", "ok")
            db.set_setting("sync_last_error", "")
        except SyncError as e:
            _on_global_error(e, [j for j in jobs if db.q1("SELECT 1 FROM sync_jobs WHERE id=? AND status='pending'", (j["id"],))])
            failed += 0
        return dict(done=done, failed=failed)


def _fail_jobs(jobs, e):
    for j in jobs:
        attempts = j["attempts"] + 1
        if e.retry and attempts < MAX_ATTEMPTS:
            delay = min(10 * 2 ** attempts, 900)
            db.ex("UPDATE sync_jobs SET attempts=?, next_try=?, last_error=?, error_kind=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                  (attempts, time.time() + delay, str(e)[:400], e.kind, j["id"]))
        else:
            db.ex("UPDATE sync_jobs SET status='failed', attempts=?, last_error=?, error_kind=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                  (attempts, str(e)[:400], e.kind, j["id"]))


def _on_global_error(e, jobs):
    db.set_setting("sync_last_error", "%s: %s" % (e.kind, e))
    if e.kind == "auth":
        db.set_setting("sync_state", "needs_reauth")
    elif e.kind in ("notfound", "permission"):
        db.set_setting("sync_state", "error")
    else:
        db.set_setting("sync_state", "retrying")
    if e.kind != "auth":
        _fail_jobs(jobs, e)


def retry_failed(school_id=None):
    sql = "UPDATE sync_jobs SET status='pending', attempts=0, next_try=0, last_error=NULL, error_kind=NULL WHERE status='failed'"
    args = ()
    if school_id:
        sql += " AND school_id=?"
        args = (school_id,)
    cur = db.ex(sql, args)
    if db.get_setting("sync_state") in ("error",):
        db.set_setting("sync_state", "ok")
    return cur.rowcount


def status():
    done_rows = db.q("SELECT sheet, COUNT(*) n FROM sync_rows GROUP BY sheet")
    pend = db.q1("SELECT COUNT(*) n FROM sync_jobs WHERE status='pending'")["n"]
    failed = db.q("SELECT j.school_id, s.name, j.sheet, j.last_error, j.error_kind, j.attempts, j.updated_at FROM sync_jobs j "
                  "JOIN schools s ON s.id=j.school_id WHERE j.status='failed' ORDER BY j.updated_at DESC LIMIT 200")
    sid = db.get_setting("g_spreadsheet_id")
    return dict(enabled=db.get_setting("sync_enabled") == "1", state=db.get_setting("sync_state", "idle"),
                account_linked=bool(get_secret("g_refresh_token")), has_client=bool(get_secret("g_client_id")),
                spreadsheet_id=sid, spreadsheet_url=("https://docs.google.com/spreadsheets/d/%s" % sid) if sid else None,
                spreadsheet_title=db.get_setting("g_spreadsheet_title"),
                synced=sum(r["n"] for r in done_rows), synced_by_sheet={r["sheet"]: r["n"] for r in done_rows},
                pending=pend, failed_count=len(failed), failed=[dict(r) for r in failed],
                last_success=db.get_setting("sync_last_success"), last_error=db.get_setting("sync_last_error"))


# ------------------------------------------------------------------ العامل الخلفي
def _loop():
    while not _stop.is_set():
        try:
            if enabled() and configured():
                process_batch()
        except Exception:
            log.error("sync worker: %s", traceback.format_exc())
        _stop.wait(5)


def start_worker():
    global _worker
    if _worker and _worker.is_alive():
        return
    _stop.clear()
    _worker = threading.Thread(target=_loop, name="sheets-sync", daemon=True)
    _worker.start()


def parse_spreadsheet_id(s):
    s = (s or "").strip()
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", s)
    return m.group(1) if m else (s if re.fullmatch(r"[a-zA-Z0-9-_]{20,}", s) else None)


# ------------------------------------------------------------------ واجهات HTTP
def register(app, auth):
    @app.get("/api/sync/status")
    @auth()
    def sync_status():
        return jsonify(status())

    @app.put("/api/sync/settings")
    @auth(["admin"])
    def sync_settings():
        d = request.get_json(force=True)
        if "client_id" in d and d["client_id"]:
            put_secret("g_client_id", d["client_id"].strip())
        if "client_secret" in d and d["client_secret"]:
            put_secret("g_client_secret", d["client_secret"].strip())
        if "spreadsheet" in d:
            sid = parse_spreadsheet_id(d["spreadsheet"])
            if not sid:
                return jsonify(error="رابط/معرّف الملف غير صالح"), 400
            try:
                meta = get_api().meta(sid)
            except SyncError as e:
                return jsonify(error=str(e), kind=e.kind), 400
            db.set_setting("g_spreadsheet_id", sid)
            db.set_setting("g_spreadsheet_title", meta["title"])
        if "enabled" in d:
            db.set_setting("sync_enabled", "1" if d["enabled"] else "0")
            if d["enabled"] and db.get_setting("sync_state") == "needs_reauth" and get_secret("g_refresh_token"):
                db.set_setting("sync_state", "ok")
        db.audit(g.user, "sync.settings", detail={k: v for k, v in d.items() if "secret" not in k})
        return jsonify(status())

    @app.get("/api/google/auth-url")
    @auth(["admin"])
    def google_auth_url():
        state = secrets.token_urlsafe(16)
        db.set_setting("g_oauth_state", state)
        redirect_uri = request.host_url.rstrip("/") + "/api/google/callback"
        try:
            return jsonify(url=SheetsAPI.auth_url(redirect_uri, state), redirect_uri=redirect_uri)
        except SyncError as e:
            return jsonify(error=str(e)), 400

    @app.get("/api/google/callback")
    @auth(["admin"])
    def google_callback():
        if request.args.get("state") != db.get_setting("g_oauth_state") or not request.args.get("code"):
            return "طلب غير صالح", 400
        try:
            SheetsAPI.exchange_code(request.args["code"], request.host_url.rstrip("/") + "/api/google/callback")
        except SyncError as e:
            return "فشل الربط: %s" % e, 400
        db.set_setting("g_oauth_state", "")
        if db.get_setting("sync_state") == "needs_reauth":
            db.set_setting("sync_state", "ok")
        db.audit(g.user, "sync.linked")
        return redirect("/#/sync")

    @app.post("/api/sync/create")
    @auth(["admin"])
    def sync_create():
        title = (request.get_json(force=True).get("title") or "الكراسات الإحصائية 2026-2027").strip()
        try:
            sid, url = get_api().create_spreadsheet(title, list(SHEETS.values()))
        except SyncError as e:
            return jsonify(error=str(e), kind=e.kind), 400
        db.set_setting("g_spreadsheet_id", sid)
        db.set_setting("g_spreadsheet_title", title)
        db.audit(g.user, "sync.create", detail=dict(id=sid))
        return jsonify(status())

    @app.post("/api/sync/retry")
    @auth(["admin", "reviewer"])
    def sync_retry():
        n = retry_failed((request.get_json(silent=True) or {}).get("school_id"))
        db.audit(g.user, "sync.retry", detail=dict(n=n))
        return jsonify(retried=n, **status())

    @app.post("/api/sync/run")
    @auth(["admin", "reviewer"])
    def sync_run():
        if not configured():
            return jsonify(error="الربط غير مكتمل"), 400
        res = process_batch()
        return jsonify(result=res, **status())

    @app.post("/api/sync/resync")
    @auth(["admin"])
    def sync_resync():
        n = enqueue_all()
        db.audit(g.user, "sync.resync", detail=dict(n=n))
        return jsonify(queued=n, **status())

    @app.post("/api/sync/disconnect")
    @auth(["admin"])
    def sync_disconnect():
        put_secret("g_refresh_token", "")
        db.set_setting("sync_enabled", "0")
        db.set_setting("sync_state", "idle")
        db.audit(g.user, "sync.disconnect")
        return jsonify(status())
