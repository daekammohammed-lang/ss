"""رفع كراسات PDF/صور، تجهيز الصفحات، والقراءة بالذكاء الاصطناعي عبر طبقة مزوّدين قابلة للاستبدال.

مبادئ:
* لا يُعتمد شيء تلقائياً: كل ما يقرؤه النموذج يدخل بحالة «AI» ويمر بالمراجعة.
* الثقة تُبنى من إشارات قابلة للقياس (اتفاق المجاميع الورقية مع المحسوبة، وجود قراءة بديلة، سلامة الرقم، المدى)
  وليست نسبة يدّعيها النموذج. هذه إشارات حتمية يمكن معايرة عتباتها لاحقاً على كراسات مصحّحة (raw يُحفظ لذلك).
* المزوّد مجرّد: يكفي تنفيذ identify() و extract() لإضافة أي نموذج آخر.
"""
import os, io, re, json, time, hashlib, threading, subprocess, base64, difflib, logging, traceback, shutil, glob
import requests
from flask import request, jsonify, g, send_file, abort
import db, forms, schools

log = logging.getLogger("extraction")
ROOT = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(os.path.dirname(db.DB_PATH), "uploads")   # بجانب قاعدة البيانات دائماً
HIGH, MID = 0.85, 0.60          # عتبات الثقة (قابلة للمعايرة)
provider_override = None         # للاختبارات


# ------------------------------------------------------------------ معالجة الصور
def preprocess(src, dst, max_side=2200):
    """تصحيح ميلان بسيط وتصغير. يعيد زاوية التصحيح."""
    try:
        import cv2, numpy as np
    except ImportError:      # بدون OpenCV: تصغير فقط دون تصحيح الميلان
        from PIL import Image
        im = Image.open(src).convert("RGB")
        k = max_side / max(im.size)
        if k < 1:
            im = im.resize((int(im.width * k), int(im.height * k)))
        im.save(dst, quality=90)
        return 0.0
    img = cv2.imread(src)
    if img is None:
        raise ValueError("تعذّر قراءة الصورة")
    h, w = img.shape[:2]
    s = max_side / max(h, w)
    if s < 1:
        img = cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    # الخطوط الأفقية الطويلة (حدود الجداول) تعطي الميلان بدقة
    lines = cv2.HoughLinesP(thr, 1, np.pi / 720, threshold=200, minLineLength=img.shape[1] // 4, maxLineGap=20)
    angle = 0.0
    if lines is not None:
        angs = []
        for l in lines[:, 0]:
            a = np.degrees(np.arctan2(l[3] - l[1], l[2] - l[0]))
            if abs(a) < 5:
                angs.append(a)
        if angs:
            angle = float(np.median(angs))
    if abs(angle) > 0.15:
        hh, ww = img.shape[:2]
        M = cv2.getRotationMatrix2D((ww / 2, hh / 2), angle, 1.0)
        img = cv2.warpAffine(img, M, (ww, hh), flags=cv2.INTER_CUBIC, borderValue=(255, 255, 255))
    cv2.imwrite(dst, img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return angle


def rasterize(path, outdir, dpi=150):
    os.makedirs(outdir, exist_ok=True)
    if path.lower().endswith(".pdf"):
        subprocess.run(["pdftoppm", "-jpeg", "-r", str(dpi), path, os.path.join(outdir, "raw")], check=True, timeout=600)
        files = sorted(glob.glob(os.path.join(outdir, "raw-*.jpg")), key=lambda p: int(re.findall(r"-(\d+)\.jpg", p)[0]))
    else:
        dst = os.path.join(outdir, "raw-1.jpg")
        shutil.copy(path, dst)
        files = [dst]
    return files


def process_upload(upload_id):
    u = db.q1("SELECT * FROM uploads WHERE id=?", (upload_id,))
    try:
        db.ex("UPDATE uploads SET status='rendering', progress=0 WHERE id=?", (upload_id,))
        src = os.path.join(UPLOAD_DIR, u["sha256"] + os.path.splitext(u["filename"])[1].lower())
        outdir = os.path.join(UPLOAD_DIR, "pages", str(upload_id))
        files = rasterize(src, outdir)
        db.ex("DELETE FROM pages WHERE upload_id=?", (upload_id,))
        for i, f in enumerate(files, 1):
            dst = os.path.join(outdir, "p%03d.jpg" % i)
            try:
                preprocess(f, dst)
            except Exception:
                shutil.copy(f, dst)
            db.ex("INSERT INTO pages(upload_id,n,path) VALUES(?,?,?)", (upload_id, i, dst))
            db.ex("UPDATE uploads SET progress=? WHERE id=?", (i / len(files), upload_id))
            os.remove(f) if os.path.exists(f) else None
        db.ex("UPDATE uploads SET status='ready', pages=?, progress=1 WHERE id=?", (len(files), upload_id))
    except Exception as e:
        log.error(traceback.format_exc())
        db.ex("UPDATE uploads SET status='failed', error=? WHERE id=?", (str(e)[:300], upload_id))


# ------------------------------------------------------------------ مزوّدو الذكاء الاصطناعي
class Provider:
    name = "base"
    model = ""

    def identify(self, image_bytes):
        """يعيد dict(form_title, school_id, school_name)"""
        raise NotImplementedError

    def extract(self, image_bytes, sections):
        """يعيد dict(values={key: str}, alternatives={key: str}, illegible=[key], paper_totals={key: str}, usage={})"""
        raise NotImplementedError


class AnthropicProvider(Provider):
    name = "anthropic"

    def __init__(self, api_key=None, model=None):
        self.key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.model = model or os.environ.get("EXTRACT_MODEL", "claude-sonnet-5-5")
        if not self.key:
            raise RuntimeError("ANTHROPIC_API_KEY غير مضبوط")

    def _call(self, image_bytes, prompt, max_tokens=8000):
        body = dict(model=self.model, max_tokens=max_tokens, messages=[dict(role="user", content=[
            dict(type="image", source=dict(type="base64", media_type="image/jpeg",
                                           data=base64.b64encode(image_bytes).decode())),
            dict(type="text", text=prompt)])])
        for attempt in range(4):
            try:
                r = requests.post("https://api.anthropic.com/v1/messages", timeout=180, json=body,
                                  headers={"x-api-key": self.key, "anthropic-version": "2023-06-01"})
            except requests.RequestException as e:
                time.sleep(2 ** attempt)
                err = e
                continue
            if r.status_code in (429, 500, 502, 503, 529):
                time.sleep(2 ** attempt * 2)
                err = RuntimeError("HTTP %s" % r.status_code)
                continue
            if r.status_code != 200:
                raise RuntimeError("API %s: %s" % (r.status_code, r.text[:300]))
            j = r.json()
            text = "".join(b.get("text", "") for b in j.get("content", []))
            return _parse_json(text), j.get("usage", {})
        raise RuntimeError("فشل الاتصال بالمزوّد: %s" % err)

    def identify(self, image_bytes):
        p = ("هذه صفحة من كراس إحصائي مدرسي عراقي. أعد JSON فقط بالمفاتيح: "
             '{"form_title": "عنوان الاستمارة المطبوع كما يظهر", "school_id": "الرقم الإحصائي المكتوب بخط اليد '
             'بأرقام لاتينية فقط، أو فارغ", "school_name": "اسم المدرسة المكتوب", "page_no": "رقم الصفحة المطبوع أسفلها مثل 15 - 6 فتكتب 6، أو فارغ"}. لا تخمّن: إن لم يكن مقروءاً اتركه فارغاً.')
        j, _ = self._call(image_bytes, p, 600)
        return j

    def extract(self, image_bytes, sections):
        spec = json.dumps(sections, ensure_ascii=False)
        p = ("هذه صفحة من كراس إحصائي مدرسي عراقي فيها أرقام مكتوبة بخط اليد داخل مربعات. "
             "الأقسام المحتملة في الصفحة وبنية جداولها (rows × cols، وكل خلية لها مفتاح):\n" + spec +
             "\n\nاقرأ كل خلية مكتوبة في الصفحة وأعد JSON فقط بالشكل: "
             '{"values": {"KEY": "الرقم"}, "alternatives": {"KEY": "قراءة بديلة محتملة"}, '
             '"illegible": ["KEY"], "paper_totals": {"KEY": "المجموع المكتوب في الورقة لخلية مجموع"}}.\n'
             "قواعد: (1) الأرقام بالصيغة اللاتينية 0-9 حتى لو كُتبت هندية. (2) الخلية الفارغة لا تُدرج. "
             "(3) خانات الاختيار: ضع 1 إن كانت عليها علامة X أو ✓. (4) إن التبس الرقم (مثل 3/4 أو 1/7 أو 0/6) فاكتب "
             "أرجح قراءة في values والبديلة في alternatives. (5) غير المقروء أدرجه في illegible ولا تخمّن. "
             "(6) خلايا المجموع المحسوبة (type=computed) لا تُدرج في values بل في paper_totals إن كُتب مجموعها. "
             "(7) استعمل المفاتيح كما هي دون اختراع مفاتيح.")
        j, usage = self._call(image_bytes, p, 12000)
        j["usage"] = usage
        return j


def _parse_json(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise RuntimeError("ردّ غير صالح من النموذج")
    return json.loads(m.group(0))


def get_provider():
    if provider_override:
        return provider_override
    return AnthropicProvider()


# ------------------------------------------------------------------ مطابقة المدرسة والأقسام
TYPE_WORDS = {"ابتدائيه", "ابتدائية", "اعداديه", "اعدادية", "ثانويه", "ثانوية", "متوسطه", "متوسطة", "مدرسه", "مدرسة",
              "روضه", "روضة", "للبنين", "للبنات", "م", "ث", "ع", "ا", "ر", "ب"}


def _name_tokens(s):
    t = [x for x in re.split(r"[\s/\\\-_.]+", schools.norm_ar(s)) if len(x) > 1]
    return {x for x in t if x not in TYPE_WORDS} or set(t)


def resolve_school(id_text, name_text):
    """يتحقق من الرقم المقروء بمقارنة الاسم المكتوب في الصفحة نفسها. status: ok | mismatch | unknown"""
    sid = schools.norm_ar(id_text or "")
    sid = re.sub(r"\D", "", sid)
    r = db.q1("SELECT * FROM schools WHERE id=?", (sid,)) if sid else None
    cand = []
    if name_text:   # كلمات النوع (اعدادية/ابتدائية…) لا تدخل في البحث لأن اسم القائمة الرسمية يختصرها (ع/، ث/)
        cand = schools.search(" ".join(sorted(_name_tokens(name_text))), 8) or schools.search(name_text, 5)
    if r:
        if not name_text:
            return r["id"], "ok", []
        a, b = _name_tokens(name_text), _name_tokens(r["name"])
        overlap = len(a & b) / max(1, min(len(a), len(b)))
        if overlap >= 0.5:
            return r["id"], "ok", []
        return r["id"], "mismatch", cand
    return None, "unknown", cand


def _norm_title(s):
    s = schools.norm_ar(s)
    return re.sub(r"[\d/\-–—:()«»\"'،.]+", " ", s).strip()


# خريطة الصفحات المطبوعة (ترقيم أسفل الصفحة «15 - n») إلى أقسام القالب؛ مأخوذة من الكراس الثانوي الفارغ.
# الرقم المطبوع أوثق من مطابقة العنوان تقريبياً، فيُستعمل إن وُجد وإلا نرجع للمطابقة بالعنوان.
PAGE_MAP = {"secondary": {4: ["info"], 5: ["s1", "s2", "s3", "s4"], 6: ["s5"], 7: ["s6", "s7"], 8: ["s8"],
                          9: ["s9", "s10", "s11", "s12", "s13", "s14", "s15", "s16", "s17", "s18"],
                          10: ["s19", "s20", "s21"], 11: ["s22"], 12: ["s23"], 13: ["s24"], 14: ["s25"]}}


# الاستمارات 6 فما فوق (الهيئة التدريسية والموظفون، غير العراقيين، الأبنية، التجهيزات، المكتبات، المختبرات، التطبيقات…)
# تُدخل يدوياً فقط: القراءة الآلية تقتصر على الاستمارات 1–5 (المعلومات العامة، المستجدون، المسجلون، الشعب والراسبون).
MANUAL_KEYWORDS = ("الهيئة التعليمية", "الهيئة التدريسية", "الموظفون", "الموظفين", "غير العراقيين", "الابنية", "الاثاث",
                   "التجهيزات", "المكتبات", "المختبرات", "مشمولة", "الايتام")


def is_manual_section(sec):
    if db.get_setting("ai_skip_manual", "1") != "1":
        return False
    t = schools.norm_ar(sec["title"])
    return any(schools.norm_ar(k) in t for k in MANUAL_KEYWORDS)


def sections_for_page(form, template, page_no, form_title):
    try:
        n = int(re.sub(r"\D", "", str(page_no or "")) or 0)
    except ValueError:
        n = 0
    ids = PAGE_MAP.get(template, {}).get(n)
    if ids:
        by = {s["id"]: s for s in form["sections"]}
        got = [by[i] for i in ids if i in by]
        if got:
            return got
    return candidate_sections(form, form_title)


def candidate_sections(form, form_title, top=4, min_ratio=0.25):
    t = _norm_title(form_title)
    scored = []
    for sec in form["sections"]:
        st = _norm_title(sec["title"])
        ratio = difflib.SequenceMatcher(None, t, st).ratio()
        tok = set(t.split()) & set(st.split())
        ratio = max(ratio, len(tok) / max(1, len(set(t.split()))) * 0.8)
        scored.append((ratio, sec))
    scored.sort(key=lambda x: -x[0])
    return [s for r, s in scored[:top] if r >= min_ratio] or [s for r, s in scored[:2]]


def section_spec(form, sec):
    out = dict(id=sec["id"], title=sec["title"])
    if sec["layout"] == "grid" and sec.get("grid"):
        g_ = sec["grid"]
        rows, cols = g_["rows"], g_["cols"]
        cells = [[None] * len(cols) for _ in rows]
        for k, (ri, ci) in g_["cells"].items():
            f = form["fields"][k]
            cells[ri][ci] = k if f["type"] != "computed" else "%s:computed" % k
        out.update(rows=rows, cols=[" / ".join(c) for c in cols], cells=cells)
    else:
        out["fields"] = [dict(key=k, label=" › ".join(form["fields"][k]["path"]), type=form["fields"][k]["type"])
                         for k in sec["fields"]]
    return out


# ------------------------------------------------------------------ تحويل النتائج إلى قيم + ثقة
def _clean_value(f, v):
    if v is None:
        return None, True
    s = str(v).strip().translate(forms._AR)
    if f["type"] == "number":
        s = s.replace(",", "").replace("٫", ".")
        n = forms.to_num(s)
        if n is None or n < 0 or n != int(n):
            return s, False
        return str(int(n)), True
    if f["type"] == "check":
        if s.lower() in ("1", "x", "✓", "true", "yes", "نعم"):
            return "1", True
        if s in ("0", "", "false"):
            return "0", True
        return s, False
    return s, True


def ingest(form, bid, result, page_id, force=False):
    """يكتب نتائج صفحة واحدة: يعيد (read_count, review_count)."""
    fields = form["fields"]
    values = result.get("values") or {}
    alts = result.get("alternatives") or {}
    illeg = set(result.get("illegible") or [])
    paper = {k.replace(":computed", ""): v for k, v in (result.get("paper_totals") or {}).items()}
    conf = {}
    clean = {}
    for k, v in values.items():
        k = k.replace(":computed", "")
        f = fields.get(k)
        if not f or f["type"] in ("computed", "seq", "id") or v in (None, ""):
            continue
        val, ok = _clean_value(f, v)
        c = 0.92
        if not ok:
            c = 0.2
        if k in alts and str(alts[k]).strip() not in ("", str(v).strip()):
            c = min(c, 0.55)
        if f["type"] == "number" and ok and int(val) > 2000:
            c = min(c, 0.5)
        clean[k], conf[k] = val, c
    for k in illeg:
        k = k.replace(":computed", "")
        f = fields.get(k)
        if f and f["type"] not in ("computed", "seq", "id"):
            clean.setdefault(k, None)
            conf[k] = 0.0
    # إشارة المجاميع: إن خالف مجموع الورق المجموع المحسوب فالحقول المساهمة مشكوك بها
    cur = {k: v for k, v in clean.items() if v is not None}
    existing = {r["k"]: r["v"] for r in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (bid,))}
    merged = {**existing, **cur}
    comp = forms.compute(form, merged)
    mismatched = []
    for k, pv in paper.items():
        f = fields.get(k)
        if f and f["type"] == "computed":
            a, b = forms.to_num(pv), comp.get(k)
            if a is not None and (b or 0) != a:
                mismatched.append(k)

    def inputs_of(k, seen=None):
        out = []
        for r in fields[k]["sum"]:
            if fields[r]["type"] == "computed":
                out += inputs_of(r)
            else:
                out.append(r)
        return out
    for k in mismatched:
        for inp in inputs_of(k):
            if inp in conf:
                conf[inp] = min(conf[inp], 0.45)
    n_read = n_review = 0
    with db.tx():
        for k, val in clean.items():
            old = db.q1("SELECT src FROM vals WHERE booklet_id=? AND k=?", (bid, k))
            if old and old["src"] == "manual" and not force:
                continue
            c = conf.get(k, 0.9)
            state = "ok" if (val is not None and c >= HIGH) else "review"
            if val is None:
                state = "missing"
            alt = alts.get(k)
            db.ex("INSERT INTO vals(booklet_id,k,v,src,conf,state,alt,page,paper) VALUES(?,?,?,'ai',?,?,?,?,?) "
                  "ON CONFLICT(booklet_id,k) DO UPDATE SET v=excluded.v, src='ai', conf=excluded.conf, state=excluded.state, "
                  "alt=excluded.alt, page=excluded.page, ver=vals.ver+1, upd_at=CURRENT_TIMESTAMP",
                  (bid, k, val, c, "review" if state != "ok" else "ok", None if alt is None else str(alt), page_id,
                   paper.get(k)))
            n_read += 1
            n_review += state != "ok"
        for k, pv in paper.items():
            if fields.get(k, {}).get("type") == "computed":
                db.ex("INSERT INTO vals(booklet_id,k,v,src,paper,page) VALUES(?,?,NULL,'ai',?,?) "
                      "ON CONFLICT(booklet_id,k) DO UPDATE SET paper=excluded.paper", (bid, k, str(pv), page_id))
    return n_read, n_review


# ------------------------------------------------------------------ تشغيل القراءة
def run_extraction(upload_id, user_id=None, force=False):
    u = db.q1("SELECT * FROM uploads WHERE id=?", (upload_id,))
    run = db.ex("INSERT INTO extraction_runs(upload_id,booklet_id,provider,status) VALUES(?,?,?, 'running')",
                (upload_id, u["booklet_id"], "?")).lastrowid
    try:
        prov = get_provider()
        db.ex("UPDATE extraction_runs SET provider=?, model=? WHERE id=?", (prov.name, prov.model, run))
        db.ex("UPDATE uploads SET status='extracting', progress=0, error=NULL WHERE id=?", (upload_id,))
        pages = db.q("SELECT * FROM pages WHERE upload_id=? ORDER BY n", (upload_id,))
        bid = u["booklet_id"]
        form = forms.load_form(db.q1("SELECT template FROM booklets WHERE id=?", (bid,))["template"]) if bid else None
        raw = []
        tot_read = tot_rev = 0
        for i, p in enumerate(pages):
            img = open(p["path"], "rb").read()
            ident = prov.identify(img)
            if bid is None:
                sid, st, cand = resolve_school(ident.get("school_id"), ident.get("school_name"))
                if st != "ok":
                    db.ex("UPDATE uploads SET school_check=?, school_id=? WHERE id=?",
                          (json.dumps(dict(status=st, read_id=ident.get("school_id"), read_name=ident.get("school_name"),
                                           candidates=cand), ensure_ascii=False), sid, upload_id))
                    db.ex("UPDATE uploads SET status='needs_school' WHERE id=?", (upload_id,))
                    db.ex("UPDATE extraction_runs SET status='needs_school', raw=? WHERE id=?",
                          (json.dumps(raw, ensure_ascii=False), run))
                    return
                s = db.q1("SELECT * FROM schools WHERE id=?", (sid,))
                if not s["template"]:
                    raise RuntimeError("لا قالب لهذه المدرسة")
                b = db.q1("SELECT id FROM booklets WHERE school_id=? AND year=?", (sid, db.get_setting("year", "2026-2027")))
                if not b:
                    b = dict(id=db.ex("INSERT INTO booklets(school_id,year,template,source,created_by,updated_by) "
                                      "VALUES(?,?,?, 'ai', ?, ?)", (sid, db.get_setting("year", "2026-2027"), s["template"],
                                                                      user_id, user_id)).lastrowid)
                bid = b["id"]
                db.ex("UPDATE uploads SET booklet_id=?, school_id=? WHERE id=?", (bid, sid, upload_id))
                form = forms.load_form(s["template"])
            secs = sections_for_page(form, form["id"] if "id" in form else None, ident.get("page_no"), ident.get("form_title", ""))
            secs = [x for x in secs if not is_manual_section(x)]
            if not secs:      # صفحة من الاستمارات 6+: تبقى للإدخال اليدوي ولا تُرسل للنموذج
                raw.append(dict(page=p["n"], ident=ident, skipped="manual"))
                db.ex("UPDATE pages SET form_hint=? WHERE id=?", ((ident.get("form_title") or "") + " (إدخال يدوي)", p["id"]))
                db.ex("UPDATE uploads SET progress=? WHERE id=?", ((i + 1) / len(pages), upload_id))
                continue
            res = prov.extract(img, [section_spec(form, s_) for s_ in secs])
            nr, nv = ingest(form, bid, res, p["id"], force)
            tot_read, tot_rev = tot_read + nr, tot_rev + nv
            db.ex("UPDATE pages SET form_hint=? WHERE id=?", (ident.get("form_title"), p["id"]))
            raw.append(dict(page=p["n"], ident=ident, sections=[s_["id"] for s_ in secs], result=res))
            db.ex("UPDATE uploads SET progress=? WHERE id=?", ((i + 1) / len(pages), upload_id))
        db.ex("UPDATE booklets SET status=CASE WHEN status='approved' THEN status ELSE 'review' END, "
              "source=CASE WHEN source='manual' THEN 'hybrid' ELSE 'ai' END, rev=rev+1, updated_at=CURRENT_TIMESTAMP WHERE id=?", (bid,))
        db.ex("UPDATE uploads SET status='done' WHERE id=?", (upload_id,))
        db.ex("UPDATE extraction_runs SET status='done', fields_read=?, fields_review=?, raw=? WHERE id=?",
              (tot_read, tot_rev, json.dumps(raw, ensure_ascii=False), run))
        db.audit(dict(id=user_id, username="ai") if user_id else None, "ai.extract", u["school_id"], bid,
                 dict(upload=upload_id, read=tot_read, review=tot_rev, provider=prov.name, model=prov.model))
    except Exception as e:
        log.error(traceback.format_exc())
        db.ex("UPDATE uploads SET status='failed', error=? WHERE id=?", (str(e)[:300], upload_id))
        db.ex("UPDATE extraction_runs SET status='failed', error=? WHERE id=?", (str(e)[:300], run))


def spawn(fn, *a):
    t = threading.Thread(target=fn, args=a, daemon=True)
    t.start()
    return t


# ------------------------------------------------------------------ واجهات HTTP
ALLOWED = (".pdf", ".jpg", ".jpeg", ".png")


def register(app, auth):
    os.makedirs(UPLOAD_DIR, exist_ok=True)

    @app.post("/api/uploads")
    @auth(write=True)
    def upload_file():
        out = []
        for f in request.files.getlist("file"):
            ext = os.path.splitext(f.filename or "")[1].lower()
            if ext not in ALLOWED:
                out.append(dict(filename=f.filename, error="نوع الملف غير مدعوم"))
                continue
            data = f.read()
            sha = hashlib.sha256(data).hexdigest()
            ex_ = db.q1("SELECT id,status,booklet_id FROM uploads WHERE sha256=?", (sha,))
            if ex_:
                out.append(dict(filename=f.filename, duplicate=True, id=ex_["id"], status=ex_["status"]))
                continue
            with open(os.path.join(UPLOAD_DIR, sha + ext), "wb") as fh:
                fh.write(data)
            bid = None
            sid = schools.norm_ar(request.form.get("school_id", "")) or None
            if sid:
                s = db.q1("SELECT * FROM schools WHERE id=?", (sid,))
                if not s or not s["template"]:
                    out.append(dict(filename=f.filename, error="مدرسة غير موجودة أو بلا قالب"))
                    continue
                year = db.get_setting("year", "2026-2027")
                b = db.q1("SELECT id FROM booklets WHERE school_id=? AND year=?", (sid, year))
                bid = b["id"] if b else db.ex("INSERT INTO booklets(school_id,year,template,created_by,updated_by) VALUES(?,?,?,?,?)",
                                              (sid, year, s["template"], g.user["id"], g.user["id"])).lastrowid
            uid = db.ex("INSERT INTO uploads(booklet_id,filename,sha256,created_by,school_id) VALUES(?,?,?,?,?)",
                        (bid, f.filename, sha, g.user["id"], sid)).lastrowid
            db.audit(g.user, "upload", sid, bid, dict(upload=uid, filename=f.filename, size=len(data)))
            spawn(process_upload, uid)
            out.append(dict(filename=f.filename, id=uid, status="rendering"))
        return jsonify(uploads=out)

    @app.get("/api/uploads")
    @auth()
    def uploads_list():
        rows = db.q("SELECT u.*, s.name school_name FROM uploads u LEFT JOIN schools s ON s.id=u.school_id "
                    "ORDER BY u.id DESC LIMIT 200")
        return jsonify(uploads=[dict(id=r["id"], filename=r["filename"], status=r["status"], pages=r["pages"],
                                     progress=r["progress"], error=r["error"], school_id=r["school_id"],
                                     school_name=r["school_name"], booklet_id=r["booklet_id"],
                                     school_check=json.loads(r["school_check"]) if r["school_check"] else None,
                                     created_at=r["created_at"]) for r in rows])

    @app.get("/api/uploads/<int:uid>")
    @auth()
    def upload_get(uid):
        r = db.q1("SELECT * FROM uploads WHERE id=?", (uid,))
        if not r:
            abort(404)
        pages = db.q("SELECT id,n,form_hint FROM pages WHERE upload_id=? ORDER BY n", (uid,))
        d = dict(r)
        d["school_check"] = json.loads(r["school_check"]) if r["school_check"] else None
        d["pages"] = [dict(p) for p in pages]
        return jsonify(d)

    @app.get("/api/pages/<int:pid>/image")
    @auth()
    def page_image(pid):
        r = db.q1("SELECT path FROM pages WHERE id=?", (pid,))
        if not r or not os.path.exists(r["path"]):
            abort(404)
        return send_file(r["path"], mimetype="image/jpeg", max_age=3600)

    @app.post("/api/uploads/<int:uid>/assign")
    @auth(write=True)
    def upload_assign(uid):
        """يربط الرفع بمدرسة يدوياً (عند عدم تطابق القراءة)."""
        sid = schools.norm_ar(str((request.get_json(force=True) or {}).get("school_id", "")))
        s = db.q1("SELECT * FROM schools WHERE id=?", (sid,))
        if not s or not s["template"]:
            return jsonify(error="مدرسة غير صالحة"), 400
        year = db.get_setting("year", "2026-2027")
        b = db.q1("SELECT id FROM booklets WHERE school_id=? AND year=?", (sid, year))
        bid = b["id"] if b else db.ex("INSERT INTO booklets(school_id,year,template,created_by,updated_by) VALUES(?,?,?,?,?)",
                                      (sid, year, s["template"], g.user["id"], g.user["id"])).lastrowid
        db.ex("UPDATE uploads SET booklet_id=?, school_id=?, status='ready', school_check=NULL WHERE id=?", (bid, sid, uid))
        db.audit(g.user, "upload.assign", sid, bid, dict(upload=uid))
        return jsonify(ok=True, booklet_id=bid)

    @app.post("/api/uploads/<int:uid>/extract")
    @auth(write=True)
    def upload_extract(uid):
        r = db.q1("SELECT * FROM uploads WHERE id=?", (uid,))
        if not r:
            abort(404)
        if r["status"] in ("rendering", "extracting"):
            return jsonify(error="العملية جارية"), 409
        if r["status"] == "done" and not (request.get_json(silent=True) or {}).get("force"):
            return jsonify(error="قُرئ هذا الملف سابقاً (استخدم force لإعادة القراءة)", code="already_done"), 409
        try:
            get_provider()
        except Exception as e:
            return jsonify(error="مزوّد الذكاء الاصطناعي غير مضبوط: %s" % e, code="no_provider"), 400
        spawn(run_extraction, uid, g.user["id"], bool((request.get_json(silent=True) or {}).get("force_overwrite")))
        return jsonify(started=True)

    @app.get("/api/booklets/<int:bid>/review")
    @auth()
    def booklet_review(bid):
        """الحقول المقروءة بالذكاء الاصطناعي مرتبة بالأولوية (الأقل ثقة أولاً) مع الصفحة المصدر."""
        form_t = db.q1("SELECT template FROM booklets WHERE id=?", (bid,))
        if not form_t:
            abort(404)
        form = forms.load_form(form_t["template"])
        rows = db.q("SELECT k,v,conf,state,alt,page,paper,src FROM vals WHERE booklet_id=? AND src='ai' "
                    "AND (state!='ok' OR paper IS NOT NULL) ORDER BY COALESCE(conf,0), k", (bid,))
        items = []
        for r in rows:
            f = form["fields"].get(r["k"])
            if not f:
                continue
            level = "low" if (r["conf"] or 0) < MID else ("mid" if (r["conf"] or 0) < HIGH else "high")
            items.append(dict(k=r["k"], label=" › ".join(f["path"]), v=r["v"], alt=r["alt"], conf=r["conf"],
                              level=level, state=r["state"], page=r["page"], paper=r["paper"], computed=f["type"] == "computed"))
        pages = db.q("SELECT p.id,p.n,p.form_hint,p.upload_id FROM pages p JOIN uploads u ON u.id=p.upload_id "
                     "WHERE u.booklet_id=? ORDER BY u.id,p.n", (bid,))
        counts = db.q1("SELECT SUM(src='ai') ai, SUM(src='ai' AND state='ok') ok, SUM(src='ai' AND state!='ok') review, "
                       "SUM(src='manual' AND alt IS NOT NULL) corrected FROM vals WHERE booklet_id=?", (bid,))
        return jsonify(items=items, pages=[dict(p) for p in pages], counts=dict(counts))

    @app.post("/api/booklets/<int:bid>/accept")
    @auth(write=True)
    def booklet_accept(bid):
        """يعتمد قراءات الذكاء الاصطناعي: all_high=true لكل عالي الثقة، أو keys=[...] لحقول محددة."""
        d = request.get_json(force=True)
        n = 0
        with db.tx():
            if d.get("keys"):
                for k in d["keys"]:
                    n += db.ex("UPDATE vals SET state='ok', conf=MAX(COALESCE(conf,0),0.9) WHERE booklet_id=? AND k=? AND src='ai'",
                               (bid, k)).rowcount
            if d.get("all_high"):
                n += db.ex("UPDATE vals SET state='ok' WHERE booklet_id=? AND src='ai' AND conf>=?", (bid, HIGH)).rowcount
            if d.get("all"):
                n += db.ex("UPDATE vals SET state='ok' WHERE booklet_id=? AND src='ai' AND state='review'", (bid,)).rowcount
        db.audit(g.user, "ai.accept", None, bid, dict(n=n, mode="keys" if d.get("keys") else ("all" if d.get("all") else "high")))
        return jsonify(accepted=n)
