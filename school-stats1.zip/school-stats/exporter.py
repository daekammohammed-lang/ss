"""تصدير Excel من القوالب الرسمية نفسها (الترويسات والدمج والتنسيق تبقى مطابقة)."""
import io, os, zipfile, time, copy, json
import openpyxl
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI
from flask import request, send_file, jsonify, g, abort
import db, forms

TEMPLATE_FILES = {"primary": "templates_xlsx/primary.xlsx", "secondary": "templates_xlsx/secondary.xlsx",
                  "kg": "templates_xlsx/kg.xlsx"}
FILE_NAMES = {"combined": "الملف الجامع لكل الفئات", "accel": "التعليم المسرع", "primary": "المدارس الابتدائية والأساسية والمتوسطة", "secondary": "المدارس الثانوية",
              "kg": "رياض الأطفال", "ahli": "المدارس الأهلية"}
ROOT = os.path.dirname(os.path.abspath(__file__))


ACCEL = "%مسرع%"   # مدارس التعليم المسرع تُميَّز باسمها في القائمة الرسمية (كلها على قالب الابتدائي)


def collect(tid, status="approved", ownership=None, ids=None, group=None):
    """يعيد [(school_row, booklet_row)] مرتبة بترتيب القائمة الرسمية."""
    year = db.get_setting("year", "2026-2027")
    sql = ("SELECT s.id sid, s.name, s.seq, b.id bid, b.status, b.master_seq FROM schools s JOIN booklets b "
           "ON b.school_id=s.id AND b.year=? WHERE s.template=?")
    args = [year, tid]
    if status == "approved":
        sql += " AND b.status='approved'"
    elif status == "incomplete":
        sql += " AND b.status!='approved'"
    if ownership:
        sql += " AND s.ownership=?"
        args.append(ownership)
    if group == "main":      # الملف الأساسي: لا أهلي ولا مسرع (لكل مدرسة ملف واحد فقط)
        sql += " AND s.ownership!='اهلي' AND s.name NOT LIKE ?"
        args.append(ACCEL)
    elif group == "accel":
        sql += " AND s.ownership!='اهلي' AND s.name LIKE ?"
        args.append(ACCEL)
    if ids:
        sql += " AND s.id IN (%s)" % ",".join("?" * len(ids))
        args += list(ids)
    # الملف العام لكل فئة يكبر بالإضافة: المدرسة المعتمدة تُلحَق بآخره (تسلسل 1، 2، 3…) حسب ترتيب أول اعتماد،
    # وتعديلها لاحقاً يحدّث صفها في مكانه ولا يغيّر رقمها. غير المعتمدة (عند تضمينها) تأتي بعدها بترتيب فتح الكراس.
    return db.q(sql + " ORDER BY b.master_seq IS NULL, b.master_seq, b.id", args)


def _cell_value(f, raw, computed_val):
    t = f["type"]
    if t == "computed":
        return computed_val if computed_val is not None else 0
    if raw in (None, ""):
        return None
    if t in ("number",):
        n = forms.to_num(raw)
        return n if n is not None else raw
    if t == "check":
        return 1 if str(raw) in ("1", "1.0", "true", "True") else (0 if str(raw) in ("0", "0.0") else raw)
    if t == "id":
        s = str(raw)
        return int(s) if s.isdigit() and not s.startswith("0") else s
    sv = str(raw).strip()
    if sv.isdigit() and len(sv) == 4 and "تأسيس" in " ".join(f["path"]).replace("تاسيس", "تأسيس"):
        return int(sv)         # سنة صرفة تُكتب رقماً كما في القالب الأصلي
    return str(raw)


def _trimmed_template(tid):
    """القالب الأصلي فيه نحو ألف صف جاهز بالصيغ فتحميله يأخذ ~6 ثوانٍ؛ نحفظ نسخة مخففة (الترويسة + صف نموذجي) مرة واحدة."""
    src = os.path.join(ROOT, TEMPLATE_FILES[tid])
    dst = os.path.join(os.path.dirname(db.DB_PATH) if hasattr(db, "DB_PATH") else os.path.join(ROOT, "data"), "tpl_cache", tid + "_v2.xlsx")
    if os.path.exists(dst) and os.path.getmtime(dst) >= os.path.getmtime(src):
        return dst
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    wb = openpyxl.load_workbook(src)
    ws = wb.worksheets[0]
    ds = forms.load_form(tid)["data_start"]
    if ws.max_row > ds:
        ws.delete_rows(ds + 1, ws.max_row - ds)
    ncols = forms.load_form(tid)["ncols"]
    if ws.max_column > ncols:                      # القالب الثانوي فيه آلاف الأعمدة الفارغة المنسّقة: تُحذف فتصغر الملفات
        ws.delete_cols(ncols + 1, ws.max_column - ncols)
    for k in [k for k in ws.column_dimensions if CI(k) > ncols]:
        del ws.column_dimensions[k]
    tmp = dst + ".tmp"
    wb.save(tmp)
    os.replace(tmp, dst)
    return dst


def build_sheet_workbook(tid, rows, formulas=False):
    """يملأ نسخة من القالب. formulas=True يبقي الصيغ حيّة بدل القيم."""
    form = forms.load_form(tid)
    wb = openpyxl.load_workbook(_trimmed_template(tid))
    ws = wb.worksheets[0]
    ds = form["data_start"]
    template_max = ws.max_row
    ncols = form["ncols"]
    fields = form["fields"]
    style_row = {c: copy.copy(ws.cell(ds, c)._style) for c in range(1, ncols + 1)}
    n = len(rows)
    for i, r in enumerate(rows):
        row = ds + i
        vals = {x["k"]: x["v"] for x in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (r["bid"],))}
        comp = forms.compute(form, vals)
        for k, f in fields.items():
            c = f["col"]
            cell = ws.cell(row, c)
            if row > template_max or cell.value is None and cell.has_style is False:
                cell._style = copy.copy(style_row[c])
            if f["type"] == "seq":
                cell.value = i + 1
                continue
            if f["type"] == "computed":
                if formulas:
                    cell.value = "=" + "+".join("%s%d" % (x, row) for x in f["sum"])
                else:
                    cell.value = comp.get(k) if comp.get(k) is not None else 0
                continue
            cell.value = _cell_value(f, vals.get(k), None)
    # صفوف القالب الفائضة (فيها صيغ جاهزة) تُحذف كي لا يظهر صفر في مدارس غير موجودة
    if n < template_max - ds + 1:
        ws.delete_rows(ds + n, template_max - (ds + n) + 1)
    _tidy(ws, form, n, tid)
    return wb


TAB_COLORS = {"primary": "2E75B6", "secondary": "548235", "kg": "BF8F00"}


def _tidy(ws, form, n, tid):
    """ترتيب الملف: تجميد الترويسة وعمودَي (ت، الرقم الإحصائي)، فلتر على آخر صف ترويسة، لون تبويب، اتجاه عربي."""
    ds = form["data_start"]
    ws.freeze_panes = "C%d" % ds
    ws.auto_filter.ref = "A%d:%s%d" % (form["hdr_last"], L(form["ncols"]), max(ds + n - 1, form["hdr_last"] + 1))
    ws.sheet_view.rightToLeft = True
    ws.sheet_properties.tabColor = TAB_COLORS.get(tid, "7F7F7F")
    ws.sheet_view.zoomScale = 90


def _copy_sheet(src, dst_wb, title):
    dst = dst_wb.create_sheet(title[:31])
    for row in src.iter_rows():
        for c in row:
            d = dst.cell(c.row, c.column, c.value)
            if c.has_style:
                d._style = copy.copy(c._style)  # نفس سجل الأنماط لا يصلح بين مصنفين؛ ننسخ الصفات صراحةً
                d.font, d.border, d.fill = copy.copy(c.font), copy.copy(c.border), copy.copy(c.fill)
                d.number_format, d.alignment = c.number_format, copy.copy(c.alignment)
    for m in src.merged_cells.ranges:
        dst.merge_cells(str(m))
    for k, dim in src.column_dimensions.items():
        dst.column_dimensions[k].width = dim.width
        dst.column_dimensions[k].hidden = dim.hidden
    for k, dim in src.row_dimensions.items():
        dst.row_dimensions[k].height = dim.height
    dst.sheet_view.rightToLeft = src.sheet_view.rightToLeft
    dst.freeze_panes = src.freeze_panes
    dst.auto_filter.ref = src.auto_filter.ref
    dst.sheet_properties.tabColor = src.sheet_properties.tabColor
    dst.sheet_view.zoomScale = src.sheet_view.zoomScale
    return dst


def workbook_bytes(wb):
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def export_one(tid, status="approved", ownership=None, ids=None, formulas=False, group=None):
    rows = collect(tid, status, ownership, ids, group)
    return build_sheet_workbook(tid, rows, formulas), len(rows)


def export_ahli(status="approved", formulas=False):
    base = None
    n_total = 0
    names = {"primary": "ابتدائي-أهلي", "secondary": "ثانوي-أهلي", "kg": "رياض-أهلي"}
    for tid in ("primary", "secondary", "kg"):
        wb, n = export_one(tid, status, "اهلي", None, formulas)
        n_total += n
        if base is None:
            base = wb
            base.worksheets[0].title = names[tid]
        else:
            _copy_sheet(wb.worksheets[0], base, names[tid])
    return base, n_total


def export_combined(status="approved", formulas=False):
    """ملف Excel واحد جامع: ورقة لكل فئة (ابتدائي، مسرع، ثانوي، رياض، ثم أهلي لكل قالب) بنفس ترويسات القوالب الرسمية."""
    parts = [("ابتدائي", "primary", None, "main"), ("تعليم مسرع", "primary", None, "accel"),
             ("ثانوي", "secondary", None, "main"), ("رياض أطفال", "kg", None, "main"),
             ("ابتدائي-أهلي", "primary", "اهلي", None), ("ثانوي-أهلي", "secondary", "اهلي", None),
             ("رياض-أهلي", "kg", "اهلي", None)]
    base, counts = None, []
    for title, tid, own, grp in parts:
        wb, n = export_one(tid, status, own, None, formulas, group=grp)
        counts.append((title, n))
        if base is None:
            base = wb
            base.worksheets[0].title = title
        else:
            _copy_sheet(wb.worksheets[0], base, title)
    _summary_sheet(base, counts, status)
    return base, counts


def _summary_sheet(wb, counts, status):
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    ws = wb.create_sheet("ملخص", 0)
    ws.sheet_view.rightToLeft = True
    ws.sheet_properties.tabColor = "1D5C87"
    st = {"approved": "المعتمدة فقط", "all": "كل الكراسات المبدوءة", "incomplete": "غير المعتمدة فقط"}.get(status, status)
    ws["A1"] = "الملف الجامع للكراسات الإحصائية " + db.get_setting("year", "2026-2027")
    ws["A1"].font = Font(bold=True, size=16)
    ws["A2"] = "تاريخ التصدير: " + time.strftime("%Y-%m-%d %H:%M") + "   |   المشمول: " + st
    ws["A3"] = "تصميم المهندس ضيغم الفهداوي"
    ws["A3"].font = Font(color="666666")
    hdr = ["الفئة (اسم الورقة)", "عدد المدارس", "القالب"]
    for i, h in enumerate(hdr, 1):
        c = ws.cell(5, i, h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1D5C87")
        c.alignment = Alignment(horizontal="center")
    tpl = {"ابتدائي": "ابتدائي", "تعليم مسرع": "ابتدائي", "ثانوي": "ثانوي", "رياض أطفال": "رياض الأطفال",
           "ابتدائي-أهلي": "ابتدائي", "ثانوي-أهلي": "ثانوي", "رياض-أهلي": "رياض الأطفال"}
    thin = Side(style="thin", color="BBBBBB")
    for r, (t, n) in enumerate(counts, 6):
        for i, v in enumerate((t, n, tpl.get(t, "")), 1):
            c = ws.cell(r, i, v)
            c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
            c.alignment = Alignment(horizontal="center" if i > 1 else "right")
        ws.cell(r, 1).hyperlink = "#'%s'!A1" % t
        ws.cell(r, 1).font = Font(color="1D5C87", underline="single")
    tr = 6 + len(counts)
    ws.cell(tr, 1, "المجموع").font = Font(bold=True)
    ws.cell(tr, 2, sum(n for _, n in counts)).font = Font(bold=True)
    ws.cell(tr, 2).alignment = Alignment(horizontal="center")
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 18
    wb.active = 0


def export_zip(status="approved", formulas=False):
    bio = io.BytesIO()
    manifest = []
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for tid in ("primary", "secondary", "kg"):
            wb, n = export_one(tid, status, None, None, formulas, group="main")
            z.writestr("%d- %s.xlsx" % ({"primary": 1, "secondary": 2, "kg": 3}[tid], FILE_NAMES[tid]), workbook_bytes(wb))
            manifest.append((FILE_NAMES[tid], n))
        wb, n = export_one("primary", status, None, None, formulas, group="accel")
        z.writestr("4- " + FILE_NAMES["accel"] + ".xlsx", workbook_bytes(wb))
        manifest.append((FILE_NAMES["accel"], n))
        wb, n = export_ahli(status, formulas)
        z.writestr("5- " + FILE_NAMES["ahli"] + ".xlsx", workbook_bytes(wb))
        manifest.append((FILE_NAMES["ahli"], n))
    bio.seek(0)
    return bio, manifest


def progress_report_bytes():
    year = db.get_setting("year", "2026-2027")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "تقرير الإنجاز"
    ws.sheet_view.rightToLeft = True
    ws.append(["الرقم الإحصائي", "اسم المدرسة", "التصنيف", "العائدية", "القالب", "حالة الكراس", "مصدر البيانات", "آخر تحديث"])
    for r in db.q("SELECT s.id,s.name,s.category,s.ownership,s.template,b.status,b.source,b.updated_at FROM schools s "
                  "LEFT JOIN booklets b ON b.school_id=s.id AND b.year=? ORDER BY s.id", (year,)):
        st = {"approved": "معتمد", "review": "قيد المراجعة", "draft": "غير مكتمل", None: "لم يبدأ"}[r["status"]]
        ws.append([r["id"], r["name"], r["category"], r["ownership"], forms.TEMPLATE_TITLES.get(r["template"], "—"),
                   st, r["source"] or "", r["updated_at"] or ""])
    return workbook_bytes(wb)


def verify_export(path_or_bytes, tid, rows):
    """يقارن الملف المصدَّر بقاعدة البيانات: يعيد قائمة الفروقات (فارغة = مطابق)."""
    wb = openpyxl.load_workbook(io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes,
                                data_only=False)
    ws = wb.worksheets[0]
    form = forms.load_form(tid)
    diffs = []
    seen = set()
    for i, r in enumerate(rows):
        row = form["data_start"] + i
        vals = {x["k"]: x["v"] for x in db.q("SELECT k,v FROM vals WHERE booklet_id=?", (r["bid"],))}
        comp = forms.compute(form, vals)
        sid = ws.cell(row, CI("B")).value
        if str(sid) in seen:
            diffs.append(("تكرار", sid))
        seen.add(str(sid))
        if str(sid) != str(r["sid"]):
            diffs.append(("ترتيب/معرّف", row, sid, r["sid"]))
        for k, f in form["fields"].items():
            got = ws.cell(row, f["col"]).value
            exp = _cell_value(f, vals.get(k), comp.get(k)) if f["type"] != "seq" else i + 1
            if isinstance(got, str) and got.startswith("="):
                continue
            if (got in (None, "")) and (exp in (None, "")):
                continue
            if str(got) != str(exp):
                diffs.append((sid, k, got, exp))
    return diffs


def register(app, auth):
    @app.get("/api/export/all")
    @auth()
    def export_all():
        status = request.args.get("status", "approved")
        bio, manifest = export_zip(status, request.args.get("formulas") == "1")
        db.audit(g.user, "export.all", detail=dict(status=status, files=manifest))
        return send_file(bio, mimetype="application/zip", as_attachment=True,
                         download_name="الملفات النهائية %s.zip" % time.strftime("%Y-%m-%d"))

    @app.get("/api/export/report")
    @auth()
    def export_report():
        return send_file(io.BytesIO(progress_report_bytes()), as_attachment=True,
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         download_name="تقرير الإنجاز.xlsx")

    @app.get("/api/export/<tid>")
    @auth()
    def export_template(tid):
        status = request.args.get("status", "approved")
        formulas = request.args.get("formulas") == "1"
        ids = [x for x in request.args.get("ids", "").split(",") if x] or None
        if tid == "ahli":
            wb, n = export_ahli(status, formulas)
        elif tid == "combined":
            wb, counts = export_combined(status, formulas)
            n = sum(c for _, c in counts)
        elif tid == "accel":
            wb, n = export_one("primary", status, None, ids, formulas, group="accel")
        elif tid == "inst":
            return jsonify(error="لا يوجد قالب Excel للمعاهد والمهني بعد؛ أرسل القالب ليُضاف", code="no_template"), 400
        elif tid in forms.TEMPLATE_IDS:
            own = request.args.get("ownership")
            wb, n = export_one(tid, status, own, ids, formulas, group=None if (ids or own) else "main")
        else:
            abort(404)
        db.audit(g.user, "export", detail=dict(template=tid, status=status, rows=n))
        return send_file(io.BytesIO(workbook_bytes(wb)), as_attachment=True,
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         download_name="%s.xlsx" % FILE_NAMES.get(tid, tid))

    @app.get("/api/export-info")
    @auth()
    def export_info():
        out = {}
        for tid in ("primary", "secondary", "kg"):
            out[tid] = dict(approved=len(collect(tid, "approved", group="main")),
                            incomplete=len(collect(tid, "incomplete", group="main")),
                            ahli=len(collect(tid, "approved", "اهلي")))
        out["accel"] = dict(approved=len(collect("primary", "approved", group="accel")),
                            incomplete=len(collect("primary", "incomplete", group="accel")), ahli=0)
        out["inst"] = dict(total=db.q1("SELECT COUNT(*) n FROM schools WHERE template IS NULL")["n"], approved=0, incomplete=0, ahli=0)
        return jsonify(out)
