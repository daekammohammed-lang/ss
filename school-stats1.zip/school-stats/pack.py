"""نقل البيانات بين الأجهزة بلا شبكة: كل جهاز يصدّر «حزمة بيانات» (.sstats) والجهاز الرئيسي يدمج الحزم.
الدمج بالرقم الإحصائي، ولا يكرر مدرسة، ويسجّل التعارضات (خانة أُدخلت بقيمتين مختلفتين على جهازين)."""
import io, os, json, time, uuid, socket, hashlib, zipfile
from flask import request, jsonify, g, send_file, abort
import db, forms, schools

FORMAT = 1
RANK = {"draft": 0, "review": 1, "approved": 2}
MAX_REPORT = 300


def computer_info():
    cid = db.get_setting("computer_id")
    if not cid:
        cid = uuid.uuid4().hex[:12]
        db.set_setting("computer_id", cid)
    name = db.get_setting("computer_name") or socket.gethostname()
    return cid, name


def build_pack(status="all"):
    year = db.get_setting("year", "2026-2027")
    cid, cname = computer_info()
    q = "SELECT b.*, s.id sid FROM booklets b JOIN schools s ON s.id=b.school_id WHERE b.year=?"
    if status == "approved":
        q += " AND b.status='approved'"
    books = []
    for b in db.q(q + " ORDER BY b.id", (year,)):
        vals = {}
        for r in db.q("SELECT k,v,src,conf,state,alt,paper,upd_at FROM vals WHERE booklet_id=? AND src IN ('manual','ai')", (b["id"],)):
            if r["v"] is None and r["paper"] is None:
                continue
            vals[r["k"]] = dict(v=r["v"], src=r["src"], conf=r["conf"], state=r["state"], alt=r["alt"], paper=r["paper"], at=r["upd_at"])
        if vals or b["status"] != "draft":
            books.append(dict(school_id=b["school_id"], template=b["template"], status=b["status"], source=b["source"],
                              updated_at=b["updated_at"], values=vals))
    data = json.dumps(dict(format=FORMAT, year=year, computer_id=cid, computer_name=cname,
                           exported_at=time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()), booklets=books),
                      ensure_ascii=False).encode("utf-8")
    meta = dict(format=FORMAT, year=year, computer=cname, booklets=len(books), sha256=hashlib.sha256(data).hexdigest())
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(meta, ensure_ascii=False))
        z.writestr("data.json", data)
    bio.seek(0)
    return bio, meta


def read_pack(fileobj):
    try:
        z = zipfile.ZipFile(fileobj)
        meta = json.loads(z.read("manifest.json"))
        data = z.read("data.json")
    except Exception:
        raise ValueError("الملف ليس حزمة بيانات صالحة")
    if hashlib.sha256(data).hexdigest() != meta.get("sha256"):
        raise ValueError("الحزمة تالفة أو عُدّلت (فشل فحص السلامة)")
    d = json.loads(data)
    if d.get("format") != FORMAT:
        raise ValueError("إصدار الحزمة غير مدعوم")
    return d


def merge_pack(d, user, ensure_booklet):
    """يدمج حزمة واحدة. يعيد تقريراً: new/updated/unchanged/conflicts/skipped."""
    year = db.get_setting("year", "2026-2027")
    if d.get("year") != year:
        raise ValueError("الحزمة لسنة %s وهذا الجهاز على %s" % (d.get("year"), year))
    rep = dict(computer=d.get("computer_name"), booklets=0, created=0, fields_new=0, fields_updated=0, fields_same=0,
               conflicts=[], skipped=[])
    uid = user["id"] if user else None
    for pb in d["booklets"]:
        s = db.q1("SELECT * FROM schools WHERE id=?", (pb["school_id"],))
        if not s or not s["template"] or s["template"] != pb["template"]:
            rep["skipped"].append(dict(school_id=pb["school_id"], reason="مدرسة غير معروفة أو قالبها مختلف"))
            continue
        existed = db.q1("SELECT 1 FROM booklets WHERE school_id=? AND year=?", (s["id"], year)) is not None
        b = ensure_booklet(s, user)
        rep["booklets"] += 1
        rep["created"] += 0 if existed else 1
        form = forms.load_form(s["template"])
        with db.tx():
            for k, x in pb["values"].items():
                f = form["fields"].get(k)
                if not f or f["type"] in ("computed", "seq", "id"):
                    continue
                cur = db.q1("SELECT v,src,upd_at FROM vals WHERE booklet_id=? AND k=?", (b["id"], k))
                put = False
                if cur is None or cur["src"] == "master" or (cur["v"] in (None, "") and cur["src"] != "manual"):
                    put = True
                    rep["fields_new"] += 1 if cur is None else 0
                    rep["fields_updated"] += 1 if cur is not None else 0
                elif (cur["v"] or "") == (x["v"] or ""):
                    rep["fields_same"] += 1
                else:
                    newer = (x.get("at") or "") > (cur["upd_at"] or "")
                    if len(rep["conflicts"]) < MAX_REPORT:
                        rep["conflicts"].append(dict(school_id=s["id"], school=s["name"], field=" › ".join(f["path"]), key=k,
                                                     local=cur["v"], incoming=x["v"], winner="الوارد" if newer else "المحلي"))
                    put = newer
                    rep["fields_updated"] += 1 if newer else 0
                if put:
                    db.ex("INSERT INTO vals(booklet_id,k,v,src,conf,state,alt,paper,upd_by,upd_at) VALUES(?,?,?,?,?,?,?,?,?,?) "
                          "ON CONFLICT(booklet_id,k) DO UPDATE SET v=excluded.v, src=excluded.src, conf=excluded.conf, state=excluded.state, "
                          "alt=excluded.alt, paper=excluded.paper, upd_by=excluded.upd_by, upd_at=excluded.upd_at, ver=vals.ver+1",
                          (b["id"], k, x["v"], x["src"], x.get("conf"), x.get("state") or "ok", x.get("alt"), x.get("paper"), uid,
                           x.get("at") or time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())))
            cur_b = db.q1("SELECT status, master_seq FROM booklets WHERE id=?", (b["id"],))
            new_status = pb["status"] if RANK.get(pb["status"], 0) > RANK.get(cur_b["status"], 0) else cur_b["status"]
            db.ex("UPDATE booklets SET status=?, rev=rev+1, updated_at=CURRENT_TIMESTAMP, updated_by=? WHERE id=?", (new_status, uid, b["id"]))
            if new_status == "approved" and cur_b["master_seq"] is None:
                db.ex("UPDATE booklets SET master_seq=(SELECT COALESCE(MAX(master_seq),0)+1 FROM booklets), approved_by=?, approved_at=? WHERE id=?",
                      (uid, time.strftime("%Y-%m-%d %H:%M:%S"), b["id"]))
    db.audit(user, "pack.import", detail=dict(computer=rep["computer"], booklets=rep["booklets"], created=rep["created"],
                                              conflicts=len(rep["conflicts"])))
    return rep


def register(app, auth):
    import app as appmod

    @app.get("/api/pack/export")
    @auth(["admin", "reviewer", "entry"])
    def pack_export():
        bio, meta = build_pack(request.args.get("status", "all"))
        db.audit(g.user, "pack.export", detail=meta)
        safe = "".join(ch for ch in meta["computer"] if ch.isalnum() or ch in "-_") or "pc"
        return send_file(bio, mimetype="application/octet-stream", as_attachment=True,
                         download_name="حزمة-%s-%s.sstats" % (safe, time.strftime("%Y%m%d-%H%M")))

    @app.get("/api/pack/info")
    @auth()
    def pack_info():
        cid, name = computer_info()
        year = db.get_setting("year", "2026-2027")
        n = db.q1("SELECT COUNT(*) n FROM booklets WHERE year=?", (year,))["n"]
        return jsonify(computer_id=cid, computer_name=name, booklets=n, local_mode=appmod.LOCAL_MODE)

    @app.put("/api/pack/info")
    @auth(["admin"])
    def pack_set_name():
        name = str((request.get_json(force=True) or {}).get("computer_name", "")).strip()
        if not name:
            return jsonify(error="اكتب اسماً للجهاز"), 400
        db.set_setting("computer_name", name[:60])
        return jsonify(ok=True)

    @app.post("/api/pack/import")
    @auth(["admin", "reviewer"], write=True)
    def pack_import():
        out = []
        for f in request.files.getlist("file"):
            try:
                d = read_pack(f.stream)
                rep = merge_pack(d, g.user, appmod.ensure_booklet)
                rep["file"] = f.filename
                out.append(rep)
            except ValueError as e:
                out.append(dict(file=f.filename, error=str(e)))
        if not out:
            return jsonify(error="لم يُرفق ملف"), 400
        return jsonify(reports=out)
