#!/bin/sh
# نسخة احتياطية متسقة من قاعدة البيانات والملفات المرفوعة. شغّله من cron يومياً.
set -e
cd "$(dirname "$0")"
D=backups; mkdir -p $D; T=$(date +%Y%m%d-%H%M)
python3 - <<PY
import sqlite3
s=sqlite3.connect("data/app.db"); d=sqlite3.connect("$D/app-$T.db"); s.backup(d); d.close()
PY
tar czf $D/files-$T.tgz data/uploads data/secret.key 2>/dev/null || true
ls -t $D/app-*.db | tail -n +15 | xargs -r rm; ls -t $D/files-*.tgz | tail -n +15 | xargs -r rm
echo "تم: $D/app-$T.db"
