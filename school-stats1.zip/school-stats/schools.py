"""استيراد قائمة المدارس والبحث."""
import json, re, openpyxl
from openpyxl.utils import get_column_letter as L
import db

CATEGORY_TEMPLATE = {"ابتدائي": "primary", "متوسط": "secondary", "ثانوي": "secondary", "اعدادية": "secondary",
                     "رياض الأطفال": "kg", "المهني": None, "معهد": None}

_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def clean(s):
    s = re.sub(r"[ـ]+", "", str(s if s is not None else ""))
    return re.sub(r"\s+", " ", s).strip()


def norm_ar(s):
    s = clean(s).translate(_AR_DIGITS)
    s = re.sub(r"[ً-ٰٟ]", "", s)
    s = re.sub("[أإآٱ]", "ا", s)
    s = s.replace("ة", "ه").replace("ى", "ي").replace("ؤ", "و").replace("ئ", "ي")
    return s.lower()


# ورقة1 (معلومات عامة) ← حقول قالب رياض الأطفال: رقم عمود ورقة1 → حرف عمود القالب
KG_MAP = {2: "C", 3: "D", 4: "E", 5: "F", 6: "G", 7: "H", 8: "I", 9: "J", 10: "K", 14: "L", 15: "M",
          16: "N", 17: "O", 21: "Q", 22: "R", 23: "S", 24: "T", 25: "U", 28: "V", 29: "W", 30: "X",
          31: "Y", 32: "Z", 33: "AA", 34: "AB"}
for _i in range(8):  # GPS: AI..AP (35..42) → AC..AJ
    KG_MAP[35 + _i] = L(29 + _i)


def _cell(v):
    if v is None:
        return None
    if isinstance(v, float) and v == int(v):
        v = int(v)
    if isinstance(v, str):
        v = clean(v)
        return v or None
    return str(v)


def import_master(path, actor=None):
    """يستورد/يحدّث المدارس. لا يحذف أي مدرسة، ولا يكرر الرقم الإحصائي."""
    wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    ws = wb["ورقة1 (2)"] if "ورقة1 (2)" in wb.sheetnames else wb.worksheets[0]
    hdr = {c.column: clean(c.value) for c in ws[1] if c.value}
    # تفاصيل إضافية من عمود R فما بعد
    detail_cols = {c: h for c, h in hdr.items() if c >= 18}
    gen = wb["ورقة1"] if "ورقة1" in wb.sheetnames else None
    prefill = {}
    if gen is not None:
        for row in gen.iter_rows(min_row=7, max_col=42):
            sid = _cell(row[1].value)
            if not sid:
                continue
            prefill[sid] = {c.column: _cell(c.value) for c in row if c.value not in (None, "")}
    added = updated = 0
    with db.tx():
        for row in ws.iter_rows(min_row=7):
            sid = _cell(row[2].value)
            if not sid:
                continue
            name = _cell(row[1].value) or ""
            cat = clean(row[5].value)
            tpl = CATEGORY_TEMPLATE.get(cat)
            own = clean(row[7].value)
            det = {detail_cols[c.column]: _cell(c.value) for c in row
                   if c.column in detail_cols and c.value not in (None, "")}
            gps = {L(c.column): _cell(c.value) for c in row if 10 <= c.column <= 17 and c.value not in (None, "")}
            if gps:
                det["gps"] = gps
            pf_src = prefill.get(sid, {})
            pf = {}
            if tpl in ("primary", "secondary"):
                pf = {L(c): v for c, v in pf_src.items() if c >= 3}
            elif tpl == "kg":
                pf = {KG_MAP[c]: v for c, v in pf_src.items() if c in KG_MAP}
            r = db.q1("SELECT id FROM schools WHERE id=?", (sid,))
            args = (_cell(row[0].value) and int(float(_cell(row[0].value))) if _cell(row[0].value) else None,
                    name, norm_ar(name), clean(row[3].value), clean(row[4].value), cat, clean(row[6].value),
                    own, clean(row[8].value), tpl, json.dumps(det, ensure_ascii=False),
                    json.dumps(pf, ensure_ascii=False))
            if r:
                db.ex("UPDATE schools SET seq=?,name=?,name_norm=?,gender=?,env=?,category=?,independence=?,"
                      "ownership=?,shift=?,template=?,details=?,prefill=? WHERE id=?", args + (sid,))
                updated += 1
            else:
                db.ex("INSERT INTO schools(seq,name,name_norm,gender,env,category,independence,ownership,shift,"
                      "template,details,prefill,id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", args + (sid,))
                added += 1
        db.audit(actor, "schools.import", detail=dict(added=added, updated=updated))
    return dict(added=added, updated=updated)


def school_dict(r, full=True):
    d = dict(id=r["id"], name=r["name"], gender=r["gender"], env=r["env"], category=r["category"],
             independence=r["independence"], ownership=r["ownership"], shift=r["shift"], template=r["template"])
    if full:
        d["details"] = json.loads(r["details"] or "{}")
    return d


def search(q, limit=20, category=None, template=None):
    q = (q or "").strip()
    sql, args = "SELECT * FROM schools WHERE 1=1", []
    if category:
        sql += " AND category=?"
        args.append(category)
    if template:
        sql += " AND template=?"
        args.append(template)
    qn = norm_ar(q)
    if qn.isdigit():
        sql += " AND id LIKE ?"
        args.append(qn + "%")
    elif qn:
        for t in qn.split():
            sql += " AND name_norm LIKE ?"
            args.append("%" + t + "%")
    sql += " ORDER BY id LIMIT ?"
    args.append(limit)
    return [school_dict(r, full=False) for r in db.q(sql, args)]
