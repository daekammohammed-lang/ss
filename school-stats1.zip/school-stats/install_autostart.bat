@echo off
chcp 65001 >nul
rem شغّله مرة واحدة كمسؤول: يشغّل المنصة تلقائياً عند فتح ويندوز، ونسخة احتياطية يومياً الساعة 8 مساءً
cd /d "%~dp0"
schtasks /Create /TN "SchoolStats-Run" /TR "\"%~dp0run.bat\"" /SC ONSTART /RL HIGHEST /F
schtasks /Create /TN "SchoolStats-Backup" /TR "\"%~dp0backup.bat\"" /SC DAILY /ST 20:00 /RL HIGHEST /F
echo تم. أعد تشغيل الجهاز للتجربة.
pause
